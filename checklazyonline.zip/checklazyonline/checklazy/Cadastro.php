<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Cadastro</title>
    <link rel="stylesheet" href="cadastro.css">
</head>
<body>

    <style>
        * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: Arial, sans-serif;
}

html, body {
  width: 100%;
  height: 100%;
}

body {
  background: #1f1f1f;
  display: flex;
  justify-content: center;
}

.container {
  width: 100%;
  height: 100%;
  background: #fff;
  display: flex;
  position: relative;
  overflow: hidden;
}

/* LADO ESQUERDO */
.left {
  width: 40%;
  background: #7a7af0;
  display: flex;
  justify-content: center;
  align-items: center;
}

.left img {
  width: 80%;
  animation: floatMascote 4s ease-in-out infinite,
             breatheMascote 6s ease-in-out infinite;
}

/* LADO DIREITO */
.right {
  width: 40%;
  padding: 50px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.right h1 {
  font-size: 40px;
}

.right h2 {
  font-size: 18px;
  color: #666;
  margin-bottom: 25px;
}

.right label {
  font-size: 14px;
  color: #555;
}

.right input {
  width: 100%;
  max-width: 520px;
  padding: 16px 22px;
  margin: 8px 0 18px;
  border-radius: 25px;
  border: 1px solid #aaa;
  outline: none;
  transition: 0.2s;
}

.right input:focus {
  border-color: #7a7af0;
  box-shadow: 0 0 0 4px rgba(122,122,240,.15);
}

.btn-login {
  width: 100%;
  max-width: 520px;
  padding: 14px;
  border-radius: 25px;
  border: none;
  background: #3b3b98;
  color: white;
  font-weight: bold;
  cursor: pointer;
  transition: 0.2s;
}

.btn-login:hover {
  background: #2c2c7a;
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(59,59,152,.35);
}

.register {
  margin-top: 15px;
  font-size: 13px;
}

.register a {
  color: #3b3b98;
  text-decoration: none;
}
.social {
  margin-top: 25px;
  display: flex;
  gap: 25px;

  /* alinhamento igual aos inputs */
  width: 100%;
  max-width: 520px;
  justify-content: flex-start;
}


.social-btn {
  all: unset;               /* remove qualquer estilo padrão */
  cursor: pointer;
}

.social-btn img {
  width: 40px;
  height: 40px;
  display: block;
  transition: 
    transform 0.25s ease,
    filter 0.25s ease;
}

.social-btn:hover img {
  transform: translateY(-3px) scale(1.15);
  filter: drop-shadow(0 6px 12px rgba(122, 122, 240, 0.45));
}

.social-btn:active img {
  transform: scale(0.95);
}


/* CÍRCULO DECORATIVO */
.container::after {
  content: "";
  position: absolute;
  bottom: -380px;
  right: -380px;
  width: 800px;
  height: 800px;
  background: #c6c7ff;
  border-radius: 50%;
}

/* ANIMAÇÕES */
@keyframes floatMascote {
  0% { transform: translateY(0); }
  50% { transform: translateY(-12px); }
  100% { transform: translateY(0); }
}

@keyframes breatheMascote {
  0% { transform: scale(1); }
  50% { transform: scale(1.03); }
  100% { transform: scale(1); }
}
/* Fundo escurecido */
.modal-overlay {
    display: none; 
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(0, 0, 0, 0.4);
    z-index: 9999;
    justify-content: center;
    align-items: center;
    backdrop-filter: blur(2px); /* Efeito opcional de desfoque ao fundo */
}

/* Caixa do Modal */
.modal-content {
    background: #fff;
    width: 90%;
    max-width: 400px;
    padding: 30px;
    border-radius: 30px; /* Cantos bem arredondados como na imagem */
    box-shadow: 0 15px 40px rgba(0,0,0,0.2);
    text-align: left;
    animation: fadeInModal 0.3s ease-out;
}

.modal-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 15px;
}

.modal-icon { font-size: 24px; }

.modal-content h3 {
    color: #6b66ff; /* Roxo da imagem */
    font-size: 22px;
    font-weight: bold;
}

.modal-content p {
    color: #555;
    font-size: 16px;
    margin-bottom: 25px;
    line-height: 1.4;
}

/* Botões do Modal */
.modal-footer {
    display: flex;
    justify-content: flex-end;
    gap: 15px;
}

.modal-footer button {
    padding: 12px 25px;
    border-radius: 20px;
    border: none;
    font-weight: bold;
    cursor: pointer;
    transition: 0.2s;
}

.btn-secondary {
    background: #eeeeee;
    color: #333;
}

.btn-primary {
    background: #6b66ff;
    color: white;
}

.btn-primary:hover { background: #5651e6; }

@keyframes fadeInModal {
    from { opacity: 0; transform: translateY(-20px); }
    to { opacity: 1; transform: translateY(0); }
}
.left {
  width: 40%;
  background: #7a7af0;
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;
}

.video-bg {
  width: 100%;
  height: 100%;
  object-fit: cover; /* Faz o vídeo preencher sem distorcer */
}
/* ============================= */
/* 📱 MOBILE  */
/* ============================= */

@media (max-width: 768px) {

  body {
    background:rgb(255, 255, 255); /* fundo roxo igual login */
    display: block;
  }

  .container {
    display: flex;
    flex-direction: column;
    background: transparent;
    min-height: 100vh;
  }

  /* topo roxo com altura fixa */
  .left {
    display: block;
    width: 100%;
    height: 180px;
    background:rgb(255, 255, 255);
  }

  /* esconde vídeo no celular */
  .video-bg {
    display: none;
  }

  /* CARD branco */
  .right {
    width: 92%;
    max-width: 420px;
    margin: -60px auto 40px; /* sobe o card */
    padding: 35px 22px;

    background: #ffffff;
    border-radius: 28px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.12);

    align-items: stretch;
    text-align: left;
  }

  .right h1 {
    font-size: 30px;
    text-align: center;
  }

  .right h2 {
    text-align: center;
    margin-bottom: 20px;
  }

  .right input,
  .btn-login {
    width: 100%;
    max-width: 100%;
  }

  .social {
    justify-content: center;
  }

  .container::after {
    display: none;
  }
}

/* celulares pequenos */
@media (max-width: 420px) {
  .right {
    padding: 28px 18px;
  }

  .right h1 {
    font-size: 26px;
  }
}



    </style>
<div class="container">
 <div class="left">
    <video autoplay muted loop playsinline class="video-bg">
        <source src="animchecklazy.mp4" type="video/mp4">
       
    </video>
</div>


    <div class="right">
        <h1>Bem-vindo</h1>
        <h2>Cadastre-se</h2>

        <label>Nome de usuário</label>
        <input type="text" id="username">

        <label>Email</label>
        <input type="email" id="email">

        <label>Senha</label>
        <input type="password" id="password">

        <label>Confirmar senha</label>
        <input type="password" id="confirmPassword">

        <button class="btn-login" id="registerBtn">CADASTRAR</button>

        <p class="register">
            Já tem uma conta? <a href="Login.php">Entrar</a>
        </p>

        <div class="social">
            <button class="social-btn" id="facebook">
                <img src="facebook.png">
            </button>
            <button class="social-btn" id="google">
                <img src="google.png">
            </button>
            <button class="social-btn" id="instagram">
                <img src="instagram.png">
            </button>
        </div>
    </div>
</div>
<div id="customAlert" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <span class="modal-icon">📝</span>
            <h3 id="modalTitle">Essa pagina diz</h3>
        </div>
        <p id="modalMessage">Cadastro confirmado com sucesso!</p>
        <div class="modal-footer">
            <button class="btn-secondary" id="closeBtn">Cancelar</button>
            <button class="btn-primary" id="confirmBtn">OK</button>
        </div>
    </div>
</div>
</body>
<script>
    const modal = document.getElementById("customAlert");
const modalTitle = document.getElementById("modalTitle");
const modalMessage = document.getElementById("modalMessage");
const confirmBtn = document.getElementById("confirmBtn");
const closeBtn = document.getElementById("closeBtn");

// Função para mostrar o alerta customizado
function showCustomAlert(titulo, mensagem, redirecionar = false) {
    modalTitle.innerText = titulo;
    modalMessage.innerText = mensagem;
    modal.style.display = "flex";

    confirmBtn.onclick = () => {
        modal.style.display = "none";
        if (redirecionar) {
            window.location.href = "Login.php";
        }
    };
}

closeBtn.onclick = () => modal.style.display = "none";
function emailValido(email) {
    // Verifica formato básico com regex
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

// Lógica de cadastro atualizada
document.getElementById("registerBtn").addEventListener("click", async () => {
    const user = document.getElementById("username").value.trim();
    const email = document.getElementById("email").value.trim();
    const pass = document.getElementById("password").value.trim();
    const confirm = document.getElementById("confirmPassword").value.trim();


    if (!user || !email || !pass || !confirm) {
        
        showCustomAlert("Atenção", "Por favor, preencha todos os campos!");
        return;
    }
if (!emailValido(email)) {
    showCustomAlert("Erro", "Digite um email válido contendo '@' e '.'");
    return;
}

    if (pass !== confirm) {
        showCustomAlert("Erro", "As senhas inseridas não coincidem!");
        return;
    }

    try {
        const response = await fetch("salvar_usuario.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: `nome=${encodeURIComponent(user)}&email=${encodeURIComponent(email)}&senha=${encodeURIComponent(pass)}`
        });

        const data = await response.json();

        if (data.status === "sucesso") {
            showCustomAlert("Sucesso", "Cadastro realizado!", true);
        } else {
            showCustomAlert("Erro", data.mensagem);
        }

    } catch (error) {
        showCustomAlert("Erro", "Erro ao conectar com o servidor.");
    }
});



</script>

<script src="transition.js"> // Script para a transição </script>
</body>

</html>