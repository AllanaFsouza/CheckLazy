<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>CheckLazy</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
:root{
    --roxo: #6C63FF;
    --roxo-claro: #8e7fff;
    --ease-suave: cubic-bezier(0.4, 0, 0.2, 1);
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Lexend', sans-serif;
}

body{
    height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    background: linear-gradient(135deg, var(--roxo), var(--roxo-claro));
    color:white;
    overflow:hidden;
    transition: opacity 0.8s var(--ease-suave);
}

/* Container central */
.splash-container{
    text-align:center;
    animation: fadeIn 1.2s var(--ease-suave);
}

/* Logo */
.logo{
    width:140px;
    margin-bottom:25px;
    animation: floatLogo 3s ease-in-out infinite;
}

/* Nome */
h1{
    font-size:48px;
    font-weight:700;
    margin-bottom:8px;
}

/* Slogan */
.slogan{
    font-size:18px;
    font-weight:400;
    opacity:0.9;
    margin-bottom:25px;
}

/* Frase complementar */
.frase{
    font-size:16px;
    font-weight:300;
    opacity:0.85;
}

/* Animações */
@keyframes fadeIn{
    from{ opacity:0; transform: translateY(20px); }
    to{ opacity:1; transform: translateY(0); }
}

@keyframes floatLogo{
    0%{ transform: translateY(0); }
    50%{ transform: translateY(-10px); }
    100%{ transform: translateY(0); }
}

/* Fade out */
.fade-out{
    opacity:0;
}
</style>
</head>

<body>

<div class="splash-container">
    <img src="LogoCheckLazy.png" alt="Logo CheckLazy" class="logo">
    <h1>CheckLazy</h1>
    <div class="slogan">Devagar e sempre!</div>
    <div class="frase">Transformando pequenas tarefas em grandes conquistas 🐌✨</div>
</div>

<script>
/* Tempo antes de sair da capa (3 segundos) */
setTimeout(() => {
    document.body.classList.add("fade-out");

    setTimeout(() => {
        window.location.href = "Login.php";
    }, 800); // tempo do fade
}, 3000);
</script>

</body>
</html>