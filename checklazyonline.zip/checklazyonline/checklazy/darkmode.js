// ===============================
// 🌙 DARK MODE GLOBAL - CHECKLAZY
// ===============================

// Aplica tema salvo ao carregar qualquer página
function applySavedTheme() {
    const savedTheme = localStorage.getItem("theme");

    if (savedTheme === "dark") {
        document.body.classList.add("dark");
    } else {
        document.body.classList.remove("dark");
    }
    updateSkinsAndEvolutionsTheme();  // Adicionando o tema à área de skins e evoluções
}

// Alterna tema e salva no localStorage
function toggleTheme() {
    document.body.classList.toggle("dark");

    if (document.body.classList.contains("dark")) {
        localStorage.setItem("theme", "dark");
    } else {
        localStorage.setItem("theme", "light");
    }
    updateSkinsAndEvolutionsTheme();  // Atualiza tema ao alternar
}

// Atualiza os elementos de skins e evolução para o modo noturno
function updateSkinsAndEvolutionsTheme() {
    const skinsContent = document.getElementById("content-loja");
    const evolucoesContent = document.getElementById("content-evolucoes");

    // Adiciona classes de tema específico às seções de skins e evolução
    if (document.body.classList.contains("dark")) {
        skinsContent.classList.add("dark");
        evolucoesContent.classList.add("dark");
    } else {
        skinsContent.classList.remove("dark");
        evolucoesContent.classList.remove("dark");
    }
}

// Inicializa dark mode
document.addEventListener("DOMContentLoaded", () => {

    // Aplica o tema salvo
    applySavedTheme();

    // Adiciona evento em TODOS botões dark-mode da página
    document.querySelectorAll(".dark-mode").forEach(btn => {
        btn.addEventListener("click", toggleTheme);
    });
});
