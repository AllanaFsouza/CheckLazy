<?php
require_once "conexao.php";
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

$id    = $data["id"] ?? null;
$nome  = $data["nome"] ?? null;
$senha = $data["senha"] ?? null;

if (!$id || !$nome || !$senha) {
    echo json_encode(["success" => false]);
    exit;
}

/* 1️⃣ Descobrir o ID do kanban internamente */
$stmt = $conn->prepare("SELECT id FROM kanban_online WHERE nome = ? AND senha = ?");
$stmt->bind_param("ss", $nome, $senha);
$stmt->execute();
$res = $stmt->get_result();
$kanban = $res->fetch_assoc();

if (!$kanban) {
    echo json_encode(["success" => false]);
    exit;
}

$kanban_id = $kanban["id"];

/* 2️⃣ Deletar a tarefa */
$stmt = $conn->prepare("DELETE FROM tarefas_online WHERE id = ? AND kanban_online_id = ?");
$stmt->bind_param("ii", $id, $kanban_id);

echo json_encode(["success" => $stmt->execute()]);
