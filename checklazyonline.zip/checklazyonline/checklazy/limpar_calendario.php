<?php
session_start();
require_once "conexao.php";

if (!isset($_SESSION['usuario_id'])) {
    echo "erro";
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

// 🔥 Apaga TODOS os registros do usuário logado
$stmt = $conn->prepare("DELETE FROM calendario WHERE usuario_id = ?");
$stmt->bind_param("i", $usuario_id);

if($stmt->execute()){
    echo "ok";
} else {
    echo "erro";
}
?>
