<?php
session_start();
require_once "conexao.php";

header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

$nome = trim($data["nome"] ?? "");
$senha = trim($data["senha"] ?? "");

if (!$nome || !$senha) {
    echo json_encode(["success" => false]);
    exit;
}

$sql = "SELECT * FROM kanban_online WHERE nome = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $nome);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["success" => false]);
    exit;
}

$kanban = $result->fetch_assoc();

if (!password_verify($senha, $kanban["senha"])) {
    echo json_encode(["success" => false]);
    exit;
}

// salva o id do kanban online na sessão
$_SESSION["kanban_online_id"] = $kanban["id"];

echo json_encode([
    "success" => true,
    "kanban_id" => $kanban["id"]
]);
