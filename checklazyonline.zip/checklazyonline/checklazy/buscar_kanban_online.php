<?php
session_start();
require_once "conexao.php";

header("Content-Type: application/json");

if (!isset($_SESSION["kanban_online_id"])) {
    echo json_encode([
        "logado" => false
    ]);
    exit;
}

$kanban_id = $_SESSION["kanban_online_id"];

$stmt = $conn->prepare("SELECT nome FROM kanban_online WHERE id = ?");
$stmt->bind_param("i", $kanban_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $kanban = $result->fetch_assoc();

    echo json_encode([
        "logado" => true,
        "nome" => $kanban["nome"]
    ]);
} else {
    echo json_encode([
        "logado" => false
    ]);
}
