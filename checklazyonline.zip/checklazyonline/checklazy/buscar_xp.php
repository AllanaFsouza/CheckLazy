<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["status" => "erro"]);
    exit;
}
require_once("conexao.php");


$usuario_id = $_SESSION['usuario_id'];

$stmt = $conn->prepare("SELECT xp, nivel FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

echo json_encode($result->fetch_assoc());

$stmt->close();
$conn->close();
?>
