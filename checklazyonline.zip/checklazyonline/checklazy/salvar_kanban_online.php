<?php
session_start();
require_once "conexao.php";

header("Content-Type: application/json");

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["success" => false, "error" => "Não autenticado"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$nome = trim($data["nome"] ?? "");
$senha = trim($data["senha"] ?? "");
$usuario_id = $_SESSION["usuario_id"];

if (!$nome || !$senha) {
    echo json_encode(["success" => false, "error" => "Dados inválidos"]);
    exit;
}

/* 1️⃣ VERIFICA SE JÁ EXISTE KANBAN COM ESSE NOME (GLOBAL) */
$check = $conn->prepare("SELECT id FROM kanban_online WHERE nome = ?");
$check->bind_param("s", $nome);
$check->execute();
$resCheck = $check->get_result();

if ($resCheck->num_rows > 0) {
    echo json_encode([
        "success" => false,
        "error" => "Já existe um kanban com esse nome"
    ]);
    exit;
}

/* 2️⃣ CRIPTOGRAFA SENHA */
$senhaHash = password_hash($senha, PASSWORD_DEFAULT);

/* 3️⃣ SALVA O KANBAN */
$stmt = $conn->prepare("INSERT INTO kanban_online (usuario_id, nome, senha) VALUES (?, ?, ?)");
$stmt->bind_param("iss", $usuario_id, $nome, $senhaHash);

if (!$stmt->execute()) {
    echo json_encode(["success" => false, "error" => "Erro ao salvar kanban"]);
    exit;
}

$kanban_online_id = $stmt->insert_id;

/* 4️⃣ BUSCA TODAS AS TAREFAS ATUAIS DO USUÁRIO */
$sql = "
SELECT k.titulo, k.descricao, k.status_id
FROM kanban k
WHERE k.usuario_id = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

/* 5️⃣ INSERE AS TAREFAS NO KANBAN ONLINE */
$insertTask = $conn->prepare("
INSERT INTO kanban_online_tarefas (kanban_online_id, titulo, descricao, status_id)
VALUES (?, ?, ?, ?)
");

while ($tarefa = $result->fetch_assoc()) {
    $insertTask->bind_param(
        "issi",
        $kanban_online_id,
        $tarefa["titulo"],
        $tarefa["descricao"],
        $tarefa["status_id"]
    );
    $insertTask->execute();
}

echo json_encode(["success" => true]);
