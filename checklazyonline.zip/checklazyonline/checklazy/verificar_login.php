<?php
session_start();
header('Content-Type: application/json');

// conexão com o banco
require_once 'conexao.php';

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($username) || empty($password)) {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "Preencha todos os campos."
    ]);
    exit;
}

// busca usuário pelo nome
$stmt = $conn->prepare("SELECT id, nome, senha FROM usuarios WHERE nome = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {

    $user = $result->fetch_assoc();

    // verifica senha criptografada
    if (password_verify($password, $user['senha'])) {

        // cria sessão
        $_SESSION['usuario_id'] = $user['id'];
        $_SESSION['usuario_nome'] = $user['nome'];

        echo json_encode([
            "status" => "sucesso"
        ]);

    } else {

        echo json_encode([
            "status" => "erro",
            "mensagem" => "Senha incorreta."
        ]);
    }

} else {

    echo json_encode([
        "status" => "erro",
        "mensagem" => "Usuário não encontrado."
    ]);
}

$stmt->close();
$conn->close();
?>
