<?php
session_start();
require_once "conexao.php";

header("Content-Type: application/json");

if (!isset($_SESSION["kanban_online_id"])) {
    echo json_encode([]);
    exit;
}

$kanban_id = $_SESSION["kanban_online_id"];

$sql = "SELECT * FROM kanban_online_tarefas WHERE kanban_online_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $kanban_id);
$stmt->execute();
$result = $stmt->get_result();

$tarefas = [];

while ($row = $result->fetch_assoc()) {
    $tarefas[] = $row;
}

echo json_encode($tarefas);
