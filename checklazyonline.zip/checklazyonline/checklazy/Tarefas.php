<?php
session_start();
$nomeUsuario = $_SESSION['usuario_nome'] ?? 'Usuário';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

require_once 'conexao.php';

$usuario_id = $_SESSION['usuario_id'];

// Obter o nível do usuário
$stmt = $conn->prepare("SELECT nivel FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$stmt->bind_result($nivelUsuario);
$stmt->fetch();
$stmt->close();

// Consultar as tarefas
$stmt = $conn->prepare("SELECT * FROM tarefas WHERE usuario_id = ? ORDER BY criada_em DESC");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

$tarefas = [];
while ($row = $result->fetch_assoc()) {
    $tarefas[] = $row;
}

$stmt->close();
$conn->close();
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Tarefas - CheckLazy</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="tarefas.css">
    
</head>
<body>

<div class="app">
    <div class="overlay"></div>

 <!-- LOGO -->
  <aside class="sidebar">

    <div>
        <!-- LOGO -->
        <div class="logo">
            <div class="logo-img">
                <img src="LogoCheckLazy.png"alt="Logo da Empresa">
            </div>

            <div>
                <h2>CheckLazy</h2>
                <span>Devagar e sempre!</span>
            </div>
        </div>

        <!-- MENU -->
        <nav class="menu">
            <a href="Tela_inicial.php">📊 Dashboard</a>
            <a class="active">📋 Tarefas</a>
            <a href="Kanban.php">🗂 Kanban</a>
            <a href="Calendario.php">📅 Calendário</a>
            <a href="Progresso.php">📈 Progresso</a>
            <a href="Configuracoes.php">⚙️ Configurações</a>
            <a href="kanbanonline.php" >🌎 Kanban Online</a>
        </nav>
    </div>

    <!-- USUÁRIO -->
    <div class="user">
    <div style="display:flex; align-items:center; gap:10px;">
       <div class="avatar">
    <?= strtoupper(mb_substr($nomeUsuario, 0, 1, 'UTF-8')) ?>
</div>

       <div>
    <strong><?= htmlspecialchars($nomeUsuario) ?></strong><br>
    <small>Nível <?= $nivelUsuario ?></small>
</div>

    </div>

    <button class="logout-btn">⎋ Sair</button>
</div>


</aside>


    <!-- CONTEÚDO -->
    <main class="content">

        <!-- HEADER -->
        <header class="top">
           

            <div>
                <h1>Tarefas</h1>
                <p>Veja suas tarefas para hoje. Vamos lá!</p>
                
            </div>

            <div class="top-actions">
             
                <button class="mode">🌙</button>
                <button class="menu-toggle">☰</button>
            </div>
        </header>

        <!-- FILTRO -->
      <div class="filter">
    <button class="filter-btn" id="filterToggle">
    Filtrar
</button>


    <div class="filter-menu" id="filterMenu">
      <button data-filter="all" class="active">Todas</button>
<button data-filter="alta">Alta</button>
<button data-filter="media">Média</button>
<button data-filter="baixa">Baixa</button>

    </div>
</div>



        <!-- LISTA -->
        <section class="tasks-box">
<?php foreach ($tarefas as $task): ?>
    <div class="task <?= htmlspecialchars($task['prioridade']) ?>">
        
        <span class="task-name">
            <?= htmlspecialchars($task['nome']) ?>
        </span>

        <span class="tag <?= htmlspecialchars($task['prioridade']) ?>">
            <?= ucfirst($task['prioridade']) ?>
        </span>

        <button class="remove-task" data-id="<?= $task['id'] ?>">✖</button>
    </div>
<?php endforeach; ?>
</section>



    </main>
</div>
<!-- MODAL SAIR -->
<div id="logout-modal" class="modal">
    <div class="modal-card">
        <h3>Deseja sair da conta?</h3>
        <p>Você será desconectado do CheckLazy 🐌</p>

        <div class="modal-actions">
            <button id="cancel-logout">Cancelar</button>
            <button id="confirm-logout" class="btn-primary">Sair</button>
        </div>
    </div>
</div>

<script src="tarefas.js"></script>


<style>
:root {
    --roxo: #6C63FF;
    --cinza: #f6f6fb;
    --texto: #333;
    --branco: #fff;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Lexend', sans-serif;
}

body {
    background: var(--cinza);
}

.app {
    display: flex;
    min-height: 100vh;
}

/* SIDEBAR */
.sidebar {
    width: 280px;
    background: var(--branco);
    padding: 30px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.logo {
    display: flex;
    gap: 12px;
    margin-bottom: 30px;
}

.mascot {
    font-size: 32px;
}

.menu a {
    display: block;
    padding: 12px;
    margin: 6px 0;
    border-radius: 10px;
    text-decoration: none;
    color: var(--texto);
}

.menu a.active,
.menu a:hover {
    background: var(--roxo);
    color: white;
}

.user {
    display: flex;
    flex-direction: column;   /* 🔥 ISSO FAZ FICAR EMBAIXO */
    gap: 14px;
    border-top: 1px solid #eee;
    padding-top: 15px;
}


.avatar {
    width: 36px;
    height: 36px;
    background: var(--roxo);
    color: white;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
}

.logout-btn {
    width: 100%;
    padding: 14px 16px;
    border-radius: 14px;
    border: none;

    background: #f2f3f7;
    color: #555;

    font-size: 14px;
    font-weight: 600;

    display: flex;
    align-items: center;
    gap: 8px;

    cursor: pointer;
    transition: all 0.25s ease;
}

/* Hover suave (não agressivo) */
.logout-btn:hover {
    background: linear-gradient(135deg, #6C63FF, #8e7fff);
    color: white;
}


/* Clique */
.logout-btn:active {
    transform: scale(0.98);
}
/* CONTENT */
.content {
    flex: 1;
    padding: 40px;
}

.top {
    display: flex;
    justify-content: space-between;
    margin-bottom: 30px;
}

.top-actions {
    display: flex;
    gap: 16px;
    align-items: center;
}

.streak {
    background: #ffb347;
    color: white;
    padding: 8px 16px;
    border-radius: 20px;
    font-weight: 600;
}

.mode {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    border: 1px solid #ddd;
    background: white;
    cursor: pointer;
}

/* FILTRO */



/* TAREFAS */
.tasks-box {
    background: var(--branco);
    border-radius: 24px;
    padding: 30px;

    width: 100%;
    min-height: calc(100vh - 220px);

    display: flex;
    flex-direction: column;
    gap: 18px;
    overflow-y: auto;

    box-sizing: border-box;
}
.task-name {
    flex: 1;              /* ocupa todo espaço disponível */
    text-align: left;     /* garante que fique à esquerda */
}

.task-actions {
    display: flex;
    align-items: center;
    gap: 12px;
}




.task {
    background: white;
    border-radius: 20px;
    padding: 20px 24px;
    margin-bottom: 18px;

    display: flex;
    justify-content: space-between;
    align-items: center;

    box-shadow: 0 4px 12px rgba(0,0,0,0.06);
    border-left: 8px solid var(--roxo);
}

/* TAGS */
.tag {
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
}

.hoje { background: #ffe3e3; color: #ff5c5c; }
.amanha { background: #fff0d6; color: #ff9800; }
.semana { background: #e3f7e9; color: #2ecc71; }
.mes { background: #e6e5ff; color: #4a47ff; }

.task-actions {
    display: flex;
    align-items: center;
    gap: 12px;
}

.remove-task {
    border: none;
    background: transparent;
    color: #bbb;
    font-size: 16px;
    cursor: pointer;
    transition: color 0.2s ease, transform 0.2s ease;
}

.remove-task:hover {
    color: #ff5c5c;
    transform: scale(1.1);
}
/* FILTRO */
.filter {
    position: relative;
    display: flex;
    justify-content: flex-end;
    margin-bottom: 24px;
}

/* Botão principal FILTRAR */
.filter-btn {
    background: linear-gradient(135deg, #6C63FF, #8e7fff);
    color: white;
    border: none;
    padding: 12px 26px;
    border-radius: 22px;

    font-size: 15px;
    font-weight: 600;
    letter-spacing: 0.3px;

    cursor: pointer;
    box-shadow: 0 6px 14px rgba(108, 99, 255, 0.25);
    transition: all 0.25s ease;

    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.filter-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 8px 18px rgba(108, 99, 255, 0.35);
}

.filter-btn:active {
    transform: scale(0.97);
}

/* Menu flutuante */
.filter-menu {
    position: absolute;
    top: 52px;
    right: 0;

    background: white;
    border-radius: 18px;
    padding: 8px;
    width: 200px;

    box-shadow: 0 12px 30px rgba(0,0,0,0.12);

    display: none;
    flex-direction: column;
    gap: 4px;

    animation: fadeIn 0.2s ease;
    z-index: 10;
}

/* Mostrar menu */
.filter-menu.show {
    display: flex;
}

/* Botões do menu */
.filter-menu button {
    background: transparent;
    border: none;
    padding: 12px 14px;
    border-radius: 14px;
    text-align: left;

    font-size: 14px;
    font-weight: 600;
    color: #333;

    cursor: pointer;
    transition: background 0.2s ease, color 0.2s ease;
}

.filter-menu button:hover {
    background: #f2f3ff;
    color: #6C63FF;
}

/* Opção ativa */
.filter-menu button.active {
    background: linear-gradient(135deg, #6C63FF, #8e7fff);
    color: white;
}

/* Animação */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(-6px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
   .logo-img {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    overflow: hidden;

    display: flex;
    align-items: center;
    justify-content: center;
}

.logo-img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
}
/* ===================== */
/* 🌙 MODO NOTURNO */
/* ===================== */

body.dark {
    --cinza: #0f1220;
    --branco: #171a2b;
    --texto: #e4e6eb;
}

/* Texto geral */
body.dark {
    background: var(--cinza);
    color: var(--texto);
}

/* Sidebar */
body.dark .sidebar {
    background: var(--branco);
}

/* Conteúdo */
body.dark .tasks-box,
body.dark .task {
    background: #1d2038;
    color: var(--texto);
}

/* Menu */
body.dark .menu a {
    color: var(--texto);
}

body.dark .menu a:hover,
body.dark .menu a.active {
    background: linear-gradient(135deg, #6C63FF, #8e7fff);
    color: white;
}

/* Botão modo */
body.dark .mode {
    background: #1d2038;
    color: white;
    border-color: #333;
}

/* Filtro */
body.dark .filter-menu {
    background: #1d2038;
}

body.dark .filter-menu button {
    color: var(--texto);
}

body.dark .filter-menu button:hover {
    background: #2a2e55;
}

/* Logout */
body.dark .logout-btn {
    background: #1d2038;
    color: var(--texto);
}
/* Destaque leve nos cards */
.task {
    box-shadow: 0 0 0 1px rgba(108, 99, 255, 0.25);
}
/* MODAL */
.modal {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.45);
    backdrop-filter: blur(4px);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
    z-index: 9999;
}

.modal.show {
    opacity: 1;
    pointer-events: all;
}

.modal-card {
    background: var(--branco);
    padding: 28px;
    border-radius: 20px;
    width: 340px;
    text-align: center;
    animation: pop 0.3s ease;
}

.modal-actions {
    display: flex;
    justify-content: center;
    gap: 12px;
    margin-top: 20px;
}

.modal-actions button {
    padding: 10px 18px;
    border-radius: 10px;
    border: none;
    cursor: pointer;
    font-weight: 600;
}

#cancel-logout {
    background: #eee;
}
/* ============================= */
/* 📱 RESPONSIVO TAREFAS */
/* ============================= */

@media (max-width: 900px) {

    /* layout vira vertical */
    .app {
        flex-direction: column;
    }

    /* SIDEBAR vira bloco superior */
    .sidebar {
        width: 100%;
        padding: 16px 20px;
        flex-direction: column;
        align-items: stretch; /* 🔥 faz ocupar largura total */
        border-bottom: 1px solid #eee;
        gap: 12px;
    }

    /* 🔥 MENU alinhado igual dashboard (vertical) */
    .menu {
        display: flex;
        flex-direction: column;   /* um embaixo do outro */
        gap: 6px;
        width: 100%;
    }

    .menu a {
        width: 100%;              /* ocupa toda largura */
        text-align: left;         /* alinhado à esquerda */
        padding: 12px;
        font-size: 15px;
        border-radius: 12px;
    }

    /* usuário horizontal embaixo */
    .user {
        border: none;
        padding: 0;
        flex-direction: row;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        width: 100%;
    }

    .logout-btn {
        padding: 8px 12px;
        font-size: 12px;
        border-radius: 10px;
    }

    /* conteúdo */
    .content {
        padding: 20px;
    }
}


/* 📱 celulares pequenos */
@media (max-width: 480px) {

    .content {
        padding: 16px;
    }

    .tasks-box {
        padding: 14px;
    }

    .task {
        padding: 14px;
        border-radius: 16px;
    }

    .streak {
        font-size: 12px;
        padding: 6px 12px;
    }

    .mode {
        width: 36px;
        height: 36px;
    }
}
/* ============================= */
/* 📱 RESPONSIVO TAREFAS */
/* ============================= */

@media (max-width: 900px) {

    /* layout vira vertical */
    .app {
        flex-direction: column;
    }

    /* SIDEBAR vira bloco superior */
    .sidebar {
        width: 100%;
        padding: 16px 20px;
        flex-direction: column;
        align-items: stretch; /* 🔥 faz ocupar largura total */
        border-bottom: 1px solid #eee;
        gap: 12px;
    }

    /* 🔥 MENU alinhado igual dashboard (vertical) */
    .menu {
        display: flex;
        flex-direction: column;   /* um embaixo do outro */
        gap: 6px;
        width: 100%;
    }

    .menu a {
        width: 100%;              /* ocupa toda largura */
        text-align: left;         /* alinhado à esquerda */
        padding: 12px;
        font-size: 15px;
        border-radius: 12px;
    }

    /* usuário horizontal embaixo */
    .user {
        border: none;
        padding: 0;
        flex-direction: row;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        width: 100%;
    }

    .logout-btn {
        padding: 8px 12px;
        font-size: 12px;
        border-radius: 10px;
    }

    /* conteúdo */
    .content {
        padding: 20px;
    }
}


/* 📱 celulares pequenos */
@media (max-width: 480px) {

    .content {
        padding: 16px;
    }

    .tasks-box {
        padding: 14px;
    }

    .task {
        padding: 14px;
        border-radius: 16px;
    }

    .streak {
        font-size: 12px;
        padding: 6px 12px;
    }

    .mode {
        width: 36px;
        height: 36px;
    }
}
/* ============================= */
/* 📱 SIDEBAR MOBILE TOGGLE */
/* ============================= */

.menu-toggle {
    display: none;
    background: var(--roxo);
    color: white;
    border: none;
    font-size: 22px;
    width: 44px;
    height: 44px;
    border-radius: 12px;
    cursor: pointer;
}

/* MOBILE */
@media (max-width: 900px) {

    .menu-toggle {
        display: block;
    }

    .sidebar {
        position: fixed;
        top: 0;
        left: -100%;
        height: 100vh;
        width: 260px;
        transition: left 0.3s ease;
        z-index: 10000;
        box-shadow: 4px 0 20px rgba(0,0,0,0.2);
    }

    .sidebar.active {
        left: 0;
    }

    /* overlay escuro */
    .overlay {
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.4);
        opacity: 0;
        pointer-events: none;
        transition: 0.3s;
        z-index: 9999;
    }

    .overlay.show {
        opacity: 1;
        pointer-events: all;
    }
}


</style>
<script>
/* ===================== */
/* 🚪 LOGOUT */
/* ===================== */


const logoutBtn = document.querySelector('.logout-btn');
const logoutModal = document.getElementById('logout-modal');
const cancelLogout = document.getElementById('cancel-logout');
const confirmLogout = document.getElementById('confirm-logout');

logoutBtn.addEventListener('click', () => {
    logoutModal.classList.add('show');
});

cancelLogout.addEventListener('click', () => {
    logoutModal.classList.remove('show');
});

confirmLogout.addEventListener('click', () => {
    window.location.href = 'Login.php';
});

logoutModal.addEventListener('click', (e) => {
    if (e.target === logoutModal) {
        logoutModal.classList.remove('show');
    }
});

/* ===================== */
/* 🌙 MODO NOTURNO */
/* ===================== */
const modeBtn = document.querySelector('.mode');
const body = document.body;

// Carrega tema salvo
if (localStorage.getItem('theme') === 'dark') {
    body.classList.add('dark');
    modeBtn.textContent = '☀️';
}

modeBtn.addEventListener('click', () => {
    body.classList.toggle('dark');

    if (body.classList.contains('dark')) {
        localStorage.setItem('theme', 'dark');
        modeBtn.textContent = '☀️';
    } else {
        localStorage.setItem('theme', 'light');
        modeBtn.textContent = '🌙';
    }
});



/* ===================== */
/* 🔍 FILTRO */
/* ===================== */
const filterToggle = document.getElementById('filterToggle');
const filterMenu = document.getElementById('filterMenu');
const filterButtons = filterMenu.querySelectorAll('button');

filterToggle.addEventListener('click', () => {
    filterMenu.classList.toggle('show');
});

// Fecha ao clicar fora
document.addEventListener('click', (e) => {
    if (!e.target.closest('.filter')) {
        filterMenu.classList.remove('show');
    }
});

// Filtragem
filterButtons.forEach(btn => {
    btn.addEventListener('click', () => {
        const filter = btn.dataset.filter;
        const tasks = document.querySelectorAll('.task');

        filterButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        tasks.forEach(task => {
            const tag = task.querySelector('.tag');

            if (filter === 'all' || (tag && tag.classList.contains(filter))) {
                task.style.display = 'flex';
            } else {
                task.style.display = 'none';
            }
        });

        filterMenu.classList.remove('show');
    });
});
document.addEventListener("click", function(e) {
    if (e.target.classList.contains("remove-task")) {

        const button = e.target;
        const taskId = button.dataset.id;
        const taskElement = button.closest(".task");

        fetch("remover_tarefa.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: "id=" + taskId
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                taskElement.remove();
            } else {
                alert("Erro ao remover tarefa");
            }
        });
    }
});
/* ===================== */
/* 📱 MENU MOBILE */
/* ===================== */

const menuToggle = document.querySelector('.menu-toggle');
const sidebar = document.querySelector('.sidebar');
const overlay = document.querySelector('.overlay');

const mobile = window.matchMedia("(max-width: 900px)");

menuToggle.addEventListener('click', () => {
    if (mobile.matches) {
        sidebar.classList.toggle('active');
        overlay.classList.toggle('show');
    }
});

overlay.addEventListener('click', () => {
    sidebar.classList.remove('active');
    overlay.classList.remove('show');
});

</script>
<script src="transition.js"></script>
</body>