<?php
session_start();
require_once "conexao.php";

header("Content-Type: application/json");

// 🔐 Verifica se está logado no Kanban Online
if (!isset($_SESSION["kanban_online_id"])) {
    echo json_encode([
        "success" => false,
        "error" => "Não logado no Kanban Online"
    ]);
    exit;
}

// 🔎 Lê JSON corretamente
$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode([
        "success" => false,
        "error" => "JSON inválido"
    ]);
    exit;
}

$titulo = trim($data["titulo"] ?? "");
$descricao = trim($data["descricao"] ?? "");
$status = trim($data["status"] ?? "");

if (!$titulo || !$status) {
    echo json_encode([
        "success" => false,
        "error" => "Dados inválidos"
    ]);
    exit;
}

$kanban_id = $_SESSION["kanban_online_id"];

// 🔄 Converte texto → id do status com segurança
switch ($status) {
    case "todo":
        $status_id = 1;
        break;
    case "doing":
        $status_id = 2;
        break;
    case "review":
        $status_id = 3;
        break;
    case "done":
        $status_id = 4;
        break;
    default:
        echo json_encode([
            "success" => false,
            "error" => "Status inválido"
        ]);
        exit;
}

// 🔧 Prepara a query
$stmt = $conn->prepare("
    INSERT INTO kanban_online_tarefas 
    (kanban_online_id, titulo, descricao, status_id)
    VALUES (?, ?, ?, ?)
");

if (!$stmt) {
    echo json_encode([
        "success" => false,
        "error" => "Erro ao preparar query: " . $conn->error
    ]);
    exit;
}

$stmt->bind_param("issi", $kanban_id, $titulo, $descricao, $status_id);

// 🚀 Executa
if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode([
        "success" => false,
        "error" => "Erro ao inserir: " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();
