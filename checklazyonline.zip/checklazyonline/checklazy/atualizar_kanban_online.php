<?php
session_start();
require_once "conexao.php";

header("Content-Type: application/json");

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["success" => false, "error" => "Não autenticado"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$nome  = trim($data["nome"] ?? "");
$senha = trim($data["senha"] ?? "");
$usuario_id = $_SESSION["usuario_id"];

if (!$nome || !$senha) {
    echo json_encode(["success" => false, "error" => "Dados inválidos"]);
    exit;
}

/* 1️⃣ Buscar o kanban online */
$stmt = $conn->prepare("
    SELECT id, senha 
    FROM kanban_online 
    WHERE nome = ? AND usuario_id = ?
");
$stmt->bind_param("si", $nome, $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "error" => "Kanban não encontrado"]);
    exit;
}

$kanban = $result->fetch_assoc();

/* 2️⃣ Verificar senha */
if (!password_verify($senha, $kanban["senha"])) {
    echo json_encode(["success" => false, "error" => "Senha incorreta"]);
    exit;
}

$kanban_online_id = $kanban["id"];

/* 3️⃣ Apagar tarefas antigas do kanban online */
$stmt = $conn->prepare("DELETE FROM kanban_online_tarefas WHERE kanban_online_id = ?");
$stmt->bind_param("i", $kanban_online_id);

if (!$stmt->execute()) {
    echo json_encode(["success" => false, "error" => "Erro ao limpar tarefas antigas"]);
    exit;
}

/* 4️⃣ Buscar tarefas atuais do kanban local */
$sql = "
SELECT titulo, descricao, status_id
FROM kanban
WHERE usuario_id = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

/* 5️⃣ Inserir novamente no kanban online */
$insert = $conn->prepare("
    INSERT INTO kanban_online_tarefas 
    (kanban_online_id, titulo, descricao, status_id)
    VALUES (?, ?, ?, ?)
");

while ($tarefa = $result->fetch_assoc()) {
    $insert->bind_param(
        "issi",
        $kanban_online_id,
        $tarefa["titulo"],
        $tarefa["descricao"],
        $tarefa["status_id"]
    );
    $insert->execute();
}

echo json_encode(["success" => true]);
