<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CheckLazy | Gerenciamento de Tarefas Consciente</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; scroll-behavior: smooth; }
        .bg-purple-soft { background-color: #7d79d1; }
        
        /* Animação da Preguiça Flutuando */
        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(3deg); }
            50% { transform: translateY(-20px) rotate(5deg); }
        }
        .animate-float {
            animation: float 5s ease-in-out infinite;
        }
        /* Esconde barra de rolagem */
.no-scrollbar::-webkit-scrollbar {
    display: none;
}
.no-scrollbar {
    -ms-overflow-style: none;
    scrollbar-width: none;
}

    </style>
</head>
<body class="bg-gray-50 text-gray-800">

    <nav class="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
            <div class="text-2xl font-bold text-indigo-700 flex items-center gap-2">
                <span></span> CheckLazy
            </div>
            <div class="space-x-8 hidden md:flex items-center">
                <a href="#solucoes" class="text-sm font-medium hover:text-indigo-600 transition">Soluções</a>
                <a href="#metodologia" class="text-sm font-medium hover:text-indigo-600 transition">Metodologia</a>
                <a href="roxoinicio.php" class="bg-indigo-600 text-white px-6 py-2 rounded-full font-bold hover:bg-indigo-700 transition shadow-md">
                    Experimentar 
                </a>
            </div>
        </div>
    </nav>

    <section class="relative overflow-hidden bg-white py-16 lg:py-24">
        <div class="max-w-7xl mx-auto px-6 flex flex-col lg:flex-row items-center">
            
            <div class="w-full lg:w-1/2 text-center lg:text-left z-10">
                <span class="inline-block py-1 px-3 rounded-full bg-indigo-100 text-indigo-700 text-xs font-bold tracking-widest uppercase mb-4">
                    Produtividade Sem Pressa
                </span>
                <h1 class="text-5xl lg:text-6xl font-extrabold text-gray-900 leading-tight mb-6">
                    Gerencie tarefas no seu <span class="text-indigo-600">próprio ritmo.</span>
                </h1>
                <p class="text-xl text-gray-600 mb-10 max-w-xl mx-auto lg:mx-0">
                    O CheckLazy ajuda você a organizar o fluxo de trabalho sem a pressão das ferramentas tradicionais. Simplicidade para quem busca resultados e paz mental.
                </p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                    <a href="roxoinicio.php" class="bg-indigo-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-indigo-700 transition shadow-xl text-center">
                        Começar Agora
                    </a>
                  <a href="#solucoes"
   class="bg-white text-indigo-600 border-2 border-indigo-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-indigo-50 transition inline-block text-center">
    Ver Demonstração
</a>

                </div>
            </div>

            <div class="w-full lg:w-1/2 mt-16 lg:mt-0 flex justify-center relative">
                <div class="relative bg-purple-soft rounded-[3rem] p-12 shadow-2xl animate-float">
                    <img src="LogoCheckLazy.png" alt="Mascote CheckLazy" class="w-64 lg:w-80">
                </div>
            </div>
        </div>
    </section>

    <section id="metodologia" class="py-24 bg-white">
        <div class="max-w-5xl mx-auto px-6">
            <div class="flex flex-col md:flex-row gap-16 items-center border-t border-gray-100 pt-16">
                <div class="w-full md:w-1/2">
                    <h2 class="text-4xl font-bold mb-6 text-indigo-900">O que é o Gerenciamento de Tarefas Consciente?</h2>
                    <p class="text-gray-600 mb-6 leading-relaxed text-lg">
                        Muito além de uma simples lista de afazeres, o gerenciamento de tarefas é a arte de organizar sua <strong>energia</strong>, não apenas suas horas. No <span class="text-indigo-600 font-bold">CheckLazy</span>, acreditamos que uma tarefa bem planejada é metade do caminho para um descanso sem culpa.
                    </p>
                    <p class="text-gray-600 mb-8 leading-relaxed text-lg">
                       o gerenciamento de tarefas que substitui a ansiedade pelo foco, garantindo que você trabalhe bem para poder descansar melhor.
                </div>
                <div class="w-full md:w-1/2 bg-indigo-50 p-8 rounded-3xl border border-indigo-100 shadow-inner">
                    <h4 class="font-bold mb-4 text-indigo-900 text-xl">Por que CheckLazy?</h4>
                    <ul class="space-y-4">
                        <li class="flex items-center gap-3 text-gray-700">✅ <strong>Check:</strong> A satisfação de concluir o que importa.</li>
                        <li class="flex items-center gap-3 text-gray-700">✅ <strong>Lazy:</strong> O descanso merecido e sem ansiedade.</li>
                        <li class="flex items-center gap-3 text-gray-700">✅ <strong>Foco:</strong> Interface limpa para mentes criativas.</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
 <!-- SEÇÃO DEMONSTRAÇÃO COM ROLAGEM -->
<section id="solucoes" class="py-24 bg-gray-100">
    <div class="max-w-6xl mx-auto px-6 text-center">

        <h2 class="text-4xl font-bold text-indigo-900 mb-4">
            Veja o CheckLazy em ação
        </h2>
        <p class="text-gray-600 mb-12 text-lg">
            Explore as funcionalidades que tornam sua produtividade mais leve e organizada.
        </p>

        <div class="relative">

            <!-- Botão Esquerda -->
            <button id="prev"
                class="absolute left-0 top-1/2 -translate-y-1/2 bg-white shadow-lg w-12 h-12 rounded-full flex items-center justify-center z-10 hover:bg-indigo-100 transition">
                ◀
            </button>

            <!-- Container do Carrossel -->
            <div id="carousel"
                class="flex gap-8 overflow-x-auto scroll-smooth no-scrollbar">

                <!-- IMAGEM 1 -->
                <img src="imagens/tela1.png"
                    class="min-w-full md:min-w-[80%] rounded-3xl shadow-2xl">

                <!-- IMAGEM 2 -->
                <img src="imagens/tela2.png"
                    class="min-w-full md:min-w-[80%] rounded-3xl shadow-2xl">

                <!-- IMAGEM 3 -->
                <img src="imagens/tela3.png"
                    class="min-w-full md:min-w-[80%] rounded-3xl shadow-2xl">
                <!-- IMAGEM 3 -->
                <img src="imagens/tela4.png"
                    class="min-w-full md:min-w-[80%] rounded-3xl shadow-2xl">

            </div>

            <!-- Botão Direita -->
            <button id="next"
                class="absolute right-0 top-1/2 -translate-y-1/2 bg-white shadow-lg w-12 h-12 rounded-full flex items-center justify-center z-10 hover:bg-indigo-100 transition">
                ▶
            </button>

        </div>
    </div>
</section>
    <footer class="bg-gray-900 text-white py-20 px-6">
        <div class="max-w-4xl mx-auto text-center">
            <h2 class="text-3xl md:text-5xl font-bold mb-8">Pronto para organizar sua vida de forma leve?</h2>
            <a href="roxoinicio.php" class="inline-block bg-white text-gray-900 px-10 py-4 rounded-full font-bold text-xl hover:bg-indigo-100 transition shadow-2xl">
                Criar Minha Conta 
            </a>
            <div class="mt-16 pt-8 border-t border-gray-800 text-gray-500 text-sm italic">
                &copy; 2026 CheckLazy - Produtividade no seu tempo.
            </div>
        </div>
       

    </footer>
<script>
const carousel = document.getElementById('carousel');
const next = document.getElementById('next');
const prev = document.getElementById('prev');

next.addEventListener('click', () => {
    carousel.scrollBy({ left: 800, behavior: 'smooth' });
});

prev.addEventListener('click', () => {
    carousel.scrollBy({ left: -800, behavior: 'smooth' });
});
</script>html

</body>
</html>