<?php
session_start();
header("Content-Type: application/json");

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["status" => "erro", "mensagem" => "Não autenticado"]);
    exit;
}

require_once("conexao.php");


$usuario_id = $_SESSION['usuario_id'];

$data = json_decode(file_get_contents("php://input"), true);
$skin = $data['skin'] ?? '';
$preco = isset($data['preco']) ? (int)$data['preco'] : 0;

// Buscar moedas e skins atuais
$stmt = $conn->prepare("SELECT moedas, skins_compradas FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo json_encode(["status" => "erro", "mensagem" => "Usuário não encontrado"]);
    exit;
}

$moedas = isset($user['moedas']) ? (int)$user['moedas'] : 0;
$skins = $user['skins_compradas'] ? json_decode($user['skins_compradas'], true) : [];

if ($moedas < $preco) {
    echo json_encode(["status" => "erro", "mensagem" => "Moedas insuficientes"]);
    exit;
}

// Adicionar skin se ainda não tiver
if (!in_array($skin, $skins) && $skin != '') {
    $skins[] = $skin;
}

// Subtrair preço
$moedas -= $preco;

// Atualizar banco
$skins_json = json_encode($skins);
$stmt = $conn->prepare("UPDATE usuarios SET moedas = ?, skins_compradas = ? WHERE id = ?");
$stmt->bind_param("isi", $moedas, $skins_json, $usuario_id);
$stmt->execute();

// Retornar saldo atualizado de moedas
echo json_encode([
    "status" => "sucesso",
    "moedas" => $moedas
]); 