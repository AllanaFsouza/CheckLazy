<?php 
session_start();
require_once "conexao.php";

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$sql = "SELECT nome, nivel FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();

$nome_usuario = $usuario['nome'];
$nivel_usuario = $usuario['nivel']; // Armazenando o nível do usuário
$inicial = strtoupper(substr($nome_usuario, 0, 1));

?>

<!DOCTYPE html>
<html lang="pt-BR">
  
<head>

  <script>
    if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark');
    }
</script>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Calendário - CheckLazy</title>

<style>
*{
  margin:0;
  padding:0;
  box-sizing:border-box;
  font-family:"Segoe UI", Arial, sans-serif;
}

body{
  display:flex;
  height:100vh;
  background:#fafafa;
}

/* SIDEBAR */
.sidebar{
  width:260px;
  background:#fff;
  border-right:1px solid #eee;
  padding:20px;
  display:flex;
  flex-direction:column;
  justify-content:space-between;
}

/* LOGO */
.logo{
  display:flex;
  align-items:center;
  gap:12px;
  margin-bottom:30px;
}

.logo-mascot{
  width:48px;
  height:48px;
  background:#E8E7FF;
  padding:6px;
  border-radius:12px;
}

.logo-text h2{
  font-size:16px;
  color:#6C63FF;
}

.logo-text span{
  font-size:12px;
  color:#888;
}

/* MENU */
.menu a{
  display:block;
  padding:12px;
  margin:5px 0;
  border-radius:10px;
  color:#333;
  text-decoration:none;
}

.menu a:hover{
  background:#6C63FF;
  color:#fff;
}

.user {
    display: flex;
    flex-direction: column;
    gap: 15px;
    width: 100%;
}

.user-top {
    display: flex;
    align-items: center;
    gap: 12px;
}


.avatar{
  width:38px;
  height:38px;
  border-radius:50%;
  background:transparent; /* remove o roxo */
  color:#000000; /* mantém a letra visível */
  display:flex;
  align-items:center;
  justify-content:center;
  font-weight:bold;
}



/* MAIN */
.main{
  flex:1;
  padding:30px 40px;
}

.top{
  display:flex;
  justify-content:space-between;
  align-items:center;
}

.actions{
  display:flex;
  gap:12px;
}

.actions button{
  border:none;
  cursor:pointer;
  border-radius:22px;
  padding:10px 18px;
  font-weight:600;
}

.streak{background:#ffb703;color:#fff;}
.dark-mode{background:#E8E7FF;}
.new-task{background:#6C63FF;color:#fff;}
.clear{
  border:none;
  background:#FFB6D5;
  color:#5a2d42;
  padding:12px 22px;
  border-radius:999px;
  cursor:pointer;
  font-weight:600;
  font-size:14px;
  transition:
    background 0.25s ease,
    transform 0.15s ease,
    box-shadow 0.15s ease;
}

.clear:hover{
  background:#ffa2c8;
  box-shadow:0 8px 18px rgba(255,182,213,0.45);
  transform:translateY(-2px);
}

.clear:active{
  transform:scale(0.95);
  box-shadow:0 4px 10px rgba(255,182,213,0.35);
}
.clear{
  background:#FFB6D5;
  color:#5a2d42;
}

.clear:hover{
  background:#ffa2c8;
}
.btn-animado{
  border:none;
  cursor:pointer;
  border-radius:999px;
  padding:10px 18px;
  font-weight:600;
  font-size:14px;
  transition:
    background 0.25s ease,
    transform 0.15s ease,
    box-shadow 0.15s ease;
}

.btn-animado:hover{
  box-shadow:0 8px 18px rgba(0,0,0,0.15);
  transform:translateY(-2px);
}

.btn-animado:active{
  transform:scale(0.95);
  box-shadow:0 4px 10px rgba(0,0,0,0.12);
}


/* CALENDÁRIO */
.section-title{
  margin:30px 0 15px;
  font-size:18px;
}

.calendar-wrapper{
  display:flex;
  justify-content:center;
  margin-top: 60px;
}

.calendar{
  background:#fff;
  width:780px;
  padding:32px;
  border-radius:30px;
  box-shadow:0 18px 36px rgba(122,92,255,.18);
    animation: flutuar 4s ease-in-out infinite;
}


.calendar-header{
  display:flex;
  justify-content:space-between;
  align-items:center;
  font-size:20px;
  font-weight:600;
  margin-bottom:20px;
}

.calendar-header button{
  border:none;
  background:#E8E7FF;
  padding:6px 14px;
  border-radius:10px;
  cursor:pointer;
}

/* SEMANA / DIAS */
.weekdays,
.days{
  display:grid;
  grid-template-columns:repeat(7,1fr);
  text-align:center;
}

.weekdays div{
  font-size:12px;
  color:#c5bfff;
  margin-bottom:12px;
}

.day{
  height:80px;
  display:flex;
  align-items:center;
  justify-content:center;
  border-radius:12px;
  cursor:pointer;
  color:#9c9c9c;
  font-weight:500;
  position:relative;
  border:1px solid #eee; /* linhas */
}


/* MARCAÇÕES */
.day::after{
  content:"";
  position:absolute;
  bottom:6px;
  right:6px;
  width:12px;
  height:12px;
  border-radius:50%;
  opacity:0;
}

.day.hoje::after{background:#6c63ff;opacity:1;}
.day.concluido::after{background:#2ecc71;opacity:1;}
.day.atencao::after{background:#f1c40f;opacity:1;}
.day.evento::after{background:#3498db;opacity:1;}

.day.dayoff::after{
  width:26px;
  height:26px;
  background:url("LogoCheckLazy.png") no-repeat center/contain;
  opacity:1;
}

/* LEGENDA */
.legend{
  display:flex;
  justify-content:center;
  gap:25px;
  margin-top:35px;
}

.legend-item{
  display:flex;
  align-items:center;
  gap:8px;
  cursor:pointer;
  font-size:13px;
  font-weight:600;
}

.legend-item.active{
  outline:2px solid #6C63FF;
  border-radius:8px;
  padding:4px 6px;
}

.dot{
  width:14px;
  height:14px;
  border-radius:50%;
}

.purple{background:#6c63ff;}
.green{background:#2ecc71;}
.yellow{background:#f1c40f;}
.blue{background:#3498db;}

.streak:hover{
  background:#f4a900; /* um pouco mais escuro */
}

.dark-mode:hover{
  background:#d6d3ff; /* roxo mais forte */
}
/* =========================
   MODO NOTURNO
   ========================= */

body.dark {
    --roxo: #9B8CFF;
    --roxo-claro: #4a3fff;
    --cinza-fundo: #1e1e2f;
    --texto-principal: #ffffff;
    --texto-secundario: #cfcfe6;
    --branco: #2c2c3c;
    --borda: #3a3a4c;
}

/* textos gerais */
body.dark h1,
body.dark h2,
body.dark h3,
body.dark p,
body.dark span,
body.dark strong {
    color: var(--texto-principal);
}

/* sidebar */
body.dark .sidebar {
    background: var(--branco);
}

body.dark .nav-link {
    color: var(--texto-principal);
}

body.dark .nav-link:hover,
body.dark .nav-link.active {
    background: var(--roxo);
    color: white;
}

/* usuário */
body.dark .user-info strong {
    color: white;
}

/* calendário */
body.dark .calendar {
    background: var(--branco);
}

body.dark .day{
  border:1px solid #444;
}



/* botão limpar */
body.dark .clear {
    background: #ff9fc6;
    color: #3a2230;
}


.decor-circle{
  position: fixed;
  bottom: -150px;   /* empurra um pouco para fora */
  right: -150px;    /* empurra um pouco para fora */
  width: 500px;
  height: 500px;
  background: #b7b3ff; /* cor da bolinha */
  border-radius: 50%;
  z-index: -1; /* fica atrás de tudo */
  opacity: 0.6;
}
.avatar {
    width: 36px;
    height: 36px;
    background: var(--roxo);   /* 🔥 AQUI define a cor roxa */
    color: white;
    border-radius: 50%;        /* 🔥 ISSO transforma em círculo */
    display: flex;
    justify-content: center;
    align-items: center;
}


</style>
</head>

<body>

  <style>
        :root {
            --roxo: #6C63FF;
            --roxo-claro: #E8E7FF;
            --cinza-fundo: #f8f9fd;
            --texto-principal: #333;
            --texto-secundario: #666;
            --branco: #ffffff;
            --borda: #f0f0f0;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Lexend', sans-serif;
        }

        body {
            background-color: var(--cinza-fundo);
        }

        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* --- Estilização da Sidebar --- */
        .sidebar {
            width: 300px;
            background-color: var(--branco);
            padding: 30px 20px;
            display: flex;
            flex-direction: column;
            border-right: 1px solid var(--borda);
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 40px;
            padding-left: 10px;
        }

        .logo-icon {
            width: 50px;
            height: 50px;
            background-color: var(--roxo-claro);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .logo-text h2 {
            font-size: 24px;
            font-weight: 700;
            color: #000;
            line-height: 1;
        }

        .logo-text span {
            font-size: 14px;
            color: var(--texto-secundario);
        }

        /* Menu de Navegação */
        .nav-menu {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 18px;
            text-decoration: none;
            color: var(--texto-principal);
            font-weight: 400;
            font-size: 16px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

     .nav-link:hover {
    background-color: var(--roxo);
    color: var(--branco);
}

        

        .nav-link.active {
            background-color: var(--roxo);
            color: var(--branco);
            font-weight: 600;
        }

        /* Seção do Usuário (Fixada no Rodapé) */
        .user-section {
            margin-top: auto;
            padding-top: 20px;
            border-top: 1px solid var(--borda);
            display: flex;
            align-items: center;
            gap: 12px;
            padding-left: 10px;
        }

        .user-avatar {
            width: 45px;
            height: 45px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 20px;
            color: var(--texto-principal);
        }

        .user-info strong {
            display: block;
            font-size: 18px;
            color: #000;
        }

        .user-info span {
            font-size: 14px;
            color: var(--texto-secundario);
        }

        /* Área de conteúdo para visualização */
        .main-content {
            flex-grow: 1;
            padding: 40px;
            color: #ccc;
            display: flex;
            align-items: center;
            justify-content: center;
            font-style: italic;
        }
        /* legenda no modo escuro */
body.dark .legend-item {
    color: white;
}

/* caso algum texto interno herde outra cor */
body.dark .legend-item span,
body.dark .legend-item div {
    color: white;
}
/* ícone de lembrete ao lado da bolinha */
.day[title]::before{
  content:"📝";
  position:absolute;
  bottom:4px;
  right:22px; /* fica ao lado da bolinha */
  font-size:12px;
}
* BOTÃO SAIR — estilo da referência */
.logout-btn {
    width: 100%;
    padding: 14px 16px;
    border-radius: 14px;
    border: none;

    background: #f2f3f7;
    color: #555;

    font-size: 14px;
    font-weight: 600;

    display: flex;
    align-items: center;
    gap: 8px;

    cursor: pointer;
    transition: all 0.25s ease;
}

/* Hover suave (não agressivo) */
.logout-btn:hover {
    background: linear-gradient(135deg, #6C63FF, #8e7fff);
    color: white;
}


/* Clique */
.logout-btn:active {
    transform: scale(0.98);
}
body.dark .logout-btn {
    background: #2f2f40;
    color: #ddd;
}

body.dark .logout-btn:hover {
    background: #3a3a4c;
    color: #fff;
}
@keyframes flutuar {
  0%   { transform: translateY(0px); }
  50%  { transform: translateY(-8px); }
  100% { transform: translateY(0px); }
}
.logout-btn { width: 100%; padding: 14px 16px; border-radius: 14px; border: none; background: #f2f3f7; color: #555; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.25s ease; }
.logout-btn:hover { background: linear-gradient(135deg, #6C63FF, #8e7fff); color: white; }
.logout-btn:active { transform: scale(0.98); }
body.dark .logout-btn { background: #2f2f40; color: #ddd; }
body.dark .logout-btn:hover { background: #3a3a4c; color: #fff;
 }

.decor-circle{
  position: fixed;
  width: 500px;
  height: 500px;
  background: #b7b3ff;
  border-radius: 50%;
  z-index: -1;
  opacity: 0.6;
}

/* bolha canto superior esquerdo */
.decor-circle.left{
  top: -90px;
  left: -90px;
}

/* bolha canto inferior direito */
.decor-circle.right{
  bottom: -150px;
  right: -150px;
}
/* Avatar e textos do usuário no modo escuro */
body.dark .user .avatar{
  color: #fff !important;   /* letra U branca */
}

body.dark .user strong,
body.dark .user small{
  color: #fff !important;   /* Usuário e Nível 5 brancos */
}

.modal-overlay{
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.45);
  display: none;
  align-items: center;
  justify-content: center;
  z-index: 9999;
}

.modal{
  background: #fff;
  width: 360px;
  padding: 26px;
  border-radius: 22px;
  box-shadow: 0 20px 40px rgba(108,99,255,0.35);
  animation: modalIn 0.25s ease;
}

.modal h3{
  color:#6C63FF;
  margin-bottom:8px;
}

.modal p{
  font-size:14px;
  color:#555;
  margin-bottom:14px;
}

.modal input{
  width:100%;
  padding:12px 14px;
  border-radius:14px;
  border:1px solid #ddd;
  font-size:14px;
  outline:none;
}

.modal input:focus{
  border-color:#6C63FF;
}

.modal-actions{
  display:flex;
  justify-content:flex-end;
  gap:10px;
  margin-top:18px;
}

.btn-cancelar{
  background:#eee;
  border:none;
  padding:10px 16px;
  border-radius:999px;
  cursor:pointer;
}

.btn-salvar{
  background:#6C63FF;
  color:#fff;
  border:none;
  padding:10px 18px;
  border-radius:999px;
  cursor:pointer;
}

@keyframes modalIn{
  from{ transform:scale(0.9); opacity:0; }
  to{ transform:scale(1); opacity:1; }
}

/* modo escuro */
body.dark .modal{
  background:#2c2c3c;
}

body.dark .modal p,
body.dark .modal input{
  color:#fff;
  background:#3a3a4c;
  border-color:#555;
}

.btn-sair{
  background: linear-gradient(135deg, #6C63FF, #8e7fff);
  color:#fff;
  border:none;
  padding:10px 20px;
  border-radius:999px;
  cursor:pointer;
}

.btn-sair:hover{
  box-shadow:0 8px 18px rgba(108,99,255,0.45);
}

/* modo escuro */
body.dark .btn-sair{
  background: linear-gradient(135deg, #9B8CFF, #b1a7ff);
}

.logout-btn { width: 100%; padding: 14px 16px; border-radius: 14px; border: none; background: #f2f3f7; color: #555; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.25s ease; }
.logout-btn:hover { background: linear-gradient(135deg, #6C63FF, #8e7fff); color: white; }
.logout-btn:active { transform: scale(0.98); }
body.dark .logout-btn { background: #2f2f40; color: #ddd; }
body.dark .logout-btn:hover { background: #3a3a4c; color: #fff; }

/* LINKS DO MENU NO MODO ESCURO */
body.dark .menu a {
    color: #ffffff;
}

body.dark .menu a:hover,
body.dark .menu a.active {
    background: var(--roxo);
    color: #ffffff;
}
/* ============================= */
/* 📱 RESPONSIVIDADE */
/* ============================= */

@media (max-width: 1200px){
  .calendar{
    width: 100%;
    max-width: 700px;
  }
}

@media (max-width: 992px){

  .app-container{
    flex-direction: column;
  }

  .sidebar{
    width: 100%;
    border-right: none;
    border-bottom: 1px solid var(--borda);
  }

  .main{
    padding: 20px;
  }

  .calendar-wrapper{
    justify-content: center;
    align-items: center;
  }

  .calendar{
    width: 100%;
    max-width: 600px;
    padding: 24px;
  }

  .day{
    height: 70px;
  }
}

@media (max-width: 768px){

  .top{
    flex-direction: column;
    align-items: flex-start;
    gap: 20px;
  }

  .actions{
    width: 100%;
    justify-content: flex-start;
  }

  .calendar-wrapper{
    margin-top: 30px;
  }

  .calendar{
    width: 100%;
    max-width: 100%;
    border-radius: 20px;
    padding: 20px;
  }

  .day{
    height: 60px;
    font-size: 14px;
  }

  .legend{
    flex-wrap: wrap;
    gap: 15px;
  }
}

@media (max-width: 480px){

  .calendar{
    padding: 16px;
  }

  .day{
    height: 50px;
    font-size: 13px;
  }

  .calendar-header{
    font-size: 16px;
  }

  .weekdays div{
    font-size: 10px;
  }
}
/* ============================= */
/* 📱 SIDEBAR RESPONSIVA */
/* ============================= */

.menu-toggle{
  display: none;
  background: var(--roxo-claro);
  border: none;
  border-radius: 999px;
  padding: 10px 16px;
  cursor: pointer;
}

/* Overlay escuro */
.sidebar-overlay{
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.45);
  opacity: 0;
  visibility: hidden;
  transition: opacity 0.3s ease;
  z-index: 998;
}

.sidebar-overlay.active{
  opacity: 1;
  visibility: visible;
}

/* MOBILE */
@media (max-width: 992px){

  .menu-toggle{
    display: inline-block;
  }

  .sidebar{
    position: fixed;
    top: 0;
    left: -100%;
    width: 80%;          /* ocupa 80% da tela */
    max-width: 280px;    /* limite máximo */
    height: 100vh;
    background: var(--branco);
    z-index: 999;
    transition: left 0.3s ease;
    box-shadow: 0 0 30px rgba(0,0,0,0.25);
  }

  .sidebar.active{
    left: 0;
  }
}
.top{
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:20px;
}

.top-text{
  display:flex;
  flex-direction:column;
}

.top-actions{
  display:flex;
  gap:12px;
}
@media (max-width: 768px){

  .top{
    flex-direction: row;      /* mantém lado a lado */
    align-items: center;
    justify-content: space-between;
  }

  .top-actions{
    width: auto;
    justify-content: flex-end;
  }

}



    </style>
    
</head>
<body>
<div class="sidebar-overlay"></div>

<div class="app-container">
    <aside class="sidebar">
        <div class="logo-section">
           <img src="LogoCheckLazy.png" class="logo-mascot"> <div class="logo-text">
                <h2>CheckLazy</h2>
                <span>Devagar e sempre!</span>
            </div>
        </div>

<nav class="nav-menu">
<a class="nav-link" href="Tela_inicial.php">📊 Dashboard</a>
<a class="nav-link" href="Tarefas.php">📋 Tarefas</a>
<a class="nav-link" href="Kanban.php" >🗂 Kanban</a>
<a class="nav-link active" href="Calendario.php">📅 Calendário</a>
<a class="nav-link" href="Progresso.php">📈 Progresso</a>
<a class="nav-link" href="Configuracoes.php">⚙️ Configurações</a>
<a class="nav-link" href="kanbanonline.php">🌎 Kanban Online</a>

 
</nav>

      <div class="user-section">
<div class="user">
    <div class="user-top">
        <div class="avatar"><?php echo $inicial; ?></div>
        <div class="user-info">
            <strong><?php echo htmlspecialchars($nome_usuario); ?></strong>
           <small>Nível <?php echo $nivel_usuario; ?></small>

        </div>
    </div>

    <button class="logout-btn">⎋ Sair</button>
</div>

</aside> <main class="content"><main class="content"><header class="header">

</div>
    </aside>

    </main>
<div class="decor-circle left"></div>
<div class="decor-circle right"></div>

<main class="main">
  <div class="top">
    <div>
      <h1>Calendario</h1>
  <p>Confira suas princpais atividades no calendário</p>
  

    </div>

    <div class="top-actions">
<button class="dark-mode btn-animado">🌙</button>
<button class="menu-toggle btn-animado">☰</button>

     
    </div>
  </div>



  <div class="calendar-wrapper">
    <div class="calendar">

      <div class="calendar-header">
        <button onclick="mesAnterior()">◀</button>
        <span id="mesAno"></span>
        <button onclick="proximoMes()">▶</button>
      </div>

      <div class="weekdays">
        <div>DOM</div><div>SEG</div><div>TER</div>
        <div>QUA</div><div>QUI</div><div>SEX</div><div>SAB</div>
      </div>

      <div class="days" id="days"></div>
    </div>
  </div>

  <div class="legend">
    <div class="legend-item" data-type="hoje"><div class="dot purple"></div>HOJE</div>
    <div class="legend-item" data-type="concluido"><div class="dot green"></div>CONCLUÍDO</div>
    <div class="legend-item" data-type="atencao"><div class="dot yellow"></div>ATENÇÃO</div>
    <div class="legend-item" data-type="evento"><div class="dot blue"></div>EVENTOS</div>
    <div class="legend-item" data-type="dayoff">🦥 DAY OFF</div>
     <button class="clear" onclick="limparTudo()">Limpar tudo</button>
  </div>
</main>

<div class="modal-overlay" id="modalLembrete">
  <div class="modal">
    <h3>📝 Lembrete</h3>
    <p>Escreva um lembrete (apague tudo para deletar):</p>

    <input type="text" id="lembreteInput" placeholder="Digite aqui..." />

    <div class="modal-actions">
      <button class="btn-cancelar">Cancelar</button>
      <button class="btn-salvar">Salvar</button>
    </div>
  </div>
</div>

<div class="modal-overlay" id="modalLogout">
  <div class="modal">
    <h3>⎋ Sair</h3>
    <p>Deseja realmente sair?</p>

    <div class="modal-actions">
      <button class="btn-cancelar">Cancelar</button>
      <button class="btn-sair">Sair</button>
    </div>
  </div>
</div>

</body>

<script>
/* ============================= */
/* 🌙 SISTEMA GLOBAL DE TEMA */
/* ============================= */

function aplicarTemaSalvo() {
    const tema = localStorage.getItem("theme");
    if (tema === "dark") {
        document.body.classList.add("dark");
    } else {
        document.body.classList.remove("dark");
    }
}

function configurarDarkMode() {
    document.querySelectorAll(".dark-mode").forEach(btn => {
        btn.addEventListener("click", () => {
            document.body.classList.toggle("dark");

            const temaAtual = document.body.classList.contains("dark")
                ? "dark"
                : "light";

            localStorage.setItem("theme", temaAtual);
        });
    });
}

/* ============================= */
/* 📅 CALENDÁRIO */
/* ============================= */

const mesAnoEl = document.getElementById("mesAno");
const daysEl = document.getElementById("days");

const meses = [
  "Janeiro","Fevereiro","Março","Abril","Maio","Junho",
  "Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"
];

let hoje = new Date();
let mes = hoje.getMonth();
let ano = hoje.getFullYear();
let selectedType = null;
let lembretes = {};

function renderCalendar(){
  daysEl.innerHTML = "";
  mesAnoEl.innerText = `${meses[mes]} ${ano}`;

  const primeiroDia = new Date(ano, mes, 1).getDay();
  const totalDias = new Date(ano, mes + 1, 0).getDate();

  for(let i = 0; i < primeiroDia; i++){
    daysEl.innerHTML += "<div></div>";
  }

  for(let d = 1; d <= totalDias; d++){
    const day = document.createElement("div");
    day.className = "day";
    day.innerText = d;

    if(
      d === hoje.getDate() &&
      mes === hoje.getMonth() &&
      ano === hoje.getFullYear()
    ){
      day.classList.add("hoje");
    }

   day.addEventListener("click", () => {
    let chave = `${ano}-${mes}-${d}`;

    /* Se estiver escolhendo bolinha */
    if(selectedType){

        if(day.classList.contains(selectedType)){
            day.className = "day";

            // 🔥 SALVAR REMOÇÃO
            salvarNoBanco(chave, "", lembretes[chave] || "");

        } else {
            day.className = "day " + selectedType;

            // 🔥 SALVAR TIPO
            salvarNoBanco(chave, selectedType, lembretes[chave] || "");
        }

        return;
    }


        /* Abrir modal */
        const modal = document.getElementById("modalLembrete");
        const input = document.getElementById("lembreteInput");
        const btnSalvar = modal.querySelector(".btn-salvar");
        const btnCancelar = modal.querySelector(".btn-cancelar");

        modal.style.display = "flex";
        input.value = lembretes[chave] || "";
        input.focus();

       btnSalvar.onclick = () => {
    let texto = input.value.trim();

    if(texto === ""){
        delete lembretes[chave];
        day.removeAttribute("title");

        // 🔥 salvar remoção de lembrete
        salvarNoBanco(chave, day.classList[1] || "", "");

    } else {
        lembretes[chave] = texto;
        day.title = texto;

        // 🔥 salvar lembrete
        salvarNoBanco(chave, day.classList[1] || "", texto);
    }

    modal.style.display = "none";
};


        btnCancelar.onclick = () => {
            modal.style.display = "none";
        };
      

    });

    daysEl.appendChild(day);
  }
}

function proximoMes(){
  mes++;
  if(mes > 11){ mes = 0; ano++; }
  renderCalendar();
}

function mesAnterior(){
  mes--;
  if(mes < 0){ mes = 11; ano--; }
  renderCalendar();
}

function limparTudo(){

  // 🔥 Limpa visualmente
  document.querySelectorAll(".day").forEach(day=>{
    day.className = "day";
    day.removeAttribute("title");
  });

  document.querySelectorAll(".legend-item")
    .forEach(i=>i.classList.remove("active"));

  selectedType = null;
  lembretes = {};

  // 🔥 Limpa no banco
  fetch("limpar_calendario.php", {
      method: "POST"
  })
  .then(res => res.text())
  .then(res => {
      console.log("Limpeza banco:", res);
  })
  .catch(err => {
      console.error("Erro ao limpar banco:", err);
  });

}


document.querySelectorAll(".legend-item").forEach(item=>{
  item.addEventListener("click",()=>{
    document.querySelectorAll(".legend-item")
      .forEach(i=>i.classList.remove("active"));

    if(selectedType === item.dataset.type){
      selectedType = null;
      return;
    }

    item.classList.add("active");
    selectedType = item.dataset.type;
  });
});

/* ============================= */
/* 🚪 LOGOUT MODAL */
/* ============================= */

const modalLogout = document.getElementById("modalLogout");
const btnLogout = document.querySelector(".logout-btn");

if(btnLogout){
    btnLogout.addEventListener("click", () => {
        modalLogout.style.display = "flex";
    });

    modalLogout.querySelector(".btn-cancelar").addEventListener("click", () => {
        modalLogout.style.display = "none";
    });

    modalLogout.querySelector(".btn-sair").addEventListener("click", () => {
        window.location.href = "login.php";
    });
}
function carregarCalendario(){
    fetch("buscar_calendario.php")
    .then(res => res.json())
    .then(dados => {
        dados.forEach(item => {
            const [anoDB, mesDB, diaDB] = item.data.split("-");
            if(parseInt(mesDB)-1 == mes && parseInt(anoDB) == ano){

                document.querySelectorAll(".day").forEach(day => {
                    if(parseInt(day.innerText) == parseInt(diaDB)){

                        if(item.tipo){
                            day.classList.add(item.tipo);
                        }

                        if(item.lembrete){
                            day.title = item.lembrete;
                            lembretes[`${ano}-${mes}-${diaDB}`] = item.lembrete;
                        }
                    }
                });

            }
        });
    });
}

/* ============================= */
/* 🚀 INICIALIZAÇÃO GLOBAL */
/* ============================= */

document.addEventListener("DOMContentLoaded", () => {
    aplicarTemaSalvo();
    configurarDarkMode();
    renderCalendar();
    carregarCalendario();

});
function salvarNoBanco(chave, tipo, lembrete){

    const [anoDB, mesDB, diaDB] = chave.split("-");

    // 🔥 FORMATO CORRETO YYYY-MM-DD
    const mesFormatado = String(parseInt(mesDB) + 1).padStart(2, "0");
    const diaFormatado = String(diaDB).padStart(2, "0");

    const dataFormatada = `${anoDB}-${mesFormatado}-${diaFormatado}`;

    fetch("salvar_calendario.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: `data=${dataFormatada}&tipo=${tipo}&lembrete=${encodeURIComponent(lembrete)}`
    })
    .then(res => res.text())
    .then(res => {
        console.log("Resposta servidor:", res);
    })
    .catch(err => {
        console.error("Erro ao salvar:", err);
    });
}
/* ============================= */
/* ☰ TOGGLE SIDEBAR */
/* ============================= */

const toggleBtn = document.querySelector(".menu-toggle");
const sidebar = document.querySelector(".sidebar");
const overlay = document.querySelector(".sidebar-overlay");

if(toggleBtn){
  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("active");
    overlay.classList.toggle("active");
  });
}

if(overlay){
  overlay.addEventListener("click", () => {
    sidebar.classList.remove("active");
    overlay.classList.remove("active");
  });
}


</script>
<script src="transition.js"></script>

</body>
</html>