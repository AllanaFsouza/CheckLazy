<?php
session_start();
header("Content-Type: application/json");

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["success" => false]);
    exit;
}
require_once 'conexao.php'; 

if (!isset($_POST['id'])) {
    echo json_encode(["success" => false]);
    exit;
}

$id = intval($_POST['id']);
$usuario_id = $_SESSION['usuario_id'];

$stmt = $conn->prepare("DELETE FROM tarefas WHERE id = ? AND usuario_id = ?");
$stmt->bind_param("ii", $id, $usuario_id);
$stmt->execute();

echo json_encode(["success" => true]);

$stmt->close();
$conn->close();
?>
