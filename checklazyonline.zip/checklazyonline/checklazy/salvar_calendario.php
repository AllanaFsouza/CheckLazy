<?php
session_start();
require_once "conexao.php";

if (!isset($_SESSION['usuario_id'])) {
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

$data = $_POST['data'] ?? null;
$tipo = $_POST['tipo'] ?? null;
$lembrete = $_POST['lembrete'] ?? null;

if (!$data) exit;

// Se ambos estiverem vazios → deletar
if (empty($tipo) && empty($lembrete)) {
    $stmt = $conn->prepare("DELETE FROM calendario WHERE usuario_id = ? AND data = ?");
    $stmt->bind_param("is", $usuario_id, $data);
    $stmt->execute();
    exit;
}

// Inserir ou atualizar
$stmt = $conn->prepare("
INSERT INTO calendario (usuario_id, data, tipo, lembrete)
VALUES (?, ?, ?, ?)
ON DUPLICATE KEY UPDATE
tipo = VALUES(tipo),
lembrete = VALUES(lembrete)
");

$stmt->bind_param("isss", $usuario_id, $data, $tipo, $lembrete);
$stmt->execute();

echo "ok";
?>
