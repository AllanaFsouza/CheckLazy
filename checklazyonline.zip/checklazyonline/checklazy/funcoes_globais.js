document.addEventListener("DOMContentLoaded", function () {

    const botoesSequencia = document.querySelectorAll(".btn-sequencia");
    const modal = document.getElementById("modalManutencao");
    const fecharModal = document.getElementById("fecharModal");

    botoesSequencia.forEach(botao => {
        botao.addEventListener("click", function (e) {
            e.preventDefault();
            modal.classList.add("active");
        });
    });

    fecharModal.addEventListener("click", function () {
        modal.classList.remove("active");
    });

    // Fechar clicando fora
    modal.addEventListener("click", function (e) {
        if (e.target === modal) {
            modal.classList.remove("active");
        }
    });

});
