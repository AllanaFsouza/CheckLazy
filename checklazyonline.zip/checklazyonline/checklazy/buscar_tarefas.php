<?php
session_start();
include "conexao.php";

$usuario_id = $_SESSION['usuario_id'];

$sql = "SELECT nome, prioridade, concluida FROM tarefas WHERE usuario_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

$tarefas = [];

while ($row = $result->fetch_assoc()) {
    $tarefas[] = [
        "name" => $row['nome'],
        "priority" => $row['prioridade'],
        "done" => (bool)$row['concluida']
    ];
}

echo json_encode($tarefas);
