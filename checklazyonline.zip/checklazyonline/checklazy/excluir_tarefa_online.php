<?php
session_start();
require_once "conexao.php";

header("Content-Type: application/json");

if (!isset($_SESSION["kanban_online_id"])) {
    echo json_encode(["success" => false]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$id = intval($data["id"] ?? 0);

if (!$id) {
    echo json_encode(["success" => false]);
    exit;
}

$kanban_id = $_SESSION["kanban_online_id"];

// Garante que a tarefa pertence ao kanban logado
$sql = "DELETE FROM kanban_online_tarefas 
        WHERE id = ? AND kanban_online_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id, $kanban_id);
$stmt->execute();

echo json_encode(["success" => true]);
