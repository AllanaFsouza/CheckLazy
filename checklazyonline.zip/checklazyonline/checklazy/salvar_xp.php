<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["status" => "erro", "mensagem" => "Usuário não autenticado"]);
    exit;
}

require_once 'conexao.php'; 

$usuario_id = $_SESSION['usuario_id'];
$data = json_decode(file_get_contents("php://input"), true);

if (!$data || !isset($data['xp'], $data['nivel'])) {
    echo json_encode(["status" => "erro", "mensagem" => "Dados inválidos"]);
    exit;
}

$xp = intval($data['xp']);
$nivel = intval($data['nivel']);

if ($xp < 0) $xp = 0;
if ($nivel < 1) $nivel = 1;

$stmt = $conn->prepare("UPDATE usuarios SET xp = ?, nivel = ? WHERE id = ?");
$stmt->bind_param("iii", $xp, $nivel, $usuario_id);

if ($stmt->execute()) {
    echo json_encode(["status" => "sucesso"]);
} else {
    echo json_encode(["status" => "erro", "mensagem" => $stmt->error]);
}

$stmt->close();
$conn->close();
?>
