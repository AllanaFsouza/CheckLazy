// ========================================
// CHECKLAZY TRANSITION PREMIUM
// Fade + Preguiça animada + Saída esquerda
// ========================================

document.addEventListener("DOMContentLoaded", function () {

    // =============================
    // CRIA OVERLAY
    // =============================
    const overlay = document.createElement("div");
    overlay.className = "purple-transition";

    overlay.innerHTML = `
        <div class="transition-content">
            <img src="LogoCheckLazy.png" alt="Logo">
        </div>
    `;

    document.body.appendChild(overlay);

    // =============================
    // ESTILO
    // =============================
    const style = document.createElement("style");
    style.innerHTML = `
    .purple-transition {
        position: fixed;
        inset: 0;
        background: rgba(108, 99, 255, 0.92);
        backdrop-filter: blur(6px);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 99999;

        opacity: 0;
        transform: translateX(0);
        transition: opacity 0.4s ease, transform 0.6s ease;
    }

    body.dark .purple-transition {
        background: rgba(74, 63, 255, 0.92);
    }

    /* Fade in */
    .purple-transition.show {
        opacity: 1;
    }

    /* Sai pela esquerda */
    .purple-transition.hide {
        transform: translateX(-100%);
        opacity: 1;
    }

    .transition-content {
        text-align: center;
        opacity: 0;
        transform: scale(0.95);
        transition: opacity 0.4s ease, transform 0.4s ease;
    }

    .purple-transition.show .transition-content {
        opacity: 1;
        transform: scale(1);
    }

    .transition-content img {
        width: 110px;
        animation: slothLife 4s ease-in-out infinite;
        filter: drop-shadow(0 8px 20px rgba(0,0,0,0.2));
    }

    @keyframes slothLife {
        0%   { transform: translateY(0px) rotate(0deg); }
        25%  { transform: translateY(-4px) rotate(-2deg); }
        50%  { transform: translateY(-6px) rotate(0deg); }
        75%  { transform: translateY(-4px) rotate(2deg); }
        100% { transform: translateY(0px) rotate(0deg); }
    }
    `;
    document.head.appendChild(style);

    // =============================
    // INTERCEPTA LINKS INTERNOS
    // =============================
    document.addEventListener("click", function (e) {

        const link = e.target.closest("a");
        if (!link) return;

        const href = link.getAttribute("href");

        if (!href || href.startsWith("#") || href.startsWith("http")) return;

        e.preventDefault();

        overlay.classList.add("show");

        // tempo do fade + pequena pausa
        setTimeout(() => {
            window.location.href = href;
        }, 600);
    });

    // =============================
    // AO CARREGAR NOVA PÁGINA
    // =============================

    overlay.classList.add("show");

    // pequena pausa antes de sair
    setTimeout(() => {
        overlay.classList.add("hide");
    }, 400);

    setTimeout(() => {
        overlay.remove();
    }, 1000);

});
