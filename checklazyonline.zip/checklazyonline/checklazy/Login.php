<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>

    <style>
        /* Reset básico */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: Arial, sans-serif;
}

/* html e body ocupam tudo */
html, body {
  width: 100%;
  height: 100%;
}

/* Fundo preto ocupando tudo */
body {
  background: #1f1f1f;
  height: 100%;
  width: 100%;
  display: flex;
  align-items: stretch;   /* para a altura ocupar tudo */
  justify-content: center;
}

/* Container branco ocupa toda a tela */
.container {
  width: 100%;
  height: 100%;
  background: #fff;
  display: flex;
  overflow: hidden;
  position: relative; /* ESSENCIAL para o meio círculo */
}


/* Colunas como antes */
.left {
  width: 40%;
  background: #7a7af0;
  display: flex;
  align-items: center;
  justify-content: center;
}

.left img {
  width: 800px;
  max-width: 90%;
  height: auto;
}

.right {
  width: 40%;
  padding: 50px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start; /* mantém alinhado à esquerda */
}

/* ... o restante do seu CSS segue igual */


.right h1 {
    font-size: 40px;
    margin-bottom: 30px;
}

.right label {
    font-size: 14px;
    color: #555;
}

.right input {
    width: 100%;
    max-width: 520px;     /* largura parecida com a referência */
    padding: 18px 22px;
    margin: 8px 0 20px;
    border-radius: 25px;
    border: 1px solid #aaa;
    outline: none;
}


.btn-login {
    width: 100%;
    max-width: 520px;
    padding: 14px;
    border: none;
    border-radius: 25px;
    background: #3b3b98;
    color: #fff;
    font-weight: bold;
    cursor: pointer;

    transition: 
      transform 0.2s ease,
      box-shadow 0.2s ease,
      background 0.2s ease;
}

.btn-login:hover {
    background: #2c2c7a;
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(59, 59, 152, 0.35);
}

.btn-login:active {
    transform: scale(0.97);
    box-shadow: 0 4px 10px rgba(59, 59, 152, 0.25);
}


.btn-login:hover {
    background: #2c2c7a;
}

.register {
    text-align: center;
    margin-top: 15px;
    font-size: 13px;
}

.register a {
    color: #3b3b98;
    text-decoration: none;
}

.social {
    display: flex;
    justify-content: center;
    gap: 25px;
    margin-top: 25px;
}

.social-btn {
    all: unset;           /* anula o estilo padrão */
    cursor: pointer;
}

.social-btn img {
    width: 45px;
    height: 45px;
    display: block;
    transition: transform 0.2s ease;
}

.social-btn:hover img {
    transform: scale(1.1);
}

.icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #e6e6ff;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;

    transition: 
      transform 0.25s ease,
      box-shadow 0.25s ease,
      background 0.25s ease;
}

.icon:hover {
    transform: translateY(-3px) scale(1.1);
    background: #d6d7ff;
    box-shadow: 0 6px 15px rgba(122, 122, 240, 0.35);
}

.icon:active {
    transform: scale(0.95);
}

.container::after {
  content: "";
  position: absolute;
  bottom: -380px;
  right: -380px;
  width: 800px;
  height: 800px;
  background: #c6c7ff;
  border-radius: 50%;

  transition: 
    transform 0.6s ease,
    opacity 0.6s ease;
}
.container:hover::after {
  transform: scale(1.08) translate(-20px, -20px);
}


.right input {
    transition: border 0.2s ease, box-shadow 0.2s ease;
}

.right input:focus {
    border: 1px solid #7a7af0;
    box-shadow: 0 0 0 4px rgba(122, 122, 240, 0.15);
}
@keyframes floatMascote {
  0% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-12px);
  }
  100% {
    transform: translateY(0);
  }
}

.left img {
  animation: floatMascote 4s ease-in-out infinite;
}
@keyframes breatheMascote {
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.03);
  }
  100% {
    transform: scale(1);
  }
}

.left img {
  animation: floatMascote 4s ease-in-out infinite,
             breatheMascote 6s ease-in-out infinite;
}
.left {
  width: 40%;
  background: #7a7af0;
  position: relative;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
}

.bg-video {
  width: 100%;
  height: 100%;
  object-fit: cover; /* faz preencher sem distorcer */
}
/* ============================= */
/* 📱 RESPONSIVO LOGIN */
/* ============================= */

@media (max-width: 768px) {

  html, body {
    width: 100%;
    height: 100%;
    background: #ffffff;
  }

  /* remove o fundo escuro lateral */
  body {
    display: block;
  }

  /* container ocupa toda a tela */
  .container {
    display: block;
    width: 100%;
    min-height: 100vh;
    background: #ffffff;
  }

  /* 🔥 remove o lado do vídeo no celular */
  .left {
    display: none !important;
    width: 0 !important;
  }

  /* formulário estilo app */
  .right {
    width: 100%;
    max-width: 420px;
    margin: 0 auto;
    padding: 40px 22px;
    align-items: stretch;
    text-align: left;
  }

  /* inputs e botão largura total */
  .right input,
  .btn-login {
    width: 100%;
    max-width: 100%;
  }

  /* redes sociais centralizadas */
  .social {
    justify-content: center;
  }

  /* remove o círculo gigante */
  .container::after {
    display: none;
  }
}


/* 📱 celulares pequenos */
@media (max-width: 420px) {

  .right {
    padding: 32px 18px;
  }

  .right h1 {
    font-size: 28px;
  }
}
/* ============================= */
/* 📱 AJUSTE VISUAL MOBILE */
/* ============================= */

@media (max-width: 768px) {

  /* fundo gradiente roxo suave */
  body {
    background: linear-gradient(135deg, #7a7af0, #c6c7ff);
  }

  /* centraliza verticalmente o conteúdo */
  .container {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  /* caixa do formulário estilo app */
  .right {
    background: #ffffff;
    border-radius: 28px;
    box-shadow: 0 20px 50px rgba(0,0,0,0.15);

    padding: 40px 28px;
    max-width: 360px;
    width: 90%;

    /* 🔥 centralização real */
    align-items: center;
    text-align: center;
  }

  /* inputs e botão alinhados */
  .right input,
  .btn-login {
    width: 100%;
    max-width: 100%;
    text-align: center;
  }

  /* espaçamento mais bonito */
  .right label {
    align-self: flex-start;
    margin-left: 4px;
  }
}


/* celulares pequenos */
@media (max-width: 420px) {

  .right {
    padding: 32px 22px;
  }

  .right h1 {
    font-size: 26px;
  }
}

    </style>
<div class="container">
   <div class="left">
    <video autoplay muted loop playsinline class="bg-video">
        <source src="animchecklazy.mp4" type="video/mp4">
   
    </video>
</div>


    <div class="right">
        <h1>Bem-Vindo</h1>

        <label>Nome de usuário</label>
        <input type="text" id="username">

        <label>Senha</label>
        <input type="password" id="password">

      <button class="btn-login" id="loginBtn" href="Tela_inicial.php">ENTRAR</button>


        <p class="register">
            Não tem uma conta? <a href="Cadastro.php">Cadastre-se</a>
        </p>

        <div class="social">
    <button class="social-btn" id="facebook">
        <img src="facebook.png" alt="Login com Facebook">
    </button>

    <button class="social-btn" id="google">
        <img src="google.png" alt="Login com Google">
    </button>

    <button class="social-btn" id="github">
        <img src="instagram.png" alt="Login com instagram">
    </button>
</div>

    </div>
</div>
<script>
document.getElementById("loginBtn").addEventListener("click", async function () {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    if (username === "" || password === "") {
        alert("Preencha todos os campos!");
        return;
    }

    try {
        const formData = new FormData();
        formData.append("username", username);
        formData.append("password", password);

        const response = await fetch("verificar_login.php", {
            method: "POST",
            body: formData
        });

        const data = await response.json();

        if (data.status === "sucesso") {
            alert("Login realizado com sucesso!");
            window.location.href = "Tela_inicial.php"; // redireciona
        } else {
            alert(data.mensagem);
        }

    } catch (error) {
        alert("Erro ao conectar com o servidor.");
    }
});
</script>


</body>
