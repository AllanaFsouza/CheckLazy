<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$nomeUsuario = $_SESSION['usuario_nome'];

require_once 'conexao.php';

$usuario_id = $_SESSION['usuario_id'];

$stmt = $conn->prepare("SELECT nivel, xp, moedas, evolucao_recebida, skin_ativa, skins_compradas FROM usuarios WHERE id = ?");




$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $nivelUsuario = (int)$row['nivel'];
    $xpUsuario = (int)$row['xp'];
    $moedasUsuario = isset($row['moedas']) ? (int)$row['moedas'] : 0;
    $evolucaoRecebida = isset($row['evolucao_recebida']) ? (int)$row['evolucao_recebida'] : 0;
    $skinAtiva = $row['skin_ativa'] ?? "classica";
$skinsCompradas = $row['skins_compradas'] ? json_decode($row['skins_compradas'], true) : [];

} else {
    $nivelUsuario = 1;
    $xpUsuario = 0;
    $moedasUsuario = 0;
    $evolucaoRecebida = 0;
}




// Criar inicial automática
$inicial = strtoupper(substr($nomeUsuario, 0, 1));
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
<meta charset="UTF-8">
<title>CheckLazy</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>

:root { --roxo: #6C63FF; --roxo-claro: #E8E7FF; --cinza-fundo: #f8f9fd; --texto-principal: #333; --texto-secundario: #666; --branco: #ffffff; --borda: #f0f0f0; --ease-suave: cubic-bezier(0.4, 0, 0.2, 1); }

* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Lexend', sans-serif; }
body { background: var(--cinza); font-size: 18px; }
.app-container { display: flex; min-height: 100vh; }
.sidebar { width: 300px; background-color: var(--branco); padding: 30px 20px; display: flex; flex-direction: column; border-right: 1px solid var(--borda); }

.logo-section { display: flex; align-items: center; gap: 15px; margin-bottom: 40px; padding-left: 10px; }
.logo-icon { width: 50px; height: 50px; background-color: var(--roxo-claro); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px; }
.logo-text h2 { font-size: 24px; font-weight: 700; color: #000; line-height: 1; }
.logo-text span { font-size: 14px; color: var(--texto-secundario); }

.nav-menu { flex-grow: 1; display: flex; flex-direction: column; gap: 8px; }
.nav-link { display: flex; align-items: center; gap: 12px; padding: 14px 18px; text-decoration: none; color: var(--texto-principal); font-weight: 400; font-size: 16px; border-radius: 12px; transition: all 0.3s ease; }
.nav-link:hover { background-color: #f5f5f5; }
.nav-link.active { background-color: var(--roxo); color: var(--branco); font-weight: 600; }

.user-section {
    margin-top: auto;
    padding-top: 20px;
    border-top: 1px solid var(--borda);
    display: flex;
    flex-direction: column; /* 🔥 ESSENCIAL */
    gap: 14px;
}

.user-avatar { width: 45px; height: 45px; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 20px; color: var(--texto-principal); }
.user-info strong { display: block; font-size: 18px; color: #000; }
.user-info span { font-size: 14px; color: var(--texto-secundario); }

.main-content { flex-grow: 1; padding: 40px; color: #ccc; display: flex; align-items: center; justify-content: center; font-style: italic; }
.logo { display: flex; align-items: center; gap: 12px; margin-bottom: 30px; }
.logo-mascot { width: 48px; height: 48px; background: var(--roxo-claro); padding: 6px; border-radius: 12px; }
.menu a { display: block; padding: 12px; margin: 5px 0; border-radius: 10px; color: var(--texto); text-decoration: none; }
.menu a.active, .menu a:hover { background: var(--roxo); color: white; }
.user { border-top: 1px solid #eee; padding-top: 15px; display: flex; gap: 10px; }
.content { flex: 1; padding: 30px; background-color: var(--cinza-fundo); }

.header { display: flex; justify-content: space-between; align-items: center; }
.header-actions { display: flex; gap: 15px; align-items: center; }
.streak { padding: 8px 20px; border-radius: 20px; background: linear-gradient(135deg, #FFD56A, #FF9F43); color: white; font-weight: 600; animation-duration: 4s; }
.dark-mode { width: 42px; height: 42px; border-radius: 50%; background: white; border: 1px solid #ddd; cursor: pointer; animation: float-moon 4s ease-in-out infinite; animation-duration: 6s; }
.btn-primary { background: var(--roxo); color: white; border: none; padding: 12px 24px; border-radius: 12px; font-weight: 600; cursor: pointer; }

.cards { display: grid; grid-template-columns: repeat(3, 1fr); gap: 25px; margin: 30px 0; }
.card { background: white; padding: 22px 26px; border-radius: 24px; display: flex; gap: 18px; box-shadow: 0 10px 25px rgba(108,99,255,.12); }
.card-icon { width: 56px; height: 56px; border-radius: 18px; display: flex; align-items: center; justify-content: center; }
.concluida .card-icon { background: linear-gradient(135deg,#7f7bff,#6C63FF); color: white; }
.pendente .card-icon { background: linear-gradient(135deg,#FFD88A,#FFB703); color: white; }
.sequencia .card-icon { background: linear-gradient(135deg,#FFB347,#FF7A00); color: white; }
.card-text strong { font-size: 26px; }

.grid { display: grid; grid-template-columns: 2fr 1fr; gap: 40px; }
.tasks { background: white; padding: 20px; border-radius: 20px; }
.tasks header { display: flex; justify-content: space-between; margin-bottom: 20px; }
.task { display: flex; align-items: center; gap: 14px; }.task .badge { margin-left: auto; }
.alta .badge { background: #ffb3b3; }
.media .badge { background: #ffe0a3; }
.baixa .badge { background: #c8f2c8; }
.check { width: 26px; height: 26px; border-radius: 50%; border: 2px solid #ccc; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 16px; color: white; transition: all 0.3s ease; }.task.done { opacity: .6; }
.task.done .check { background: var(--roxo); border-color: var(--roxo); }
.task.done .check::after { content: "✓"; font-weight: bold; }
.task.done { opacity: 0.6; }
.task.done strong { text-decoration: line-through; }
.mascot { background: white; padding: 30px; border-radius: 20px; text-align: center; display: flex; flex-direction: column; align-items: center; gap: 14px; }
.mascot progress { width: 100%; height: 12px; border-radius: 10px; overflow: hidden; }
.mascot button { margin-top: 8px; width: 100%; }
button, .menu a, .card, .task, .check, .mascot { transition: transform 0.35s var(--ease-suave), box-shadow 0.35s var(--ease-suave), background-color 0.35s var(--ease-suave), filter 0.35s var(--ease-suave); }

.btn-primary:hover { transform: translateY(-2px) scale(1.015); box-shadow: 0 10px 22px rgba(108, 99, 255, 0.28); }
.dark-mode:hover { transform: scale(1.20) rotate(-15deg); background: var(--roxo-claro); }
.menu a:hover { transform: translateX(4px); }
.card:hover { transform: translateY(-4px); box-shadow: 0 14px 28px rgba(108, 99, 255, 0.18); }
.check:hover { border-color: var(--roxo); background: var(--roxo-claro); transform: scale(1.15); }
.mascot:hover { transform: translateY(-4px); box-shadow: 0 14px 30px rgba(0,0,0,0.12); }
button, .card { transition-delay: 0.03s; }

.task.alta:hover { background: linear-gradient(135deg, #ffe5e5, #ffb3b3);  transform: scale(1.01); }
.task.media:hover { background: linear-gradient(135deg, #fff3d6, #ffe0a3); transform: scale(1.01); }
.task.baixa:hover { background: linear-gradient(135deg, #e6f7e6, #c8f2c8); transform: scale(1.01); }

.streak { animation: pulse-streak 3s var(--ease-suave) infinite; }
@keyframes pulse-streak { 0% { transform: scale(1); box-shadow: 0 0 0 rgba(255, 159, 67, 0); } 50% { transform: scale(1.05); box-shadow: 0 10px 25px rgba(255, 159, 67, 0.45); } 100% { transform: scale(1); box-shadow: 0 0 0 rgba(255, 159, 67, 0); } }
@keyframes float-moon { 0% { transform: translateY(0); } 50% { transform: translateY(-4px); } 100% { transform: translateY(0); } }

@media (prefers-reduced-motion: reduce) { * { animation: none !important; transition: none !important; } }

.xp-container { width: 100%; display: flex; flex-direction: column; gap: 8px; }
.xp-info { display: flex; justify-content: space-between; font-size: 14px; color: var(--texto-secundario); }
.xp-bar { width: 100%; height: 14px; background: #eee; border-radius: 999px; overflow: hidden; }
.xp-fill { height: 100%; width: 0%; background: linear-gradient(135deg, #6C63FF, #9b94ff); border-radius: 999px; transition: width 1.2s var(--ease-suave); box-shadow: 0 0 12px rgba(108, 99, 255, 0.6); }

.level-up { position: fixed; inset: 0; background: rgba(108, 99, 255, 0.25); backdrop-filter: blur(6px); display: flex; align-items: center; justify-content: center; opacity: 0; pointer-events: none; z-index: 9999; transition: opacity 0.4s ease; }
.level-up.show { opacity: 1; pointer-events: all; }
.level-up-card { background: white; padding: 40px 50px; border-radius: 28px; text-align: center; box-shadow: 0 30px 60px rgba(108, 99, 255, 0.35); animation: popLevel 0.6s var(--ease-suave); }
.level-up-card h2 { font-size: 42px; color: var(--roxo); margin-bottom: 8px; }
.level-up-card p { font-size: 18px; color: var(--texto-secundario); }
.spark { display: inline-block; font-size: 32px; animation: sparkle 1.2s infinite; }

@keyframes popLevel { 0% { transform: scale(0.6); opacity: 0; } 60% { transform: scale(1.1); opacity: 1; } 100% { transform: scale(1); } }
@keyframes sparkle { 0%, 100% { transform: scale(1) rotate(0deg); } 50% { transform: scale(1.3) rotate(12deg); } }

@keyframes pop { 0% { transform: scale(0.6); } 60% { transform: scale(1.3); } 100% { transform: scale(1); } }
.task.done .check { background: var(--roxo); border-color: var(--roxo); animation: pop 0.3s ease; }
.task.done .check::after { content: "✓"; font-weight: bold; }

@keyframes unpop { 0% { transform: scale(1); } 100% { transform: scale(0.9); } }
.task:not(.done) .check { animation: unpop 0.15s ease; }

#confetti-container { position: fixed; inset: 0; pointer-events: none; overflow: hidden; z-index: 9999; }
.confetti { position: absolute; width: 8px; height: 14px; opacity: 0.9; animation: fall 1.2s ease-out forwards; }

@keyframes fall { from { transform: translateY(-20px) rotate(0deg); } to { transform: translateY(100vh) rotate(360deg); opacity: 0; } }

.modal { position: fixed; inset: 0; background: rgba(0,0,0,0.4); backdrop-filter: blur(4px); display: flex; align-items: center; justify-content: center; opacity: 0; pointer-events: none; transition: 0.3s ease; z-index: 9999; }
.modal.show { opacity: 1; pointer-events: all; }
.modal-card { background: white; padding: 30px; border-radius: 20px; width: 360px; display: flex; flex-direction: column; gap: 16px; animation: popLevel 0.4s ease; }
.modal-card label { display: flex; flex-direction: column; gap: 6px; font-size: 14px; }
.modal-card input { padding: 10px; border-radius: 10px; border: 1px solid #ddd; font-size: 14px; }
.modal-actions { display: flex; justify-content: flex-end; gap: 10px; }
.modal-actions button { padding: 10px 16px; border-radius: 10px; border: none; cursor: pointer; }

#empty-tasks { color: var(--texto-secundario); font-size: 16px; opacity: 0.8; display: flex; align-items: center; justify-content: center; height: 180px; text-align: center; }
    
#form-error { display: none; color: #ff6b6b; background: #ffecec; padding: 10px 14px; border-radius: 10px; font-size: 14px; text-align: center; animation: pop 0.3s ease; }    

.delete-task { margin-left: auto; cursor: pointer; opacity: 0; transition: opacity 0.3s ease, transform 0.3s ease; }
.task:hover .delete-task { opacity: 1; transform: scale(1.1); }
.task-actions { margin-left: auto; display: flex; align-items: center; gap: 10px; }  
.delete-task { cursor: pointer; opacity: 0; transition: opacity 0.25s ease, transform 0.25s ease; }
.task:hover .delete-task { opacity: 1; transform: scale(1.15); }

.task { display: flex; align-items: center; gap: 14px; background: var(--cinza); padding: 15px; border-radius: 14px; margin-bottom: 10px; transition: transform 0.35s var(--ease-suave), box-shadow 0.35s var(--ease-suave), background-color 0.35s var(--ease-suave); }
.task .badge { margin-left: auto; }

.alta .badge { background: #ffb3b3; }
.media .badge { background: #ffe0a3; }
.baixa .badge { background: #c8f2c8; }

.check { width: 26px; height: 26px; border-radius: 50%; border: 2px solid #ccc; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 16px; color: white; transition: all 0.3s ease; }
.menu-toggle {
    display: none;
}

.task.done { opacity: 0.6; }
.task.done strong { text-decoration: line-through; }
.task.done .check { background: var(--roxo); border-color: var(--roxo); }
.task.done .check::after { content: "✓"; font-weight: bold; }

.task.alta:hover { background: linear-gradient(135deg, #ffe5e5, #ffb3b3); transform: scale(1.01); }
.task.media:hover { background: linear-gradient(135deg, #fff3d6, #ffe0a3); transform: scale(1.01); }
.task.baixa:hover { background: linear-gradient(135deg, #e6f7e6, #c8f2c8); transform: scale(1.01); }

.badge { padding: 3px 8px; border-radius: 14px; font-size: 11px; font-weight: 600; line-height: 1; }

@keyframes float-preguica { 0% { transform: translateY(0); } 50% { transform: translateY(-15px); } 100% { transform: translateY(0); } }
.mascot img { animation: float-preguica 3s ease-in-out infinite; }

body.dark { --roxo: #9B8CFF; --roxo-claro: #4a3fff; --cinza: #1e1e2f; --texto: #ffffff; --branco: #2c2c3c; }
body.dark .sidebar { background: var(--branco); color: var(--texto); }
body.dark .menu a { color: var(--texto); }
body.dark .menu a.active, body.dark .menu a:hover { background: var(--roxo); color: white; }
body.dark .header { background: var(--branco); color: var(--texto); }
body.dark .header h1, body.dark .header p { color: var(--texto); }
body.dark .kanban-column { background: var(--branco); color: var(--texto); }
body.dark .kanban-column h3 { color: var(--texto); }
body.dark .kanban-card { background: var(--cinza); color: var(--texto); }
body.dark .kanban-card p, body.dark .kanban-card strong { color: var(--texto); }
body.dark .add-task-form input, body.dark .add-task-form textarea, body.dark .add-task-form select { background: #3a3a4c; color: var(--texto); border: 1px solid #555; }
body.dark .add-task-form button#createTask { color: white; background: linear-gradient(135deg, #8e7fff, #6C63FF); }
body.dark .footer { background: linear-gradient(135deg, #4a3fff, #6C63FF); color: white; }
body.dark .footer-decor { background: rgba(255,255,255,0.5); }

body.dark { --roxo: #9B8CFF; --roxo-claro: #4a3fff; --cinza-fundo: #1e1e2f; --cinza: #2a2a3b; --texto-principal: #ffffff; --texto-secundario: #cccccc; --branco: #2c2c3c; --borda: #444; }
body.dark .sidebar { background-color: var(--branco); color: var(--texto-principal); border-right: 1px solid var(--borda); }
body.dark .menu a { color: var(--texto-principal); }
body.dark .menu a.active, body.dark .menu a:hover { background-color: var(--roxo); color: var(--branco); }
body.dark .header { background-color: var(--branco); color: var(--texto-principal); }
body.dark .header h1, body.dark .header p { color: var(--texto-principal); }
body.dark .cards .card { background-color: var(--branco); color: var(--texto-principal); }
body.dark .tasks { background-color: var(--branco); color: var(--texto-principal); }
body.dark .task { background-color: var(--cinza); color: var(--texto-principal); }
body.dark .task .badge { color: var(--texto-principal); }
body.dark .xp-bar { background-color: #444; }
body.dark .xp-fill { box-shadow: 0 0 12px rgba(155, 140, 255, 0.6); }
body.dark .mascot { background-color: var(--branco); color: var(--texto-principal); }
body.dark .btn-primary { background: var(--roxo); color: var(--branco); }
body.dark .modal-card { background-color: var(--branco); color: var(--texto-principal); }
body.dark #task-modal input, body.dark #task-modal select { background-color: #3a3a4c; color: var(--texto-principal); border: 1px solid #555; }

.logout-btn { width: 100%; padding: 14px 16px; border-radius: 14px; border: none; background: #f2f3f7; color: #555; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.25s ease; }
.logout-btn:hover { background: linear-gradient(135deg, #6C63FF, #8e7fff); color: white; }
.logout-btn:active { transform: scale(0.98); }
body.dark .logout-btn { background: #2f2f40; color: #ddd; }
body.dark .logout-btn:hover { background: #3a3a4c; color: #fff; }

.dark-mode {transition: transform 0.4s ease;}
.dark-mode:hover {transform: rotate(20deg) scale(1.1);}
.delete-task:hover {transform: rotate(10deg) scale(1.2);opacity: 1;}

body.dark .btn-primary.btn-link {box-shadow: 0 8px 22px rgba(155,140,255,0.4);}
#skins-modal .modal-card::-webkit-scrollbar {
    width: 6px;
}
#skins-modal .modal-card::-webkit-scrollbar-thumb {
    background: #ccc;
    border-radius: 10px;
}
.btn-tab {
    border: none;
    background: none;
    padding: 8px 20px;
    border-radius: 20px;
    cursor: pointer;
    font-weight: 600;
    transition: 0.3s;
    color: var(--texto-secundario);
}
.active-tab {
    background: var(--roxo);
    color: white !important;
}

.timeline-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 20px;
    background: #f8f9fd;
    border-radius: 18px;
    border: 1px solid #eee;
}

.active-row {
    background: #f0edff !important;
    border: 2px solid var(--roxo) !important;
}

.timeline-left {
    display: flex;
    align-items: center;
    gap: 15px;
}

.circle-check {
    width: 32px;
    height: 32px;
    background: var(--roxo);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 14px;
    flex-shrink: 0;
}

.t-title {
    margin: 0;
    font-size: 15px;
    font-weight: bold;
    color: #333;
}

.t-desc {
    margin: 0;
    font-size: 12px;
    color: #888;
}

.t-xp {
    font-size: 13px;
    color: #999;
}
.skin-card {
    border: 1px solid #eee;
    border-radius: 20px;
    padding: 15px;
    text-align: center;
    position: relative;
    background: white;
    transition: transform 0.2s ease;
}
#content-loja {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.skin-card:hover { transform: translateY(-3px); }

.equipped { border: 2px solid var(--roxo); background: #fbfaff; }

.rarity-tag {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 10px;
    font-weight: bold;
    padding: 2px 8px;
    border-radius: 10px;
    background: #eee;
}

.rarity-rara { background: #e0f2ff; color: #007bff; }
.rarity-epica { background: #f3e5f5; color: #9c27b0; }
.rarity-lendaria { background: #fff3e0; color: #ff9800; }

.skin-desc { font-size: 11px; color: #888; margin: 8px 0; min-height: 25px; }

.btn-buy {
    width: 100%;
    padding: 10px;
    border-radius: 12px;
    border: none;
    background: var(--roxo);
    color: white;
    font-weight: bold;
    cursor: pointer;
    font-size: 13px;
}

.avatar {
    width: 36px;
    height: 36px;
    background: var(--roxo);   /* 🔥 AQUI define a cor roxa */
    color: white;
    border-radius: 50%;        /* 🔥 ISSO transforma em círculo */
    display: flex;
    justify-content: center;
    align-items: center;
}
.task.done .check {
    pointer-events: none;
    opacity: 0.7;
    cursor: not-allowed;
}
/* Estilos do modo escuro específicos para a seção de skins e evolução */
#content-evolucoes.dark,
#content-loja.dark {
    background-color: #2a2a3b; /* Cor de fundo mais escura para o modo noturno */
    color: #ddd; /* Texto claro */
}

#content-evolucoes.dark .skin-card,
#content-loja.dark .skin-card {
    background-color: #333; /* Fundo das cartas mais escuras */
    border: 1px solid #444; /* Borda sutil */
}

#content-evolucoes.dark .rarity-tag,
#content-loja.dark .rarity-tag {
    background-color: #555; /* Cor de fundo das tags de raridade */
    color: #fff; /* Cor do texto das tags */
}

#content-evolucoes.dark .btn-buy,
#content-loja.dark .btn-buy {
    background-color: #4a3fff; /* Botões com fundo roxo mais escuro */
    color: white;
}

#content-evolucoes.dark .btn-buy:hover,
#content-loja.dark .btn-buy:hover {
    background-color: #6C63FF; /* Efeito de hover mais claro */
}

#content-evolucoes.dark .skin-desc,
#content-loja.dark .skin-desc {
    color: #ccc; /* Cor do texto da descrição mais clara */
}

/* Outros ajustes para a área de evolução e loja para se adaptar ao modo escuro */
#content-evolucoes.dark .timeline-row,
#content-loja.dark .skin-card {
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15); /* Efeito de sombra para cartas */
}
/* Tema escuro: Cards de skins */
body.dark .skin-card {
    background-color: #2a2a3b; /* Ajuste do fundo para um tom mais escuro */
    color: #ddd; /* Texto claro */
    border: 1px solid #444; /* Borda mais visível */
}

/* Ajustes no título das skins */
body.dark .skin-card h4 {
    color: #fff; /* Texto branco */
}

/* Aplique ao botão de compra de skins */
body.dark .btn-buy {
    background-color: var(--roxo); /* Cor de fundo roxa */
    color: #fff; /* Texto branco */
    border: none;
}

/* Altere o texto de descrição das skins */
body.dark .skin-desc {
    color: #bbb; /* Texto mais claro */
}

/* Modificação no botão de "equipar" de skins */
body.dark .btn-buy[disabled] {
    background-color: #444; /* Fundo mais escuro quando desabilitado */
    color: #666; /* Cor do texto desabilitado */
}

/* Atualização da linha do tempo de evolução */
body.dark .timeline-row {
    background-color: #333; /* Linha do tempo com fundo mais escuro */
    border-color: #444; /* Borda mais visível */
    color: #fff; /* Texto claro */
}

/* Modificação nos círculos de evolução */
body.dark .circle-check {
    background-color: var(--roxo); /* Cor de fundo do círculo de check */
    color: white; /* Cor do texto no círculo */
}

/* Alteração no texto de descrições das evoluções */
body.dark .t-desc {
    color: #aaa; /* Texto claro */
}

/* Alterações nas abas de evolução e loja */
body.dark .btn-tab {
    color: #bbb; /* Cor do texto nas abas */
    background-color: #333; /* Fundo mais escuro das abas */
}

/* Ajustes no botão de "Ver Skins & Evolução" */
body.dark .btn-primary {
    background-color: var(--roxo); /* Cor de fundo do botão */
    color: #fff; /* Texto branco */
}

/* Alteração no modal de skins para modo escuro */
body.dark #skins-modal .modal-card {
    background-color: #2a2a3b; /* Fundo escuro */
    color: #ddd; /* Texto claro */
}

/* Modificação do conteúdo do modal */
body.dark #skins-modal h2 {
    color: var(--roxo); /* Cor do título em roxo */
}

body.dark #skins-modal p {
    color: #bbb; /* Cor de descrição mais clara */
}

/* Alterações no texto de moedas no modal */
body.dark #moedas-display {
    color: #ffd700; /* Moedas em dourado */
}
.evolucao-card {
    background: white;
    border: 1px solid #eee;
    border-radius: 20px;
    padding: 20px;
    display: flex;
    gap: 15px;
    align-items: center;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    margin-bottom: 25px;
}
body.dark .evolucao-card {
    background: #2a2a3b;
    border-color: #444;
}
/* ============================= */
/* 📱 RESPONSIVIDADE TABLET */
/* ============================= */

@media (max-width: 1024px) {

    .cards {
        grid-template-columns: repeat(2, 1fr);
    }

    .grid,
    #content-loja {
        grid-template-columns: 1fr;
        gap: 25px;
    }
}

/* ============================= */
/* 📱 MOBILE (até 768px) */
/* ============================= */

@media (max-width: 768px) {

    body {
        font-size: 16px;
    }

    /* Layout principal */
    .app-container {
        flex-direction: row;
    }

    /* ================= SIDEBAR ================= */

    .sidebar {
        position: fixed;
        top: 0;
        left: -100%;
        height: 100vh;
        width: 270px;
        border: none;
        padding: 20px;
        transition: left 0.3s ease;
        z-index: 9999;
        box-shadow: 4px 0 25px rgba(0,0,0,0.2);
    }

    .sidebar.active {
        left: 0;
    }

    /* ================= HEADER ================= */

    .header {
        display: grid;
        grid-template-columns: 1fr auto auto;
        grid-template-rows: auto auto;
        align-items: center;
        gap: 6px 10px;
    }

    .header-left {
        grid-column: 1 / 2;
        grid-row: 1 / 2;
    }

    /* BOTÃO MODO NOTURNO (VISÍVEL) */
    .dark-mode {
        grid-column: 2 / 3;
        grid-row: 1 / 2;
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    /* MENU HAMBURGUER */
    .menu-toggle {
        display: block;
        grid-column: 3 / 4;
        grid-row: 1 / 2;
        background: var(--roxo);
        color: white;
        border: none;
        font-size: 22px;
        width: 44px;
        height: 44px;
        border-radius: 12px;
        cursor: pointer;
        z-index: 11000;
    }

    /* BOTÃO NOVA TAREFA */
    .header-actions {
        grid-column: 2 / 4;
        grid-row: 2 / 3;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }

    .btn-primary {
        padding: 8px 12px;
        font-size: 13px;
        white-space: nowrap;
    }

    /* ================= CARDS ================= */

    .cards {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 10px;
    }

    .card {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 10px;
        text-align: center;
    }

    .task {
        flex-wrap: wrap;
        gap: 10px;
    }

    .task-actions {
        width: 100%;
        justify-content: flex-end;
    }

    .modal-card {
        width: 95%;
    }

    .evolucao-card,
    .timeline-row {
        flex-direction: column;
        text-align: center;
        gap: 10px;
    }

    /* Overlay */
    .overlay {
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.4);
        opacity: 0;
        pointer-events: none;
        transition: 0.3s ease;
        z-index: 9998;
    }

    .overlay.show {
        opacity: 1;
        pointer-events: all;
    }
}

/* ============================= */
/* 📱 MOBILE PEQUENO (480px) */
/* ============================= */

@media (max-width: 480px) {

    .header-actions {
        flex-direction: row;
        gap: 6px;
        justify-content: flex-end;
        width: 100%;
    }
}
@media (max-width: 768px) {

    .menu-toggle {
        display: block;
        grid-column: 3 / 4;
        grid-row: 1 / 2;
        background: var(--roxo);
        color: white;
        border: none;
        font-size: 22px;
        width: 44px;
        height: 44px;
        border-radius: 12px;
        cursor: pointer;
        z-index: 11000;
    }



}


</style>
</head>

<body>

<div class="app-container">
    <div class="overlay"></div>

<aside class="sidebar">
<div><div class="logo"><img src="LogoCheckLazy.png" class="logo-mascot"><div><h2>CheckLazy</h2><span>Devagar e sempre!</span></div></div>
<nav class="menu"><a class="active" href="Tela_inicial.php">📊 Dashboard</a><a href="Tarefas.php">📋 Tarefas</a><a href="Kanban.php">🗂 Kanban</a><a href="Calendario.php">📅 Calendário</a><a href="Progresso.php">📈 Progresso</a><a href="Configuracoes.php">⚙️ Configurações</a></nav>
</div>

<div class="user-section">
    <div style="display: flex; align-items: center; gap: 12px;">
        <div class="avatar"><?php echo $inicial; ?></div>
        <div>
            <strong><?php echo htmlspecialchars($nomeUsuario); ?></strong>
            <br>
            <small>Nível <?php echo $nivelUsuario; ?></small>
        </div>
    </div>

    <button class="logout-btn">⎋ Sair</button>
</div>



</aside> <main class="content">
  <header class="header">

    <div class="header-left">
         

        <div>
            <h1>Dashboard!</h1>
            <p>Confira algumas tarefas de hoje.</p>
          
        </div>
       
    </div>
    <button class="menu-toggle">☰</button>

<div class="header-actions">
    <button class="dark-mode">🌙</button>
    <button class="btn-primary">+ Nova Tarefa</button>
</div>


</header>



<section class="cards">
<div class="card concluida"><div class="card-icon">✔️</div><div class="card-text"><strong class="count">0</strong><p>Concluídas</p></div></div>
<div class="card pendente"><div class="card-icon">⏳</div><div class="card-text"><strong>0</strong><p>Pendentes</p></div></div>

<div class="card sequencia"><div class="card-icon">🔥</div><div class="card-text"><strong>0 dias</strong><p>Sequência</p></div></div>
</section>

<section class="grid">
<div class="tasks"><header><h2>Tarefas prioritárias</h2><a href="Tarefas.php">Ver todas</a></header><ul id="task-list"></ul><p id="empty-tasks">Nenhuma tarefa ainda 🐌...</p></div>
<aside class="mascot"><?php
$imagemSkin = "imagens/normal.png";

if ($skinAtiva == "ninja") {
    $imagemSkin = "imagens/ninja.png";
} elseif ($skinAtiva == "dourada") {
    $imagemSkin = "imagens/dourada.png";
} elseif ($skinAtiva == "cosmica") {
    $imagemSkin = "imagens/cosmica.png";
}

?>

<img src="<?php echo $imagemSkin; ?>" width="80">
<h4>Preguicinha</h4><p>Preguiça Ágil</p><div class="xp-container"><div class="xp-info"><span>Nível <strong id="level">0</strong></span>
<span><strong id="xp-current">0</strong> / <span id="xp-max">700</span> XP</span>
</div>

<div class="xp-bar">
<div class="xp-fill" id="xp-fill"></div>
</div>
</div>

<button class="btn-primary">Ver Skins & Evolução</button>
</aside>
</section>
</main>
</div>

<div id="level-up" class="level-up">
<div class="level-up-card"><span class="spark">✨</span><h2>LEVEL UP!</h2><p>Você alcançou o nível <strong id="level-up-number"></strong></p></div>
</div>

<div id="confetti-container"></div>
<div id="task-modal" class="modal"><div class="modal-card"><p id="form-error">Preencha todos os campos 🐌</p><h2>Nova Tarefa</h2><label>Nome da tarefa<input type="text" id="task-name" placeholder="Ex: Estudar JS"></label><label>Prazo<input type="date" id="task-date"></label>

<div class="modal-actions">
<button id="cancel-task">Cancelar</button><button class="btn-primary" id="save-task">Adicionar</button></div></div>
</div>

<div id="delete-modal" class="modal">
<div class="modal-card"><p>Deseja realmente excluir esta tarefa? 🐌</p><div class="modal-actions"><button id="cancel-delete">Cancelar</button><button id="confirm-delete" class="btn-primary">Excluir</button></div></div>
</div>

<div id="logout-modal" class="modal"><div class="modal-card"><h2>Sair da conta</h2><p>Deseja realmente encerrar sua sessão? 🐌</p>
<div class="modal-actions"><button id="cancel-logout">Cancelar</button><button id="confirm-logout" class="btn-primary">Sair</button></div></div>
</div>
<div id="skins-modal" class="modal">
    <div class="modal-card" style="width: 550px; max-height: 90vh; overflow-y: auto;">
        <div style="display: flex; justify-content: space-between; align-items: start;">
            <div>
                <h2 style="color: var(--roxo); margin: 0;">Preguicinha Evolution</h2>
                <p style="font-size: 13px; color: var(--texto-secundario);">Evolua seu mascote e desbloqueie skins exclusivas!</p>
            </div>
            <button id="close-skins" style="background:none; border:none; font-size:24px; cursor:pointer;">&times;</button>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; margin: 20px 0;">
            <div class="tabs" style="display: flex; gap: 10px; background: #eee; padding: 5px; border-radius: 25px;">
                <button id="tab-evolucoes" class="btn-tab active-tab">Evolução</button>
                <button id="tab-loja" class="btn-tab">Loja de Skins</button>
            </div>
            <span id="moedas-display" style="color: #d4a017; font-weight: bold;">✨ <?php echo $moedasUsuario; ?> moedas
</span>
        </div>

       <div id="content-evolucoes">
    <div style=" border: 1px solid #eee; border-radius: 20px; padding: 20px; display: flex; gap: 15px; align-items: center; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-bottom: 25px;">
        <img src="LogoCheckLazy.png" width="70">
        <div style="flex: 1;">
            <div style="display: flex; gap: 10px; align-items: center;">
              <h3 style="margin:0; color: #333;">
    Nível <?php echo $nivelUsuario; ?>
</h3>

                <span class="badge" style="background: var(--roxo-claro); color: var(--roxo); padding: 2px 8px; border-radius: 10px; font-size: 12px;">Preguiça Ágil</span>
            </div>
            <?php
$maxXPUsuario = 300;
$percentXP = min(100, ($xpUsuario / $maxXPUsuario) * 100);
?>

<div class="xp-bar" style="height: 10px; margin: 10px 0; background: #eee; border-radius: 5px; overflow: hidden;">
    <div class="xp-fill" 
         style="width: <?php echo $percentXP; ?>%; height: 100%; background: var(--roxo);">
    </div>
</div>

<div style="display: flex; justify-content: space-between; font-size: 12px; color: #888;">
    <span><?php echo $xpUsuario; ?> XP</span>
    <span><?php echo $maxXPUsuario; ?> XP</span>
</div>

        </div>
    </div>

    <h4 style="margin: 20px 0 10px; color: #333;">Linha do Tempo da Evolução</h4>
    
    <div class="timeline-container" style="display: flex; flex-direction: column; gap: 12px;">
        
        <?php
$evolucoes = [
    ["nome" => "Preguiça Sonolenta", "desc" => "Acesso básico", "min" => 1, "max" => 2],
    ["nome" => "Preguiça Desperta", "desc" => "Modo escuro", "min" => 3, "max" => 4],
    ["nome" => "Preguiça Focada", "desc" => "Estatísticas avançadas", "min" => 5, "max" => 6],
    ["nome" => "Preguiça Produtiva", "desc" => "Grupos ilimitados", "min" => 7, "max" => 8],
    ["nome" => "Preguiça Ágil", "desc" => "Loja de skins", "min" => 9, "max" => 10],
];

foreach ($evolucoes as $e) {

    $ativa = ($nivelUsuario >= $e["min"] && $nivelUsuario <= $e["max"]);
    $concluida = ($nivelUsuario > $e["max"]);

    echo '<div class="timeline-row ' . ($ativa ? 'active-row' : '') . '">';
    echo '<div class="timeline-left">';

    if ($concluida || $ativa) {
        echo '<div class="circle-check">✓</div>';
    } else {
        echo '<div class="circle-check" style="background:#ccc;">•</div>';
    }

    echo '<div>';
    echo '<p class="t-title">' . $e["nome"] . '</p>';
 echo '<p class="t-desc">' . $e["desc"] . ' • 🎁 +50 moedas</p>';

    echo '</div></div>';

    echo '<span class="t-xp';
    if ($ativa) echo '" style="color: var(--roxo); font-weight:bold;';
    echo '">';
    echo 'Nível ' . $e["min"] . ' - ' . $e["max"];
    echo '</span>';

    echo '</div>';
}
?>
       </div> <!-- FECHA content-evolucoes -->
</div> <!-- FECHA content-evolucoes -->


<div id="content-loja" style="display: none;">

    <!-- Clássica -->
    <?php
$comprada = true; // A Clássica sempre é comprada
$equipada = ($skinAtiva == "classica");
?>
<div class="skin-card <?php echo $equipada ? 'equipped' : ''; ?>">
    <span class="rarity-tag">Comum</span>
    <img src="imagens/normal.png" width="80"
         style="<?php echo !$comprada ? 'filter: grayscale(1); opacity: 0.5;' : ''; ?>">

    <h4>☆ Clássica</h4>
    <p class="skin-desc">A preguiça original, sempre simpática!</p>

    <?php if ($equipada): ?>
        <button class="btn-buy" disabled>✓ Equipada</button>
    <?php elseif ($comprada): ?>
        <button class="btn-buy owned" data-skin="classica">✓ Equipar</button>
    <?php else: ?>
        <button class="btn-buy" data-skin="classica" data-preco="0">✨ 0 moedas</button>
    <?php endif; ?>
</div>


<!-- Ninja -->
    <?php
    $comprada = in_array("ninja", $skinsCompradas);
    $equipada = ($skinAtiva == "ninja");
    ?>
   <div class="skin-card <?php echo $equipada ? 'equipped' : ''; ?>">
    <span class="rarity-tag rarity-rara">Rara</span>

       <img src="imagens/ninja.png" width="80"
     style="<?php echo !$comprada ? 'filter: grayscale(1); opacity: 0.5;' : ''; ?>">

        <h4>⚔️ Ninja Noturna</h4>
        <p class="skin-desc">Mova-se nas sombras e conclua tarefas como um verdadeiro ninja.</p>

        <?php if ($equipada): ?>
            <button class="btn-buy" disabled>✓ Equipada</button>
        <?php elseif ($comprada): ?>
            <button class="btn-buy owned" data-skin="ninja">✓ Equipar</button>
        <?php else: ?>
            <button class="btn-buy" data-skin="ninja" data-preco="50">✨ 50 moedas</button>
        <?php endif; ?>
    </div>

    <!-- Dourada -->
    <?php
    $comprada = in_array("dourada", $skinsCompradas);
    $equipada = ($skinAtiva == "dourada");
    ?>
    <div class="skin-card <?php echo $equipada ? 'equipped' : ''; ?>">
        <span class="rarity-tag rarity-epica">Épica</span>
      <img src="imagens/dourada.png" width="80"
     style="<?php echo !$comprada ? 'filter: grayscale(1); opacity: 0.5;' : ''; ?>">

        <h4>👑 Dourada Real</h4>
        <p class="skin-desc">Brilhe como o sol ao completar tarefas!</p>

        <?php if ($equipada): ?>
            <button class="btn-buy" disabled>✓ Equipada</button>
        <?php elseif ($comprada): ?>
            <button class="btn-buy owned" data-skin="dourada">✓ Equipar</button>
        <?php else: ?>
            <button class="btn-buy" data-skin="dourada" data-preco="80">✨ 80 moedas</button>
        <?php endif; ?>
    </div>

    <!-- Cósmica -->
    <?php
    $comprada = in_array("cosmica", $skinsCompradas);
    $equipada = ($skinAtiva == "cosmica");
    ?>
    <div class="skin-card <?php echo $equipada ? 'equipped' : ''; ?>">
        <span class="rarity-tag rarity-lendaria">Lendária</span>
       <img src="imagens/cosmica.png" width="80"
     style="<?php echo !$comprada ? 'filter: grayscale(1); opacity: 0.5;' : ''; ?>">

        <h4>✨ Cósmica</h4>
        <p class="skin-desc">Poder das estrelas para produtividade!</p>

        <?php if ($equipada): ?>
            <button class="btn-buy" disabled>✓ Equipada</button>
        <?php elseif ($comprada): ?>
            <button class="btn-buy owned" data-skin="cosmica">✓ Equipar</button>
        <?php else: ?>
            <button class="btn-buy" data-skin="cosmica" data-preco="120">✨ 120 moedas</button>
        <?php endif; ?>
    </div>

</div> <!-- FECHA content-loja -->

    </div>
</div>
<script>
document.querySelectorAll('.btn-buy').forEach(btn => {

    btn.addEventListener('click', () => {

        const skin = btn.dataset.skin;
        const preco = parseInt(btn.dataset.preco);

        // Se já comprada → equipar
        if (btn.classList.contains('owned')) {
            equiparSkin(skin);
            return;
        }

        fetch("comprar_skin.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ skin: skin, preco: preco })
        })
        .then(res => res.json())
        .then(data => {

            if (data.status === "sucesso") {

                document.getElementById("moedas-display").innerHTML =
                    "✨ " + data.moedas + " moedas";

                btn.textContent = "✓ Equipar";
                btn.classList.add("owned");

                alert("Skin comprada! ✨");

            } else {
                alert(data.mensagem);
            }

        });

    });

});

function equiparSkin(skin) {

    fetch("equipar_skin.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ skin: skin })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === "sucesso") {
            alert("Skin equipada! 🐌✨");
            location.reload();
        }
    });

}
</script>

</body>
<script>
const logoutBtn = document.querySelector('.logout-btn');
const logoutModal = document.getElementById('logout-modal');
const cancelLogout = document.getElementById('cancel-logout');
const confirmLogout = document.getElementById('confirm-logout');

logoutBtn.addEventListener('click', () => {logoutModal.classList.add('show');});
cancelLogout.addEventListener('click', () => {logoutModal.classList.remove('show');});
confirmLogout.addEventListener('click', () => {window.location.href = 'logout.php';});
</script>

<script>
let level = <?php echo $nivelUsuario; ?>;
let currentXP = <?php echo $xpUsuario; ?>;

// regra de crescimento igual você usa no level up
let maxXP = Math.round(100 * Math.pow(1.15, level - 1));
const levelEl = document.getElementById('level');const xpCurrentEl = document.getElementById('xp-current');const xpMaxEl = document.getElementById('xp-max');const xpFillEl = document.getElementById('xp-fill');

function updateXP() {const percent = (currentXP / maxXP) * 100;xpFillEl.style.width = percent + '%';levelEl.textContent = level;xpCurrentEl.textContent = currentXP;xpMaxEl.textContent = maxXP;}
window.addEventListener('load', () => {setTimeout(updateXP, 300);});

document.querySelectorAll('.check').forEach(check => {
check.addEventListener('click', () => {
const task = check.closest('.task');
task.classList.toggle('done');
if (!task.dataset.xpGiven && task.classList.contains('done')) {
let xpGain = 25;
if (task.classList.contains('alta')) xpGain = 40;
if (task.classList.contains('media')) xpGain = 25;
if (task.classList.contains('baixa')) xpGain = 15;
currentXP += xpGain;
if (currentXP >= maxXP) {
currentXP -= maxXP;
level++;
maxXP = Math.round(maxXP * 1.15);
launchConfetti();
showLevelUp(level);
}

task.dataset.xpGiven = "true";
updateXP();
}
});
});

function showLevelUp(newLevel) {
const overlay = document.getElementById('level-up');
const levelText = document.getElementById('level-up-number');
levelText.textContent = newLevel;
overlay.classList.add('show');
setTimeout(() => {overlay.classList.remove('show');}, 2200);
}
</script>

<script>
function launchConfetti() {
const container = document.getElementById('confetti-container');
for (let i = 0; i < 40; i++) {
const confetti = document.createElement('div');
confetti.classList.add('confetti');
confetti.style.left = Math.random() * 100 + 'vw';
confetti.style.backgroundColor = ['#6C63FF', '#FFD56A', '#FF9F43', '#7f7bff'][Math.floor(Math.random() * 4)];
confetti.style.animationDuration = (0.8 + Math.random()) + 's';
container.appendChild(confetti);
setTimeout(() => confetti.remove(), 1500);
}
}
</script>

<script>
const modal = document.getElementById('task-modal');const btnNewTask = document.querySelector('.btn-primary');const btnCancel = document.getElementById('cancel-task');const btnSave = document.getElementById('save-task');const taskList = document.querySelector('.tasks ul');const deleteModal = document.getElementById('delete-modal');const btnCancelDelete = document.getElementById('cancel-delete');
const btnConfirmDelete = document.getElementById('confirm-delete');const countConcluidas = document.querySelector('.card.concluida .count');const countPendentes = document.querySelector('.card.pendente .card-text strong');const emptyMessage = document.getElementById('empty-tasks');
let taskToDelete = null; 

btnNewTask.addEventListener('click', () => modal.classList.add('show'));
btnCancel.addEventListener('click', () => modal.classList.remove('show'));

btnCancelDelete.addEventListener('click', () => {
deleteModal.classList.remove('show');
taskToDelete = null;
});

btnConfirmDelete.addEventListener('click', () => {
    if (taskToDelete) {

        taskToDelete.remove();

        updateTaskCounts();
        toggleEmptyMessage();

        saveTasksToDatabase(); // <-- ESSENCIAL

        deleteModal.classList.remove('show');
        taskToDelete = null;
    }
});



function toggleEmptyMessage() {
emptyMessage.style.display = taskList.children.length === 0 ? 'flex' : 'none';
}

function updateTaskCounts() {
const tasks = Array.from(taskList.children);
const concluidas = tasks.filter(t => t.classList.contains('done')).length;
const pendentes = tasks.filter(t => !t.classList.contains('done')).length;
countConcluidas.textContent = concluidas;
countPendentes.textContent = pendentes;
}

function getPriority(dateValue) {

    const hoje = new Date();
    const ano = hoje.getFullYear();
    const mes = String(hoje.getMonth() + 1).padStart(2, "0");
    const dia = String(hoje.getDate()).padStart(2, "0");

    const hojeString = `${ano}-${mes}-${dia}`;

    if (dateValue === hojeString) return 'alta';

    if (dateValue > hojeString) {

        // diferença simples para saber se é amanhã
        const hojeDate = new Date(hojeString);
        const taskDate = new Date(dateValue);
        const diff = (taskDate - hojeDate) / (1000 * 60 * 60 * 24);

        if (diff === 1) return 'media';

        return 'baixa';
    }

    return 'baixa';
}


function insertTaskByPriority(taskElement, priority) {
const tasks = Array.from(taskList.children);
if (priority === 'alta') {taskList.prepend(taskElement);return;}
if (priority === 'media') {
const lastHigh = tasks.filter(t => t.classList.contains('alta')).pop();
lastHigh ? lastHigh.after(taskElement) : taskList.prepend(taskElement);
return;
}
taskList.append(taskElement);
}

function addTask(name, priority) {
    const li = document.createElement('li');
    li.className = `task ${priority}`;

    const priorityLabel =
        priority === 'alta' ? 'Alta' :
        priority === 'media' ? 'Média' : 'Baixa';

    li.innerHTML = `
        <span class="check"></span>
        <strong>${name}</strong>
        <div class="task-actions">
            <span class="badge">${priorityLabel}</span>
            <span class="delete-task">🗑️</span>
        </div>
    `;

    insertTaskByPriority(li, priority);
    toggleEmptyMessage();
    updateTaskCounts();

    // evento de concluir
    li.querySelector('.check').addEventListener('click', () => {
        if (li.classList.contains('done')) return;

        let xpValue = 25;
        if (priority === 'alta') xpValue = 40;
        if (priority === 'media') xpValue = 25;
        if (priority === 'baixa') xpValue = 15;

        li.classList.add('done');

        currentXP += xpValue;

        if (currentXP >= maxXP) {
            currentXP -= maxXP;
            level++;
            maxXP = Math.round(maxXP * 1.15);
            launchConfetti();
            showLevelUp(level);
            verificarNovaEvolucao();
        }

        updateXP();
        updateTaskCounts();
        salvarXP();
        saveTasksToDatabase();
    });

    // delete
    li.querySelector('.delete-task').addEventListener('click', e => {
        e.stopPropagation();
        taskToDelete = li;
        deleteModal.classList.add('show');
    });

    return li; // 🔥 ESSENCIAL
}


btnSave.addEventListener('click', () => {

    const name = document.getElementById('task-name').value.trim();
    const date = document.getElementById('task-date').value.trim();
    const error = document.getElementById('form-error');

    if (!name || !date) {
        error.style.display = 'block';
        return;
    }

    // 🔥 VALIDAÇÃO REAL DA DATA
    const hoje = new Date();
    const ano = hoje.getFullYear();
    const mes = String(hoje.getMonth() + 1).padStart(2, "0");
    const dia = String(hoje.getDate()).padStart(2, "0");
    const hojeString = `${ano}-${mes}-${dia}`;

    if (date < hojeString) {
        error.textContent = "Não é permitido selecionar datas passadas 🐌";
        error.style.display = 'block';
        return;
    }

    error.style.display = 'none';

    const priority = getPriority(date);
    addTask(name, priority);
    saveTasksToDatabase();

    modal.classList.remove('show');
    document.getElementById('task-name').value = '';
    document.getElementById('task-date').value = '';
});

window.addEventListener('load', () => {
toggleEmptyMessage();
updateTaskCounts();
});
</script>



<script>
const tabEvolucoes = document.getElementById('tab-evolucoes');
const tabLoja = document.getElementById('tab-loja');
const contentEvolucoes = document.getElementById('content-evolucoes');
const contentLoja = document.getElementById('content-loja');

// Função para mudar para a aba Loja
tabLoja.addEventListener('click', () => {
    tabLoja.classList.add('active-tab');
    tabEvolucoes.classList.remove('active-tab');
    contentLoja.style.display = 'block';
    contentEvolucoes.style.display = 'none';
});

// Função para mudar para a aba Evolução
tabEvolucoes.addEventListener('click', () => {
    tabEvolucoes.classList.add('active-tab');
    tabLoja.classList.remove('active-tab');
    contentEvolucoes.style.display = 'block';
    contentLoja.style.display = 'none';
});

// Lembrar de abrir o modal no botão principal (ajuste o seletor se necessário)
document.querySelector('.mascot .btn-primary').addEventListener('click', () => {
    document.getElementById('skins-modal').classList.add('show');
});

document.getElementById('close-skins').addEventListener('click', () => {
    document.getElementById('skins-modal').classList.remove('show');
});
</script>
<script>




/* ===============================
   SALVAR NO BANCO DE DADOS
================================ */

function salvarNoBanco(tasks) {

fetch("salvar_tarefas.php", {
    method: "POST",
    headers: {
        "Content-Type": "application/json"
    },
    body: JSON.stringify({ tasks: tasks })
})
.then(res => res.json())
.then(data => {
    if (data.status !== "sucesso") {
        console.error("Erro ao salvar no banco:", data.mensagem);
    }
})
.catch(err => console.error("Erro:", err));

}
function saveTasksToDatabase() {
    const tasks = Array.from(document.querySelectorAll('.task')).map(task => ({
        name: task.querySelector('strong').innerText,
        priority: task.classList.contains('alta')
            ? 'alta'
            : task.classList.contains('media')
            ? 'media'
            : 'baixa',
        done: task.classList.contains('done')
    }));

    salvarNoBanco(tasks);
}
function carregarDoBanco() {
    fetch("buscar_tarefas.php")
    .then(res => res.json())
    .then(tasks => {

        taskList.innerHTML = "";

        tasks.forEach(task => {
            const li = addTask(task.name, task.priority);

            if (task.done) {
                li.classList.add('done');

                const check = li.querySelector('.check');
                check.style.pointerEvents = 'none';
            }
        });

        updateTaskCounts();
        toggleEmptyMessage();
    })
    .catch(err => console.error("Erro ao carregar:", err));
}



window.addEventListener('load', carregarDoBanco);
function salvarXP() {
    fetch("salvar_xp.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            xp: currentXP,
            nivel: level
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status !== "sucesso") {
            console.error("Erro ao salvar XP:", data.mensagem);
        }
    })
    .catch(error => {
        console.error("Erro na requisição:", error);
    });
}

function carregarXP() {
    fetch("buscar_xp.php")
        .then(res => res.json())
        .then(data => {
            if (data.xp !== undefined) {
                currentXP = parseInt(data.xp);
                level = parseInt(data.nivel);
                maxXP = 300;

                updateXP();

                // 🔥 ADICIONE ESTA LINHA
                verificarNovaEvolucao();
            }
        });
}



window.addEventListener('load', carregarXP);
let moedas = <?php echo $moedasUsuario; ?>;
let evolucaoRecebida = <?php echo $evolucaoRecebida; ?>;

function verificarNovaEvolucao() {

    let novaEvolucao = 0;

    if (level >= 1 && level <= 2) novaEvolucao = 1;
    else if (level >= 3 && level <= 4) novaEvolucao = 2;
    else if (level >= 5 && level <= 6) novaEvolucao = 3;
    else if (level >= 7 && level <= 8) novaEvolucao = 4;
    else if (level >= 9 && level <= 10) novaEvolucao = 5;

    if (novaEvolucao > evolucaoRecebida) {

        moedas += 50;
        evolucaoRecebida = novaEvolucao;

        atualizarMoedas();
        salvarMoedas();

        mostrarAnimacaoMoedas();
    }
}

function salvarMoedas() {
    fetch("salvar_moedas.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            moedas: moedas,
            evolucao: evolucaoRecebida
        })
    });
}

function atualizarMoedas() {
    const moedaSpan = document.getElementById('moedas-display');
    moedaSpan.innerHTML = `✨ ${moedas} moedas`;
}


function mostrarAnimacaoMoedas() {
    const msg = document.createElement("div");
    msg.textContent = "✨ +50 moedas!";
    msg.style.position = "fixed";
    msg.style.top = "20px";
    msg.style.right = "20px";
    msg.style.background = "#FFD56A";
    msg.style.padding = "12px 20px";
    msg.style.borderRadius = "15px";
    msg.style.fontWeight = "bold";
    msg.style.zIndex = "9999";
    document.body.appendChild(msg);

    setTimeout(() => msg.remove(), 2000);
}


</script>
<script>
const menuToggle = document.querySelector('.menu-toggle');
const sidebar = document.querySelector('.sidebar');
const overlay = document.querySelector('.overlay');
const mobile = window.matchMedia("(max-width: 768px)");

menuToggle.addEventListener('click', () => {
    if (mobile.matches) {
        sidebar.classList.add('active');
        overlay.classList.add('show');
        menuToggle.classList.add('hide'); // 🔥 ESCONDE O BOTÃO
    }
});

overlay.addEventListener('click', () => {
    sidebar.classList.remove('active');
    overlay.classList.remove('show');
    menuToggle.classList.remove('hide'); // 🔥 MOSTRA DE NOVO
});
document.addEventListener("DOMContentLoaded", function () {
    const dateInput = document.getElementById("task-date");

    const hoje = new Date();
    const ano = hoje.getFullYear();
    const mes = String(hoje.getMonth() + 1).padStart(2, "0");
    const dia = String(hoje.getDate()).padStart(2, "0");

    dateInput.min = `${ano}-${mes}-${dia}`;
});



</script>

<script src="darkmode.js"></script>
<script src="transition.js"></script>

</html>