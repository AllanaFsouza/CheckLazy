<?php
session_start();
require_once 'conexao.php';  

$data = json_decode(file_get_contents("php://input"), true);

$moedas = (int)$data['moedas'];
$evolucao = (int)$data['evolucao'];

$usuario_id = $_SESSION['usuario_id'];

$stmt = $conn->prepare("UPDATE usuarios SET moedas = ?, evolucao_recebida = ? WHERE id = ?");
$stmt->bind_param("iii", $moedas, $evolucao, $usuario_id);

if ($stmt->execute()) {
    echo json_encode(["status" => "sucesso"]);
} else {
    echo json_encode(["status" => "erro"]);
}
?>
