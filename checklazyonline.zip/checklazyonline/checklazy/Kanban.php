<?php
session_start();
require_once "conexao.php"; // sua conexão com o banco

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

// Buscar nome atualizado no banco
$sql = "SELECT nome, nivel FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();

$nome_usuario = $usuario['nome'];
$nivel_usuario = $usuario['nivel']; 
$inicial = strtoupper(substr($nome_usuario, 0, 1));

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Kanban - CheckLazy</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="kanban.css">
    
</head>
<body>

    <style>
        :root {
    --roxo: #6C63FF;
    --roxo-claro: #E8E7FF;
    --cinza: #f6f6fb;
    --texto: #333;
    --branco: #fff;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Lexend', sans-serif;
}

body {
    background: var(--cinza);
}

/* LAYOUT */
.app {
    display: flex;
    min-height: 100vh;
}

/* SIDEBAR */
.sidebar {
    width: 280px;
    background: var(--branco);
    padding: 30px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.logo {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 30px;
}

.logo-mascot {
    width: 48px;
}

.menu a {
    display: block;
    padding: 12px;
    margin: 6px 0;
    border-radius: 10px;
    text-decoration: none;
    color: var(--texto);
}

.menu a.active,
.menu a:hover {
    background: var(--roxo);
    color: white;
}

.user {
    display: flex;
    flex-direction: column;   /* 👈 empilha vertical */
    align-items: flex-start;  /* alinha à esquerda */
    gap: 10px;
    border-top: 1px solid #eee;
    padding-top: 15px;
}


/* CONTENT */
.content {
    flex: 1;
    padding: 30px;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 40px; /* 👈 afasta do kanban */
}

.header-actions {
    display: flex;
    align-items: center;
    gap: 16px;
}

.header-status {
    display: flex;
    align-items: center;
    gap: 12px;
}

.streak {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    background: linear-gradient(135deg, #FFD56A, #FF9F43);
    color: white;
    border-radius: 20px;
    font-size: 14px;
    font-weight: 600;
}

.streak img {
    width: 18px;
}

.dark-mode {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    border: 1px solid #ddd;
    background: var(--branco);
    cursor: pointer;
}

.btn-primary {
    background: var(--roxo);
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 12px;
    font-weight: 600;
    cursor: pointer;
}


/* GRID */
/* GRID PRINCIPAL */
.grid {
    display: grid;
    grid-template-columns: 280px 1fr;
    gap: 40px;
    align-items: flex-start;
}

/* KANBAN CONTAINER */
.kanban {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 40px;
    width: 100%;
}

/* COLUNAS DO KANBAN */
.kanban-column {
    background: var(--branco);
    padding: 24px;
    border-radius: 20px;
    min-height: 280px;   /* 👈 FORÇA FICAR GRANDE */
    display: flex;
    flex-direction: column;
}

/* CARDS */
.kanban-card {
    width: 100%;
    min-height: 140px;
}

/* COLUNA ADICIONAR TAREFA */
.add-column {
    width: 280px;
    max-width: 280px;
}


/* TASKS */
.tasks {
    background: var(--branco);
    padding: 24px;
    border-radius: 20px;
}

.tasks header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
}

.task {
    background: var(--cinza);
    padding: 16px;
    border-radius: 14px;
    margin: 10px 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.badge {
    padding: 4px 10px;
    border-radius: 10px;
    font-size: 12px;
}

.alta .badge { background: #ffb3b3; }
.media .badge { background: #ffe0a3; }
.baixa .badge { background: #c8f2c8; }

/* MASCOT */
.mascot {
    background: var(--branco);
    padding: 24px;
    border-radius: 20px;
    text-align: center;
}

.mascot img {
    width: 80px;
}

.mascot button {
    margin-top: 10px;
    width: 100%;
    padding: 8px;
    border-radius: 8px;
    border: 1px solid var(--roxo);
    background: transparent;
    color: var(--roxo);
}
/* KANBAN */
.kanban {
    display: grid;
    grid-template-columns: repeat(2, 1fr); /* 👈 2 colunas */
    gap: 50px;
}

.kanban-column {
    background: var(--branco);
    padding: 16px;
    border-radius: 20px;
}

.kanban-column header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
}

.kanban-column h3 {
    font-size: 16px;
}

.kanban-column button {
    width: 28px;
    height: 28px;
    border-radius: 50%;
    border: none;
    background: var(--roxo);
    color: white;
    font-weight: bold;
    cursor: pointer;
}

.kanban-card {
    background: var(--cinza);
    padding: 20px;
    border-radius: 18px;
    margin-bottom: 16px;
    font-size: 15px;
    min-height: 110px;
    width: 320px;

    display: flex;
    align-items: center;

    position: relative;
}


.kanban-card::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    width: 6px;
    height: 100%;
    border-radius: 14px 0 0 14px;
}

/* CORES DAS COLUNAS */
.red::before {
    background: #ff7675;
}

.orange::before {
    background: #fd9644;
}

.yellow::before {
    background: #feca57;
}

.green::before {
    background: #2ecc71;
}.add-column {
    background: var(--branco);
    padding: 20px;
    border-radius: 20px;
}

.add-task-form {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.add-task-form input,
.add-task-form textarea,
.add-task-form select {
    padding: 12px;
    border-radius: 12px;
    border: 1px solid #ddd;
    font-size: 14px;
    resize: none;
}

.add-task-form button {
    background: #2ecc71;
    color: white;
    border: none;
    padding: 12px;
    border-radius: 12px;
    font-weight: 600;
    cursor: pointer;
}

.kanban-column:empty::after {
    content: "Nenhuma tarefa ainda";
    display: block;
    text-align: center;
    color: #aaa;
    font-size: 14px;
    padding: 30px 0;
}
.kanban-column .empty {
    text-align: center;
    color: #aaa;
    font-size: 14px;
    padding: 30px 0;
}
/* HEADER FIXO NO TOPO */
.header {
    position: fixed;
    top: 0;
    left: 280px; /* largura da sidebar */
    right: 0;
    z-index: 100;
    background: var(--cinza);
    padding: 30px;
}

/* EMPURRA O CONTEÚDO PARA BAIXO DO HEADER */
.content {
    padding-top: 140px; /* altura visual do header */
}
.content > .header {
    display: none;
}
/* BOTÃO DE ADICIONAR TAREFA */
.add-task-form button#createTask {
    background: linear-gradient(135deg, #6C63FF, #8e7fff);
    color: white;
    border: none;
    padding: 18px 24px;       /* altura e largura do botão */
    border-radius: 12px;
    font-weight: 700;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
    text-align: center;
    width: 100%;
    min-width: 160px;

    /* NOVO: centralizar texto */
    display: flex;
    justify-content: center;
    align-items: center;
}

/* HOVER */
.add-task-form button#createTask:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    background: linear-gradient(135deg, #8e7fff, #6C63FF);
}

/
/* MODO NOTURNO COM TEXTO BRANCO */
body.dark {
    --roxo: #9B8CFF;
    --roxo-claro: #4a3fff;
    --cinza: #1e1e2f;
    --texto: #ffffff; /* 👈 todas as letras brancas */
    --branco: #2c2c3c;
}

/* Sidebar */
body.dark .sidebar {
    background: var(--branco);
    color: var(--texto);
}

body.dark .menu a {
    color: var(--texto);
}

body.dark .menu a.active,
body.dark .menu a:hover {
    background: var(--roxo);
    color: white; /* mantém contraste nos links ativos */
}

/* Header */
body.dark .header {
    background: var(--branco);
    color: var(--texto);
}

body.dark .header h1,
body.dark .header p {
    color: var(--texto);
}

/* Kanban */
body.dark .kanban-column {
    background: var(--branco);
    color: var(--texto);
}

body.dark .kanban-column h3 {
    color: var(--texto);
}

body.dark .kanban-card {
    background: var(--cinza);
    color: var(--texto);
}

body.dark .kanban-card p,
body.dark .kanban-card strong {
    color: var(--texto);
}

/* Inputs e formulários */
body.dark .add-task-form input,
body.dark .add-task-form textarea,
body.dark .add-task-form select {
    background: #3a3a4c;
    color: var(--texto);
    border: 1px solid #555;
}

/* Botão criar tarefa */
body.dark .add-task-form button#createTask {
    color: white;
    background: linear-gradient(135deg, #8e7fff, #6C63FF);
}

/* Footer */
body.dark .footer {
    background: linear-gradient(135deg, #4a3fff, #6C63FF);
    color: white;
}

/* Decor do footer */
body.dark .footer-decor {
    background: rgba(255,255,255,0.5);
}
body.dark .logout-btn {
    background: #2f2f40;
    color: #ddd;
}

body.dark .logout-btn:hover {
    background: #3a3a4c;
    color: #fff;
}


/* BOTÃO SAIR — estilo da referência */
.logout-btn {
    width: 100%;
    padding: 14px 16px;
    border-radius: 14px;
    border: none;

    background: #f2f3f7;
    color: #555;

    font-size: 14px;
    font-weight: 600;

    display: flex;
    align-items: center;
    gap: 8px;

    cursor: pointer;
    transition: all 0.25s ease;
}

/* Hover suave (não agressivo) */
.logout-btn:hover {
    background: linear-gradient(135deg, #6C63FF, #8e7fff);
    color: white;
}


/* Clique */
.logout-btn:active {
    transform: scale(0.98);
}
/* BOTÃO EXCLUIR TAREFA */
.delete-task {
    position: absolute;
    top: 10px;
    right: 10px;

    background: none;
    border: none;
    cursor: pointer;

    font-size: 16px;
    opacity: 0.4;
    transition: opacity 0.2s ease, transform 0.2s ease;
}

.delete-task:hover {
    opacity: 1;
    transform: scale(1.1);
}

/* MODAL PADRÃO */
.modal {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.45);
    backdrop-filter: blur(4px);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
    z-index: 9999;
}

.modal.show {
    opacity: 1;
    pointer-events: all;
}

.modal-card {
    background: var(--branco);
    padding: 28px;
    border-radius: 20px;
    width: 340px;
    text-align: center;
    animation: pop 0.3s ease;
}

.modal-card h3 {
    margin-bottom: 8px;
}

.modal-card p {
    font-size: 14px;
    color: #777;
}

.modal-actions {
    display: flex;
    justify-content: center;
    gap: 12px;
    margin-top: 20px;
}

.modal-actions button {
    padding: 10px 18px;
    border-radius: 10px;
    border: none;
    cursor: pointer;
    font-weight: 600;
}

/* Botão cancelar */
#cancel-logout {
    background: #eee;
}

/* Dark mode */
body.dark .modal-card {
    background: var(--branco);
    color: var(--texto);
}

body.dark #cancel-logout {
    background: #3a3a4c;
    color: white;
}

button {
    transition: 
        transform 0.2s ease,
        box-shadow 0.2s ease,
        background 0.3s ease;
}

/* Hover */
button:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 18px rgba(0,0,0,0.15);
}

/* Clique */
button:active {
    transform: scale(0.96);
    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
}

@keyframes pulse-soft {
    0% { box-shadow: 0 0 0 0 rgba(108,99,255,0.5); }
    70% { box-shadow: 0 0 0 12px rgba(108,99,255,0); }
    100% { box-shadow: 0 0 0 0 rgba(108,99,255,0); }
}

.createTask {
    animation: pulse-soft 2.5s infinite;
}

#createTask:hover {
    animation: none;
}
.dark-mode {
    transition: transform 0.4s ease;
}

.dark-mode:hover {
    transform: rotate(20deg) scale(1.1);
}
.delete-task:hover {
    transform: rotate(10deg) scale(1.2);
    opacity: 1;
}

.btn-primary {
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}
.avatar {
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, #6C63FF, #8e7fff);
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 16px;
}
body.dark .app {
    background: var(--cinza); /* ou um tom escuro coerente */
}

body.dark .sidebar {
    background: var(--cinza); /* deixa a sidebar escura igual ao fundo */
    color: var(--texto);
}
/* ================= DARK MODE ================= */

body.dark {
    --roxo: #9B8CFF;
    --roxo-claro: #4a3fff;
    --cinza: #1e1e2f;
    --texto: #ffffff;
    --branco: #2c2c3c;

    background: var(--cinza);
}

body.dark .app {
    background: var(--cinza);
}

/* Sidebar */
body.dark .sidebar {
    background: var(--cinza);
    color: var(--texto);
}

/* Menu */
body.dark .menu a {
    color: var(--texto);
}

body.dark .menu a.active,
body.dark .menu a:hover {
    background: var(--roxo);
    color: white;
}

/* Header / conteúdo */
body.dark .header,
body.dark .content,
body.dark .kanban-column {
    background: var(--branco);
    color: var(--texto);
}

/* Cards no dark */
body.dark .kanban-card {
    background: #1f1f2e;
    color: var(--texto);
}

/* Inputs no dark */
body.dark .add-task-form input,
body.dark .add-task-form textarea,
body.dark .add-task-form select {
    background: #3a3a4c;
    color: var(--texto);
    border: 1px solid #555;
}

/* Botão criar tarefa no dark */
body.dark .add-task-form button#createTask {
    background: linear-gradient(135deg, #8e7fff, #6C63FF);
    color: white;
}


/* ================= MODO CLARO (PADRÃO) ================= */

/* Inputs claros */
.add-task-form input,
.add-task-form textarea,
.add-task-form select {
    background: var(--branco);
    color: var(--texto);
    border: 2px solid var(--roxo);
    box-shadow: 0 0 8px rgba(108, 99, 255, 0.15);
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

.add-task-form input:focus,
.add-task-form textarea:focus,
.add-task-form select:focus {
    border-color: #8e7fff;
    box-shadow: 0 0 12px rgba(142, 127, 255, 0.35);
    outline: none;
}

/* Colunas */
.kanban-column {
    background: var(--branco);
    color: var(--texto);
    border: 2px solid transparent;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
    border-radius: 20px;
}

.kanban-column:hover {
    border-color: var(--roxo);
    box-shadow: 0 6px 20px rgba(108, 99, 255, 0.25);
}

/* Cards no claro */
.kanban-card {
    background: var(--cinza);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    transition: box-shadow 0.3s ease;
}

.kanban-card:hover {
    box-shadow: 0 4px 16px rgba(108, 99, 255, 0.35);
}

/* ================= RESPONSIVIDADE ================= */

/* TABLET */
@media (max-width: 1024px) {

    .grid {
        grid-template-columns: 1fr;
        gap: 30px;
    }

    .kanban {
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }

    .kanban-card {
        width: 100%;
    }

    .header {
        left: 0;
    }

    .content {
        padding-top: 160px;
    }
}

/* MOBILE */
@media (max-width: 768px) {

    .app {
        flex-direction: column;
    }

    /* Sidebar vira topo */
    .sidebar {
        width: 100%;
        flex-direction: column;
        padding: 20px;
    }

    .menu {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }

    .menu a {
        flex: 1 1 45%;
        text-align: center;
    }

    /* Header deixa de ser fixo */
    .header {
        position: relative;
        left: 0;
        padding: 20px;
    }

    .content {
        padding-top: 20px;
        padding-left: 20px;
        padding-right: 20px;
    }

    /* Grid vira coluna única */
    .grid {
        display: flex;
        flex-direction: column;
        gap: 30px;
    }

    /* Kanban vira coluna única */
    .kanban {
        grid-template-columns: 1fr;
        gap: 20px;
    }

    .kanban-column {
        width: 100%;
    }

    .kanban-card {
        width: 100%;
    }

    .add-column {
        width: 100%;
        max-width: 100%;
    }

    /* Header actions quebra linha */
    .header-actions {
        flex-direction: column;
        align-items: flex-start;
        gap: 12px;
        margin-top: 15px;
    }

    .btn-primary {
        width: 100%;
    }
}

/* MOBILE PEQUENO */
@media (max-width: 480px) {

    .menu a {
        flex: 1 1 100%;
    }

    .avatar {
        width: 36px;
        height: 36px;
        font-size: 14px;
    }

    .kanban-card {
        padding: 16px;
    }

    .modal-card {
        width: 90%;
    }
}
/* ===== SIDEBAR COLAPSÁVEL ===== */

.sidebar {
    transition: transform 0.35s ease, width 0.35s ease;
}

.content {
    transition: margin-left 0.35s ease;
}

.header {
    transition: left 0.35s ease;
}

/* Estado fechado */
.app.collapsed .sidebar {
    transform: translateX(-100%);
    position: fixed;
}

.app.collapsed .header {
    left: 0;
}

.app.collapsed .content {
    margin-left: 0;
}
/* Esconde botão no desktop */
#toggleSidebar {
    display: none;
}
@media (max-width: 768px) {
    #toggleSidebar {
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }
}
.header-actions {
    display: flex;
    align-items: center;
    gap: 16px;
}

.header-status {
    display: flex;
    align-items: center;
    gap: 10px; /* espaço entre ☰ e 🌙 */
}

@media (max-width: 768px) {

    .header {
        position: relative;
        left: 0;

        padding: 12px 16px; /* 🔥 menor */
        margin-bottom: 20px; /* reduz espaço */
    }

    .header h1 {
        font-size: 20px; /* menor */
    }

    .header p {
        font-size: 13px;
    }

}
@media (max-width: 768px) {

    .btn-primary {
        padding: 6px 12px;   /* 🔥 menor */
        font-size: 13px;     /* texto menor */
        border-radius: 10px; /* levemente mais compacto */
        box-shadow: 0 3px 8px rgba(108, 99, 255, 0.2);
    }

}
/* ===== SIDEBAR FLUTUANTE (FUNDO ESTÁTICO) ===== */

.sidebar {
    width: 280px;
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    z-index: 3000;

    transform: translateX(-100%);
    transition: transform 0.35s ease;

    box-shadow: 4px 0 20px rgba(0,0,0,0.15);
}

/* Quando aberta */
.app:not(.collapsed) .sidebar {
    transform: translateX(0);
}

/* NÃO MEXE NO CONTENT */
.content {
    margin-left: 0 !important;
}

/* NÃO MEXE NO HEADER */
.header {
    left: 0 !important;
}
/* ===== DESKTOP ===== */
@media (min-width: 769px) {

    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        width: 280px;
        transform: translateX(0);
        z-index: 3000;
    }

    .app {
        padding-left: 280px; /* 🔥 RESERVA ESPAÇO REAL */
    }

    .header {
        left: 280px !important;
        width: calc(100% - 280px);
    }

}


/* ===== SIDEBAR MOBILE ===== */
@media (max-width: 768px) {

    .sidebar {
        transform: translateX(-100%);
    }

    .app:not(.collapsed) .sidebar {
        transform: translateX(0);
    }

    .content {
        margin-left: 0 !important;
    }

    .header {
        left: 0 !important;
    }

}

#saveKanbanBtn {
    background: linear-gradient(135deg, #2ecc71, #27ae60);
}
/* ===== MODAL KANBAN ONLINE BONITO ===== */

#save-kanban-modal .modal-card {
    background: linear-gradient(135deg, #ffffff, #f4f6ff);
    border-radius: 24px;
    padding: 32px;
    width: 380px;
    box-shadow: 0 25px 60px rgba(108, 99, 255, 0.25);
    text-align: center;
}

#save-kanban-modal h3 {
    font-size: 20px;
    margin-bottom: 10px;
    color: var(--roxo);
}

.modal-description {
    font-size: 14px;
    color: #666;
    line-height: 1.6;
    margin-bottom: 20px;
}

/* Inputs mais bonitos */
#save-kanban-modal input {
    padding: 14px;
    border-radius: 14px;
    border: 2px solid #e0e0ff;
    background: white;
    transition: all 0.3s ease;
    font-size: 14px;
}

#save-kanban-modal input:focus {
    border-color: var(--roxo);
    box-shadow: 0 0 12px rgba(108, 99, 255, 0.3);
    outline: none;
}

/* Botões */
#save-kanban-modal .modal-actions {
    margin-top: 25px;
}

#confirm-save-kanban {
    background: linear-gradient(135deg, #6C63FF, #8e7fff);
    color: white;
    padding: 12px 22px;
    border-radius: 12px;
}

#confirm-save-kanban:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(108,99,255,0.4);
}

#cancel-save-kanban {
    background: #f0f0f5;
    color: #555;
}

body.dark #save-kanban-modal .modal-card {
    background: linear-gradient(135deg, #2c2c3c, #1f1f2e);
    color: white;
}

body.dark .modal-description {
    color: #ccc;
}

body.dark #save-kanban-modal input {
    background: #3a3a4c;
    border: 2px solid #555;
    color: white;
}


    </style>

<div class="app">

    <!-- SIDEBAR -->
    <aside class="sidebar">
        <div>
            <div class="logo">
                <img src="LogoCheckLazy.png" class="logo-mascot">
                <div class="logo-text">
                    <h2>CheckLazy</h2>
                    <span>Devagar e sempre!</span>
                </div>
            </div>

         <nav class="menu">
    <a href="Tela_inicial.php">📊 Dashboard</a>
    <a href="Tarefas.php">📋 Tarefas</a>
    <a href="Kanban.php" class="active">🗂 Kanban</a>
    <a href="Calendario.php">📅 Calendário</a>
    <a href="Progresso.php">📈 Progresso</a>
    <a href="Configuracoes.php">⚙️ Configurações</a>
     <a href="kanbanonline.php" >🌎 Kanban Online</a>
</nav>


        </div>

       <div class="user">
    <div style="display:flex; align-items:center; gap:10px;">
        <div class="avatar"><?php echo $inicial; ?></div>
        <div>
            <strong><?php echo htmlspecialchars($nome_usuario); ?></strong><br>
            <small>Nível <?php echo $nivel_usuario; ?></small> <!-- 🔹 nível real -->
        </div>
    </div>

    <button class="logout-btn">⎋ Sair</button>
</div>

       
    </aside>
 <!-- HEADER -->
        <header class="header">
            <div>
                <h1>Kanban</h1>
                <p>Adicione novas tarefas com o Kanban!</p>
            </div>

          <div class="header-actions">

    <div class="header-status">
        <button class="dark-mode">🌙</button>
        <button id="toggleSidebar" class="btn-primary" style="background:#eee;color:#333;">
            ☰
        </button>

        
    </div>
 <a href="#" id="saveKanbanBtn" class="btn-primary" style="background:#2ecc71;">
        💾 Salvar Kanban Online
    </a>
    <a href="Tarefas.php" class="btn-primary">+ Nova Tarefa</a>

</div>


        </header>
    <!-- CONTEÚDO -->
    <main class="content">

        <header class="header">
            <div>
                <h1>Bem vindo!</h1>
                <p>Adicione novas tarefas com o Kanban!</p>
            </div>
        </header>

        <section class="grid">

            <!-- ADICIONAR TAREFA -->
            <div class="kanban-column add-column">
                <header>
                    <h3>Adicionar tarefa</h3>
                </header>

                <div class="add-task-form">
                    <input type="text" id="taskTitle" placeholder="Nome da tarefa">
                    <textarea id="taskDesc" placeholder="Descrição da tarefa"></textarea>

                    <select id="taskStatus">
                        <option value="A Fazer">A Fazer</option>
                        <option value="Em Andamento">Em Andamento</option>
                        <option value="Em Revisão">Em Revisão</option>
                        <option value="Concluído">Concluído</option>
                    </select>

                    <button id="createTask">Pronto</button>
                </div>
            </div>

            <!-- KANBAN -->
            <div class="kanban">

                <div class="kanban-column">
                    <header><h3>A Fazer</h3></header>
                    <div class="empty">Nenhuma tarefa ainda</div>
                </div>

                <div class="kanban-column">
                    <header><h3>Em Andamento</h3></header>
                    <div class="empty">Nenhuma tarefa ainda</div>
                </div>

                <div class="kanban-column">
                    <header><h3>Em Revisão</h3></header>
                    <div class="empty">Nenhuma tarefa ainda</div>
                </div>

                <div class="kanban-column">
                    <header><h3>Concluído</h3></header>
                    <div class="empty">Nenhuma tarefa ainda</div>
                </div>

            </div>
        </section>

<!-- MODAL SALVAR KANBAN -->
<div id="save-kanban-modal" class="modal">
    <div class="modal-card">
       <h3>🌍 Compartilhar Kanban </h3>
<p class="modal-description">
Salve seu Kanban para que outros usuários tenham acesso.
Proteja com uma senha e compartilhe quando quiser 🔐
</p>


        <div style="margin-top:15px; display:flex; flex-direction:column; gap:10px;">
            <input type="text" id="kanbanName" placeholder="Nome do Kanban">
            <input type="password" id="kanbanPassword" placeholder="Senha">
        </div>

        <div class="modal-actions">
            <button id="cancel-save-kanban">Cancelar</button>
            <button id="confirm-save-kanban" class="btn-primary">Salvar</button>
        </div>
    </div>
</div>



    </main>
</div>

<script src="kanban.js"></script>

<script>
    document.getElementById('createTask').addEventListener('click', () => {
    const title = document.getElementById('taskTitle').value.trim();
    const desc = document.getElementById('taskDesc').value.trim();
    const status = document.getElementById('taskStatus').value;

    if (!title) {
        alert('Digite o nome da tarefa');
        return;
    }

    let column = null;

    // procura apenas colunas do kanban real (ignora "Adicionar tarefa")
    document.querySelectorAll('.kanban .kanban-column').forEach(col => {
        const h3 = col.querySelector('h3');
        if (h3 && h3.innerText === status) {
            column = col;
        }
    });

    if (!column) return;

    // remove placeholder "Nenhuma tarefa"
    const empty = column.querySelector('.empty');
    if (empty) empty.remove();

    // cria o card
    const card = document.createElement('div');
    card.classList.add('kanban-card');

    switch (status) {
        case 'A Fazer':
            card.classList.add('red');
            break;
        case 'Em Andamento':
            card.classList.add('orange');
            break;
        case 'Em Revisão':
            card.classList.add('yellow');
            break;
        case 'Concluído':
            card.classList.add('green');
            break;
    }

    card.innerHTML = `
    <button class="delete-task" title="Excluir tarefa">🗑</button>

    <div>
        <strong>${title}</strong>
        ${desc ? `<p style="font-size:13px; margin-top:6px;">${desc}</p>` : ''}
    </div>
`;


    column.appendChild(card);
    // ===== ENVIA PARA O BANCO =====
salvarTarefaNoBanco(title, desc, status, card);



    // limpa campos
    document.getElementById('taskTitle').value = '';
    document.getElementById('taskDesc').value = '';
    document.getElementById('taskStatus').value = 'A Fazer';
});
// Alterna modo claro/escuro
document.querySelectorAll('.dark-mode').forEach(btn => {
    btn.addEventListener('click', () => {
        document.body.classList.toggle('dark');
    });
});

document.addEventListener('click', (e) => {

    if (e.target.classList.contains('delete-task')) {

        const card = e.target.closest('.kanban-card');
        const column = card.parentElement;
        const id = card.dataset.id;

        if (id) {

            fetch("deletar_tarefa_kanban.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ id: id })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    card.remove();

                    if (column.querySelectorAll('.kanban-card').length === 0) {
                        const empty = document.createElement('div');
                        empty.classList.add('empty');
                        empty.innerText = 'Nenhuma tarefa ainda';
                        column.appendChild(empty);
                    }

                } else {
                    console.error("Erro ao deletar:", data.error);
                }
            });

        } else {
            // Caso não tenha ID (segurança)
            card.remove();
        }
    }
});


</script>

<!-- MODAL SAIR -->
<div id="logout-modal" class="modal">
    <div class="modal-card">
        <h3>Deseja sair da conta?</h3>
        <p>Você será desconectado do CheckLazy 🐌</p>

        <div class="modal-actions">
            <button id="cancel-logout">Cancelar</button>
            <button id="confirm-logout" class="btn-primary">Sair</button>
        </div>
    </div>
</div>
<script>
const logoutBtn = document.querySelector('.logout-btn');
const logoutModal = document.getElementById('logout-modal');
const cancelLogout = document.getElementById('cancel-logout');
const confirmLogout = document.getElementById('confirm-logout');

logoutBtn.addEventListener('click', () => {
    logoutModal.classList.add('show');
});

cancelLogout.addEventListener('click', () => {
    logoutModal.classList.remove('show');
});

confirmLogout.addEventListener('click', () => {
    window.location.href = 'login.php';
});
logoutModal.addEventListener('click', (e) => {
    if (e.target === logoutModal) {
        logoutModal.classList.remove('show');
    }
});



// ===== APLICAR TEMA AO CARREGAR A PÁGINA =====
document.addEventListener("DOMContentLoaded", () => {
    const savedTheme = localStorage.getItem("theme");

    if (savedTheme === "dark") {
        document.body.classList.add("dark");
    }
});

// ===== BOTÃO MODO ESCURO =====
document.querySelectorAll('.dark-mode').forEach(btn => {
    btn.addEventListener('click', () => {
        document.body.classList.toggle('dark');

        // Salva preferência
        if (document.body.classList.contains('dark')) {
            localStorage.setItem("theme", "dark");
        } else {
            localStorage.setItem("theme", "light");
        }
    });
});

</script>
<script>
document.addEventListener("DOMContentLoaded", function () {

    const buttons = document.querySelectorAll(".dark-mode");

    // Aplica tema salvo
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "dark") {
        document.body.classList.add("dark");
    }

    // Evento de clique
    buttons.forEach(btn => {
        btn.addEventListener("click", function () {
            document.body.classList.toggle("dark");

            if (document.body.classList.contains("dark")) {
                localStorage.setItem("theme", "dark");
            } else {
                localStorage.setItem("theme", "light");
            }
        });
    });

});
// ===== FUNÇÃO PARA SALVAR NO BANCO =====
function salvarTarefaNoBanco(nome, descricao, status, cardElement) {

    fetch("salvar_tarefa_kanban.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            nome: nome,
            descricao: descricao,
            status: status
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log("Tarefa salva no banco!");
            
            // 🔥 salva o ID da tarefa no card
            cardElement.dataset.id = data.id;

        } else {
            console.error("Erro ao salvar:", data.error);
        }
    })
    .catch(error => {
        console.error("Erro na requisição:", error);
    });
}


</script>

<script>

// ===== CARREGAR TAREFAS DO BANCO =====
document.addEventListener("DOMContentLoaded", function () {

    fetch("buscar_tarefas_kanban.php")
        .then(response => response.json())
        .then(data => {

            if (!data.success) {
                console.error("Erro ao buscar tarefas:", data.error);
                return;
            }

           data.tarefas.forEach(task => {
    adicionarCardNaTela(
        task.titulo,
        task.descricao,
        task.nome_status,
        task.id   
    );
});


        })
        .catch(error => {
            console.error("Erro na requisição:", error);
        });

});


// ===== FUNÇÃO PARA ADICIONAR CARD NA TELA =====
function adicionarCardNaTela(title, desc, status, id = null) {

    let column = null;

    document.querySelectorAll('.kanban .kanban-column').forEach(col => {
        const h3 = col.querySelector('h3');
        if (h3 && h3.innerText === status) {
            column = col;
        }
    });

    if (!column) return;

    const empty = column.querySelector('.empty');
    if (empty) empty.remove();

    const card = document.createElement('div');
    card.classList.add('kanban-card');

    if (id) {
        card.dataset.id = id; // 🔥 salva id no HTML
    }

    switch (status) {
        case 'A Fazer': card.classList.add('red'); break;
        case 'Em Andamento': card.classList.add('orange'); break;
        case 'Em Revisão': card.classList.add('yellow'); break;
        case 'Concluído': card.classList.add('green'); break;
    }

    card.innerHTML = `
        <button class="delete-task" title="Excluir tarefa">🗑</button>
        <div>
            <strong>${title}</strong>
            ${desc ? `<p style="font-size:13px; margin-top:6px;">${desc}</p>` : ''}
        </div>
    `;

    column.appendChild(card);
}


</script>
<script>
const toggleBtn = document.getElementById("toggleSidebar");
const app = document.querySelector(".app");

function isMobile() {
    return window.innerWidth <= 768;
}

document.addEventListener("DOMContentLoaded", () => {
    // Começa fechada apenas em mobile/tablet
    if (isMobile()) {
        app.classList.add("collapsed");
    } else {
        app.classList.remove("collapsed"); // desktop sempre aberta
    }
});

toggleBtn.addEventListener("click", () => {
    // Toggle só funciona em mobile/tablet
    if (!isMobile()) return;

    app.classList.toggle("collapsed");

    if (app.classList.contains("collapsed")) {
        sessionStorage.setItem("sidebarState", "collapsed");
    } else {
        sessionStorage.removeItem("sidebarState");
    }
});

// Opcional: reajustar sidebar ao redimensionar a tela
window.addEventListener("resize", () => {
    if (!isMobile()) {
        app.classList.remove("collapsed");
    }
});
</script>

<script>
const saveBtn = document.getElementById("saveKanbanBtn");
const saveModal = document.getElementById("save-kanban-modal");
const cancelSave = document.getElementById("cancel-save-kanban");
const confirmSave = document.getElementById("confirm-save-kanban");

saveBtn.addEventListener("click", (e) => {
    e.preventDefault();
    saveModal.classList.add("show");
});

cancelSave.addEventListener("click", () => {
    saveModal.classList.remove("show");
});

saveModal.addEventListener("click", (e) => {
    if (e.target === saveModal) {
        saveModal.classList.remove("show");
    }
});

confirmSave.addEventListener("click", () => {

    const name = document.getElementById("kanbanName").value.trim();
    const password = document.getElementById("kanbanPassword").value.trim();

    if (!name || !password) {
        alert("Preencha nome e senha!");
        return;
    }

    // Aqui você pode enviar para o banco
    fetch("salvar_kanban_online.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            nome: name,
            senha: password
        })
    })
    .then(res => res.json())
    .then(data => {
    if (data.success) {
        alert("Kanban salvo com sucesso!");
        saveModal.classList.remove("show");
    } else {
        alert(data.error || "Erro ao salvar.");
    }
});


});
</script>




<script src="transition.js"></script>
</body>
</html>