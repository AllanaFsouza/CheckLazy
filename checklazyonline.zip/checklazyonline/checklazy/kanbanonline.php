<?php
session_start();
require_once "conexao.php";

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

$sql = "SELECT nome, nivel FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();

$nome_usuario = $usuario['nome'];
$nivel_usuario = $usuario['nivel'];
$inicial = strtoupper(substr($nome_usuario, 0, 1));
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>CheckLazy - Kanbanonline</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: 'Poppins', sans-serif;
}
body{
    min-height:100vh;
    background: linear-gradient(135deg, #f5f3ff, #ede9fe, #ddd6fe);
    color:#333;
}


/* SIDEBAR */
.sidebar{
    width:250px;
    background:#fff;
    height:100vh;
    padding:20px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
    box-shadow:2px 0 10px rgba(0,0,0,0.05);
}

.logo{
    font-size:22px;
    font-weight:600;
    margin-bottom:20px;
}

.menu{
    display:flex;
    flex-direction:column;
    gap:15px;
}

.menu a{
    text-decoration:none;
    color:#555;
    padding:10px;
    border-radius:10px;
    transition:0.3s;
}

.menu a:hover{
    background:#f1f1f1;
}

.menu .active{
    background:linear-gradient(90deg,#6C63FF,#7C73FF);
    color:#fff;
}

.user{
    border-top:1px solid #eee;
    padding-top:15px;
}

/* MAIN */
.main{
    flex:1;
    padding:30px;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;
}

.header h1{
    font-size:28px;
}

.buttons{
    display:flex;
    gap:15px;
}

.btn{
    padding:10px 20px;
    border:none;
    border-radius:12px;
    cursor:pointer;
    color:#fff;
    font-weight:500;
}

.btn-purple{
    background:linear-gradient(90deg,#6C63FF,#7C73FF);
}

.btn-green{
    background:#22c55e;
}

.btn-blue{
    background:#6366f1;
}

/* KANBAN GRID */
.kanban{
    display:grid;
    grid-template-columns:280px 1fr 1fr;
    grid-template-rows:auto auto;
    gap:25px;
    align-items:start;
}

/* ADD TASK */
.add-task{
    background:#fff;
    padding:20px;
    border-radius:20px;
    box-shadow:0 5px 20px rgba(0,0,0,0.05);
}

.add-task h3{
    margin-bottom:15px;
}

.add-task input,
.add-task textarea,
.add-task select{
    width:100%;
    padding:10px;
    margin-bottom:10px;
    border-radius:10px;
    border:2px solid #6C63FF;
    outline:none;
}

.add-task button{
    width:100%;
    padding:12px;
    border:none;
    border-radius:15px;
    background:linear-gradient(90deg,#6C63FF,#7C73FF);
    color:#fff;
    font-weight:600;
    cursor:pointer;
}

/* COLUMN */
.column{
    background:#fff;
    border-radius:20px;
    padding:15px;
    min-height:300px;
    box-shadow:0 5px 20px rgba(0,0,0,0.05);
}

.column h3{
    margin-bottom:15px;
}

.card{
    background:#f3f4f6;
    padding:10px;
    border-radius:10px;
    margin-bottom:10px;
    cursor:pointer;
}

.empty{
    color:#aaa;
    text-align:center;
    margin-top:50px;
}
.add-task{
    grid-row: 1 / 3; /* ocupa as duas linhas */
}

#todo{
    grid-column:2;
    grid-row:1;
}

#doing{
    grid-column:3;
    grid-row:1;
}

#review{
    grid-column:2;
    grid-row:2;
}

#done{
    grid-column:3;
    grid-row:2;
}
.logo{
    display:flex;
    align-items:center;
    gap:12px;
    margin-bottom:25px;
}

.logo-mascot{
    width:45px;
    height:auto;
}

.logo-text h2{
    font-size:20px;
    font-weight:600;
    margin:0;
    color:#2d2d2d;
}

.logo-text span{
    font-size:12px;
    color:#777;
}
.avatar{
    width:40px;
    height:40px;
    background:linear-gradient(135deg,#6C63FF,#8e7fff);
    color:#fff;
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
    font-weight:700;
}
.logout-btn {
    width: 100%;
    padding: 14px 16px;
    border-radius: 14px;
    border: none;

    background: #f2f3f7;
    color: #555;

    font-size: 14px;
    font-weight: 600;

    display: flex;
    align-items: center;
    gap: 8px;

    cursor: pointer;
    transition: all 0.25s ease;
}

/* Hover suave (não agressivo) */
.logout-btn:hover {
    background: linear-gradient(135deg, #6C63FF, #8e7fff);
    color: white;
}


/* Clique */
.logout-btn:active {
    transform: scale(0.98);
}
/* MODAL */
.modal{
    display:none;
    position:fixed;
    inset:0;
    background:rgba(0,0,0,0.4);
    justify-content:center;
    align-items:center;
    z-index:1000;
}

.modal-content{
    background:#fff;
    padding:25px;
    border-radius:20px;
    width:300px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    animation: fadeIn 0.3s ease;
}

.modal-content h3{
    margin-bottom:15px;
}

.modal-content input{
    width:100%;
    padding:10px;
    margin-bottom:10px;
    border-radius:10px;
    border:2px solid #6C63FF;
    outline:none;
}

.modal-buttons{
    display:flex;
    gap:10px;
}

.modal-buttons button{
    flex:1;
    padding:10px;
    border:none;
    border-radius:10px;
    cursor:pointer;
    font-weight:600;
    background:linear-gradient(90deg,#6C63FF,#7C73FF);
    color:#fff;
}

.modal-buttons .cancel{
    background:#ddd;
    color:#333;
}

@keyframes fadeIn{
    from{transform:scale(0.9); opacity:0;}
    to{transform:scale(1); opacity:1;}
}
.delete-btn{
    background: transparent;
    border: none;
    cursor: pointer;
    font-size: 16px;
    transition: 0.2s;
}

.delete-btn:hover{
    transform: scale(1.2);
}
.header{
    display:flex;
    flex-direction:column;
    margin-bottom:30px;
}

.header-top{
    display:flex;
    justify-content:space-between;
    align-items:center;
    width:100%;
}

.kanban-status{
    font-size:14px;
    color:#666;
    margin-top:6px;
    text-align:left;
    width:100%;
}

/* ================= DARK MODE BASE ================= */

body.dark {
    background: #1e1e2f;
    color: #ffffff;
}

/* Containers principais */
body.dark .sidebar,
body.dark .column,
body.dark .add-task {
    background: #2c2c3c;
}

/* Cards */
body.dark .card {
    background: #1f1f2e;
    color: #ffffff;
}

/* Área principal */
body.dark .main {
    background: transparent;
    color: #ffffff;
}

body.dark .header h1,
body.dark .kanban-status {
    color: #ffffff;
}

/* Inputs e formulários */
body.dark input,
body.dark textarea,
body.dark select {
    background: #3a3a4c;
    color: #ffffff;
    border: 1px solid #555;
}

/* Placeholder */
body.dark input::placeholder,
body.dark textarea::placeholder {
    color: #bbb;
}

/* Options do select */
body.dark select option {
    background: #2c2c3c;
    color: #ffffff;
}

/* Logout */
body.dark .logout-btn {
    background: #2f2f40;
    color: #ddd;
}

/* Botão dark mode */
body.dark .dark-mode {
    background: #2c2c3c;
    color: #ffffff;
}
#customAlert .modal-content {
    background: #ffffff;
    color: #222222;
}

#customAlert h3 {
    color: #222222 !important;
    margin-bottom: 15px;
    font-weight: 600;
}

#customAlert button {
    background: linear-gradient(90deg,#6C63FF,#7C73FF);
    color: #ffffff !important;
    border: none;
    padding: 10px;
    border-radius: 10px;
    font-weight: 600;
    cursor: pointer;
}
/* ================= RESPONSIVIDADE ================= */

/* ===== TABLET ===== */
@media (max-width: 1024px){

    .kanban{
        grid-template-columns: 1fr 1fr;
        grid-template-rows: auto auto auto;
    }

    .add-task{
        grid-column: 1 / 3;
        grid-row: auto;
    }

    #todo, #doing, #review, #done{
        grid-column: auto;
        grid-row: auto;
    }
}


/* ================= SIDEBAR + MOBILE ================= */

/* Estrutura principal */
.app{
    display:flex;
}

/* ===== DESKTOP ===== */
@media (min-width: 769px){

    .sidebar{
        position:fixed;
        left:0;
        top:0;
        bottom:0;
        width:250px;
        transform:translateX(0);
        z-index:2000;
    }

    .main{
        margin-left:250px;
    }

    #toggleSidebar{
        display:none;
    }

    .overlay{
        display:none;
    }
}


/* ===== MOBILE ===== */
@media (max-width: 768px){

    body{
        flex-direction:column;
    }

    /* Sidebar deslizante */
    .sidebar{
        position:fixed;
        left:0;
        top:0;
        bottom:0;
        width:250px;
        background:#fff;
        transform:translateX(-100%);
        transition:0.35s ease;
        z-index:3000;
    }

    .app:not(.collapsed) .sidebar{
        transform:translateX(0);
    }

    /* Overlay escuro */
    .overlay{
        position:fixed;
        inset:0;
        background:rgba(0,0,0,0.4);
        backdrop-filter:blur(2px);
        opacity:0;
        visibility:hidden;
        transition:0.3s ease;
        z-index:2500;
    }

    .app:not(.collapsed) .overlay{
        opacity:1;
        visibility:visible;
    }

    /* Botão ☰ aparece */
    #toggleSidebar{
        display:flex;
    }

    .main{
        margin-left:0;
        padding:15px;
    }

    /* MENU alinhado */
    .menu{
        flex-direction:column;
        gap:8px;
        width:100%;
    }

    .menu a{
        display:flex;
        align-items:center;
        gap:10px;
        width:100%;
        padding:12px 14px;
        border-radius:12px;
        font-size:14px;
        font-weight:500;
        text-align:left;
    }

    /* Header ajustado */
  .header-top{
    display:flex;
    justify-content:space-between;
    align-items:center;
    width:100%;
}

.header-actions{
    display:flex;
    gap:10px;
    align-items:center;
}

    .buttons{
        width:100%;
        flex-wrap:wrap;
        gap:10px;
    }

    .buttons button{
        flex:1 1 100%;
    }

    /* Kanban coluna única */
    .kanban{
        display:flex;
        flex-direction:column;
        gap:20px;
    }

    .add-task,
    .column{
        width:100%;
    }
    
}


/* ===== MOBILE PEQUENO ===== */
@media (max-width: 480px){

    .logo-text h2{
        font-size:16px;
    }

    .header h1{
        font-size:20px;
    }

    .btn{
        padding:8px 12px;
        font-size:14px;
    }

    .dark-mode{
        width:36px;
        height:36px;
        font-size:16px;
    }
}
.buttons{
    display: flex;
    flex-direction: row;      /* lado a lado */
    justify-content: flex-end; /* alinhado à direita */
    gap: 15px;
    width: 100%;
}
.toggle-sidebar{
    width:42px;
    height:42px;
    border:none;
    border-radius:14px; /* meio arredondado, não totalmente círculo */
    cursor:pointer;

    background:#ffffff;
    font-size:18px;

    display:flex;
    align-items:center;
    justify-content:center;

    box-shadow:0 4px 12px rgba(0,0,0,0.08);
    transition:0.25s ease;
}

.toggle-sidebar:hover{
    transform:scale(1.08);
}
.dark-mode {
    width: 42px;
    height: 42px;
    min-width: 42px;
    min-height: 42px;

    padding: 0;
    border-radius: 50%;

    border: none;
    background: linear-gradient(135deg,#6C63FF,#8e7fff);
    color: white;

    display: flex;
    align-items: center;
    justify-content: center;

    cursor: pointer;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    transition: 0.25s ease;
}

.dark-mode:hover {
    transform: scale(1.08);
}
</style>
</head>
<body>
<div class="app collapsed">
<div class="overlay" id="overlay"></div>

<!-- ALERT CUSTOM -->
<div id="customAlert" class="modal">
    <div class="modal-content">
        <h3 id="alertText"></h3>
        <div class="modal-buttons">
            <button onclick="fecharAlerta()">OK</button>
        </div>
    </div>
</div>


<!-- SIDEBAR -->
<div class="sidebar">
    <div>
        <div class="logo">
    <img src="LogoCheckLazy.png" class="logo-mascot">
    <div class="logo-text">
        <h2>CheckLazy</h2>
        <span>Devagar e sempre!</span>
    </div>
</div>

        <div class="menu">
           <a href="Tela_inicial.php">📊 Dashboard</a>
    <a href="Tarefas.php">📋 Tarefas</a>
    <a href="Kanban.php" >🗂 Kanban</a>
    <a href="Calendario.php">📅 Calendário</a>
    <a href="Progresso.php">📈 Progresso</a>
    <a href="Configuracoes.php">⚙️ Configurações</a>
            <a href="kanbanonline.php" class="active">🌎 Kanban Online</a>
        </div>
    </div>

    <div class="user">
    <div style="display:flex; align-items:center; gap:10px;">
        <div class="avatar"><?php echo $inicial; ?></div>
        <div>
            <strong><?php echo htmlspecialchars($nome_usuario); ?></strong><br>
            <small>Nível <?php echo $nivel_usuario; ?></small>
        </div>
    </div>

    <button class="logout-btn" onclick="window.location.href='logout.php'">⎋ Sair</button>

</div>

</div>

<!-- MAIN -->
<div class="main">

    <div class="header">

        <div class="header-top">
            <h1>Kanban online</h1>

            <div class="header-actions">
                 <button class="dark-mode">🌙</button>
                <button id="toggleSidebar" class="toggle-sidebar">☰</button>
               
            </div>
        </div>

        <div class="buttons">
            <button class="btn btn-blue" onclick="openModal()">
                🌎 Acessar Kanban Online
            </button>

            <button class="btn btn-green" onclick="atualizarKanbanTempoReal()">
                🔄 Atualizar Kanban Online
            </button>
        </div>

        <p id="statusKanban" class="kanban-status">
            Verificando status...
        </p>

    </div>

<!-- MODAL LOGIN -->
<div id="loginModal" class="modal">
    <div class="modal-content">
        <h3>Acessar Kanban Online</h3>
        <input type="text" id="loginNome" placeholder="Nome do kanban">
        <input type="password" id="loginSenha" placeholder="Senha">
        <div class="modal-buttons">
            <button onclick="loginKanban()">Entrar</button>
            <button class="cancel" onclick="closeModal()">Cancelar</button>
        </div>
    </div>
</div>
    <div class="kanban">
        
        <!-- ADD TASK -->
        <div class="add-task">
            <h3>Adicionar tarefa</h3>
            <input type="text" id="title" placeholder="Nome da tarefa">
            <textarea id="desc" placeholder="Descrição da tarefa"></textarea>
            <select id="status">
                <option value="todo">A Fazer</option>
                <option value="doing">Em Andamento</option>
                <option value="review">Em Revisão</option>
                <option value="done">Concluído</option>
            </select>
            <button onclick="addTask()">Pronto</button>
        </div>

        <!-- COLUMNS -->
        <div class="column" id="todo">
            <h3>A Fazer</h3>
            <div class="empty">Nenhuma tarefa ainda</div>
        </div>

        <div class="column" id="doing">
            <h3>Em Andamento</h3>
            <div class="empty">Nenhuma tarefa ainda</div>
        </div>

        <div class="column" id="review">
            <h3>Em Revisão</h3>
            <div class="empty">Nenhuma tarefa ainda</div>
        </div>

        <div class="column" id="done">
            <h3>Concluído</h3>
            <div class="empty">Nenhuma tarefa ainda</div>
        </div>

    </div>
</div>

<script>
function addTask(){

    const title = document.getElementById('title').value.trim();
    const desc = document.getElementById('desc').value.trim();
    const status = document.getElementById('status').value;

    if(!title){
        alert("Digite o nome da tarefa");
        return;
    }

    // 🔥 PRIMEIRO verifica se está conectado ao Kanban Online
    fetch("buscar_kanban_online.php")
    .then(res => res.json())
    .then(kanban => {

        if(!kanban.logado){
            alert("Você precisa estar conectado a um Kanban Online!");
            return;
        }

        // 🔥 Só adiciona se estiver logado
        fetch("adicionar_tarefa_online.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                titulo: title,
                descricao: desc,
                status: status
            })
        })
        .then(res => res.json())
        .then(data => {

            if(data.success){

                document.getElementById('title').value = "";
                document.getElementById('desc').value = "";

                carregarKanbanOnline();

            } else {
                alert("Erro ao adicionar: " + (data.error ?? ""));
            }

        });

    })
    .catch(error => {
        console.error(error);
        alert("Erro de conexão!");
    });

}



function openModal(){
    document.getElementById("loginModal").style.display = "flex";
}

function closeModal(){
    document.getElementById("loginModal").style.display = "none";
}

function loginKanban(){

    const nome = document.getElementById("loginNome").value.trim();
    const senha = document.getElementById("loginSenha").value.trim();

    if(!nome || !senha){
        mostrarAlerta("Preencha nome e senha!");
        return;
    }

    fetch("login_kanban_online.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ nome, senha })
    })
    .then(res => res.json())
    .then(data => {

        if(data.success){

            mostrarAlerta("Login realizado com sucesso!"); // ✅ agora personalizado

            closeModal();

            carregarKanbanOnline();

            atualizarStatusKanban();

        } else {
            mostrarAlerta("Nome ou senha incorretos!"); // ✅ personalizado
        }

    })
    .catch(error => {
        console.error(error);
        mostrarAlerta("Erro de conexão com o servidor!"); // ✅ personalizado
    });
}


function carregarKanbanOnline(){

    // limpa colunas
    ["todo","doing","review","done"].forEach(id=>{
        const col = document.getElementById(id);

        col.querySelectorAll(".card").forEach(c => c.remove());

        const empty = col.querySelector(".empty");
        if(empty) empty.remove();
    });

    fetch("buscar_tarefas_online.php")
    .then(res => res.json())
    .then(tarefas => {

        tarefas.forEach(tarefa => {

            let colunaId = "";

            if(tarefa.status_id == 1) colunaId = "todo";
            if(tarefa.status_id == 2) colunaId = "doing";
            if(tarefa.status_id == 3) colunaId = "review";
            if(tarefa.status_id == 4) colunaId = "done";

            const coluna = document.getElementById(colunaId);

            const card = document.createElement("div");
            card.className = "card";

            card.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <strong>${tarefa.titulo}</strong>
                    <button 
                        onclick="excluirTarefa(${tarefa.id}, this)" 
                        class="delete-btn">
                        🗑
                    </button>
                </div>
                <div>${tarefa.descricao ?? ""}</div>
            `;

            coluna.appendChild(card);
        });

    })
    .catch(error => {
        console.error("Erro ao carregar tarefas:", error);
    });
}

function excluirTarefa(id, btn){

    if(!confirm("Deseja excluir esta tarefa?")) return;

    const card = btn.closest(".card");

    // Remove visualmente primeiro
    card.remove();

    fetch("excluir_tarefa_online.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ id })
    })
    .then(res => res.json())
    .then(data => {
        if(!data.success){
            alert("Erro ao excluir no banco!");
            carregarKanbanOnline(); // restaura tudo se der erro
        }
    })
    .catch(() => {
        alert("Erro de conexão!");
        carregarKanbanOnline();
    });
}
function atualizarStatusKanban(){

    fetch("buscar_kanban_online.php")
    .then(res => res.json())
    .then(data => {

        const status = document.getElementById("statusKanban");

        if(data.logado){
            status.innerHTML = `
                Atualmente você está conectado ao Kanban: 
                <strong>"${data.nome}"</strong>
            `;
        } else {
            status.innerHTML = `
                Atualmente você não está conectado em nenhum Kanban online
            `;
        }

    })
    .catch(() => {
        document.getElementById("statusKanban").innerHTML =
            "Erro ao verificar status";
    });
}
// Quando a página carregar
window.onload = function(){
    atualizarStatusKanban();
    carregarKanbanOnline(); // 🔥 CARREGA OS CARDS AO ATUALIZAR A PÁGINA
};
function atualizarKanbanTempoReal(){

    // Atualiza tarefas
    carregarKanbanOnline();

    // Atualiza status
    atualizarStatusKanban();

    // Pequeno feedback visual (opcional)
    console.log("Kanban atualizado em tempo real");
}

</script>
<script>

document.addEventListener("DOMContentLoaded", function() {

    const darkBtn   = document.querySelector(".dark-mode");
    const toggleBtn = document.getElementById("toggleSidebar");
    const app       = document.querySelector(".app");
    const overlay   = document.getElementById("overlay");

    /* ================= DARK MODE ================= */

    // 🔥 Aplica automaticamente ao carregar
    if(localStorage.getItem("theme") === "dark"){
        document.body.classList.add("dark");
    }

    // 🔥 Clique no botão
    if(darkBtn){
        darkBtn.addEventListener("click", function(){

            document.body.classList.toggle("dark");

            if(document.body.classList.contains("dark")){
                localStorage.setItem("theme", "dark");
            } else {
                localStorage.setItem("theme", "light");
            }

        });
    }

    /* ================= SIDEBAR ================= */

    if (toggleBtn && app) {
        toggleBtn.addEventListener("click", function() {
            app.classList.toggle("collapsed");
        });
    }

    if (overlay && app) {
        overlay.addEventListener("click", function() {
            app.classList.add("collapsed");
        });
    }

});

</script>

<script src="transition.js"></script>
</div>

</body>
</html>
