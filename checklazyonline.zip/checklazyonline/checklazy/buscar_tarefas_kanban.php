<?php
session_start();
header("Content-Type: application/json; charset=utf-8");

require_once("conexao.php");

/* ===== Verifica login ===== */
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode([
        "success" => false,
        "error" => "Usuário não logado"
    ]);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

/* ===== Força UTF-8 na conexão ===== */
if ($conn) {
    $conn->set_charset("utf8mb4");
} else {
    echo json_encode([
        "success" => false,
        "error" => "Erro na conexão com o banco"
    ]);
    exit;
}

/* ===== Query principal ===== */
$sql = "
    SELECT 
        k.id,
        k.titulo,
        k.descricao,
        k.status_id,
        s.nome_status
    FROM kanban k
    JOIN status_kanban s ON k.status_id = s.id
    WHERE k.usuario_id = ?
    ORDER BY k.criada_em ASC
";

$stmt = $conn->prepare($sql);

/* ===== Verifica erro no prepare ===== */
if (!$stmt) {
    echo json_encode([
        "success" => false,
        "error" => "Erro no prepare",
        "mysql_error" => $conn->error
    ]);
    exit;
}

$stmt->bind_param("i", $usuario_id);
$stmt->execute();

$result = $stmt->get_result();

$tarefas = [];

while ($row = $result->fetch_assoc()) {

    /* Padroniza nome exibido (opcional) */
    if ($row['nome_status'] === "Concluída") {
        $row['nome_status'] = "Concluído";
    }

    $tarefas[] = [
        "id" => (int)$row["id"],
        "titulo" => $row["titulo"],
        "descricao" => $row["descricao"],
        "status_id" => (int)$row["status_id"],
        "nome_status" => $row["nome_status"]
    ];
}

/* ===== Resposta final ===== */
echo json_encode([
    "success" => true,
    "usuario_id" => $usuario_id,
    "total" => count($tarefas),
    "tarefas" => $tarefas
], JSON_UNESCAPED_UNICODE);

$stmt->close();
$conn->close();
