<?php
session_start();
header("Content-Type: application/json");

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["status" => "erro"]);
    exit;
}

require_once("conexao.php");

$usuario_id = $_SESSION['usuario_id'];

$data = json_decode(file_get_contents("php://input"), true);
$skin = $data['skin'];

$stmt = $conn->prepare("UPDATE usuarios SET skin_ativa = ? WHERE id = ?");
$stmt->bind_param("si", $skin, $usuario_id);
$stmt->execute();

echo json_encode(["status" => "sucesso"]);
