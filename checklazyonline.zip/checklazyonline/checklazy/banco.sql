-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 19/02/2026 às 04:03
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `checklazy`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `calendario`
--

CREATE TABLE `calendario` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `data` date NOT NULL,
  `tipo` varchar(20) DEFAULT NULL,
  `lembrete` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `calendario`
--

INSERT INTO `calendario` (`id`, `usuario_id`, `data`, `tipo`, `lembrete`) VALUES
(6, 50, '2026-02-25', 'concluido', ''),
(8, 50, '2026-02-20', 'evento', 'cantar'),
(9, 50, '2026-02-28', 'dayoff', ''),
(10, 50, '2026-02-18', 'dayoff', '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `kanban`
--

CREATE TABLE `kanban` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `criada_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `kanban`
--

INSERT INTO `kanban` (`id`, `usuario_id`, `status_id`, `titulo`, `descricao`, `criada_em`) VALUES
(41, 50, 1, 'a', '', '2026-02-17 20:20:24'),
(42, 50, 2, 'a', '', '2026-02-17 20:20:29'),
(43, 50, 3, 'a', '', '2026-02-17 20:20:33'),
(44, 50, 4, 'a', '', '2026-02-17 20:20:37'),
(49, 51, 1, 'teste', '', '2026-02-19 03:01:05'),
(50, 51, 2, 'teste', '', '2026-02-19 03:01:10'),
(51, 51, 3, 'teste', '', '2026-02-19 03:01:17'),
(52, 51, 4, 'teste', '', '2026-02-19 03:01:22');

-- --------------------------------------------------------

--
-- Estrutura para tabela `kanban_online`
--

CREATE TABLE `kanban_online` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `kanban_online`
--

INSERT INTO `kanban_online` (`id`, `usuario_id`, `nome`, `senha`, `criado_em`) VALUES
(1, 51, 'teste', '$2y$10$lnCAadJxLa/vH.pXpOj/p.ekYpSUn0U2ZGX4TxLqYLZLER10JVU8a', '2026-02-19 02:44:44'),
(2, 51, 'teste', '$2y$10$lDsGScRcYg3J9HzQ0Ltiveb9g6u8ATKePaj.Lejv3gw70RlB6UVxu', '2026-02-19 03:02:09');

-- --------------------------------------------------------

--
-- Estrutura para tabela `kanban_online_tarefas`
--

CREATE TABLE `kanban_online_tarefas` (
  `id` int(11) NOT NULL,
  `kanban_online_id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `status_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `kanban_online_tarefas`
--

INSERT INTO `kanban_online_tarefas` (`id`, `kanban_online_id`, `titulo`, `descricao`, `status_id`) VALUES
(1, 1, 'aa', '552143', 1),
(2, 1, '654', '654', 2),
(3, 1, '5465', '545', 3),
(4, 1, '5456', '', 4),
(5, 2, 'teste', '', 1),
(6, 2, 'teste', '', 2),
(7, 2, 'teste', '', 3),
(8, 2, 'teste', '', 4);

-- --------------------------------------------------------

--
-- Estrutura para tabela `status_kanban`
--

CREATE TABLE `status_kanban` (
  `id` int(11) NOT NULL,
  `nome_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `status_kanban`
--

INSERT INTO `status_kanban` (`id`, `nome_status`) VALUES
(1, 'A Fazer'),
(2, 'Em Andamento'),
(3, 'Em Revisão'),
(4, 'Concluída');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tarefas`
--

CREATE TABLE `tarefas` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `prioridade` varchar(20) NOT NULL,
  `concluida` tinyint(1) DEFAULT 0,
  `criada_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tarefas`
--

INSERT INTO `tarefas` (`id`, `usuario_id`, `nome`, `prioridade`, `concluida`, `criada_em`) VALUES
(2791, 50, 'a', 'alta', 1, '2026-02-17 20:21:52'),
(2792, 50, 'a', 'alta', 1, '2026-02-17 20:21:52'),
(2793, 50, 'a', 'alta', 1, '2026-02-17 20:21:52'),
(2794, 50, 'a', 'alta', 1, '2026-02-17 20:21:52'),
(2795, 50, 'a', 'alta', 1, '2026-02-17 20:21:52'),
(2796, 50, 'a', 'alta', 1, '2026-02-17 20:21:52'),
(2802, 51, '654', 'alta', 1, '2026-02-18 00:01:51'),
(2803, 51, '564', 'alta', 1, '2026-02-18 00:01:51');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `xp` int(11) DEFAULT 0,
  `nivel` int(11) DEFAULT 1,
  `moedas` int(11) DEFAULT 0,
  `evolucao_recebida` int(11) DEFAULT 0,
  `skin_ativa` varchar(50) DEFAULT 'classica',
  `skins_compradas` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `data_criacao`, `xp`, `nivel`, `moedas`, `evolucao_recebida`, `skin_ativa`, `skins_compradas`) VALUES
(50, 'a', 'lio@gmail.com', '$2y$10$rfX.ji3Yo2/TlbcE2Uq29Oam5Ic2a5Vnjc3izOf6m0IcsqSKWpOKy', '2026-02-17 20:17:03', 113, 6, 100, 3, 'ninja', '[\"ninja\"]'),
(51, 'leo', 'juju@gmail.com', '$2y$10$mUMc4g6RstCfAo/Yr6bk3eoeYM/PDBLLiY0RmtNsKIyG3VbyKdle2', '2026-02-17 23:03:49', 300, 2, 50, 1, 'classica', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario_perfil`
--

CREATE TABLE `usuario_perfil` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `genero` varchar(20) DEFAULT NULL,
  `preferencias` text DEFAULT NULL,
  `atualizado_em` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `avatar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuario_perfil`
--

INSERT INTO `usuario_perfil` (`id`, `usuario_id`, `genero`, `preferencias`, `atualizado_em`, `avatar`) VALUES
(3, 50, 'Feminino', 'estudos', '2026-02-17 20:21:37', 'avatar2.png'),
(4, 51, '', 'Nenhuma preferência definida', '2026-02-18 00:01:30', 'avatar3.png');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `calendario`
--
ALTER TABLE `calendario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario_data` (`usuario_id`,`data`);

--
-- Índices de tabela `kanban`
--
ALTER TABLE `kanban`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `status_id` (`status_id`);

--
-- Índices de tabela `kanban_online`
--
ALTER TABLE `kanban_online`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `kanban_online_tarefas`
--
ALTER TABLE `kanban_online_tarefas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kanban_online_id` (`kanban_online_id`),
  ADD KEY `status_id` (`status_id`);

--
-- Índices de tabela `status_kanban`
--
ALTER TABLE `status_kanban`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `tarefas`
--
ALTER TABLE `tarefas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices de tabela `usuario_perfil`
--
ALTER TABLE `usuario_perfil`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_perfil_usuario` (`usuario_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `calendario`
--
ALTER TABLE `calendario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `kanban`
--
ALTER TABLE `kanban`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT de tabela `kanban_online`
--
ALTER TABLE `kanban_online`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `kanban_online_tarefas`
--
ALTER TABLE `kanban_online_tarefas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `status_kanban`
--
ALTER TABLE `status_kanban`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `tarefas`
--
ALTER TABLE `tarefas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2804;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT de tabela `usuario_perfil`
--
ALTER TABLE `usuario_perfil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `calendario`
--
ALTER TABLE `calendario`
  ADD CONSTRAINT `calendario_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `kanban`
--
ALTER TABLE `kanban`
  ADD CONSTRAINT `fk_kanban_status` FOREIGN KEY (`status_id`) REFERENCES `status_kanban` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_kanban_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `kanban_online`
--
ALTER TABLE `kanban_online`
  ADD CONSTRAINT `kanban_online_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `kanban_online_tarefas`
--
ALTER TABLE `kanban_online_tarefas`
  ADD CONSTRAINT `kanban_online_tarefas_ibfk_1` FOREIGN KEY (`kanban_online_id`) REFERENCES `kanban_online` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `kanban_online_tarefas_ibfk_2` FOREIGN KEY (`status_id`) REFERENCES `status_kanban` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `tarefas`
--
ALTER TABLE `tarefas`
  ADD CONSTRAINT `tarefas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `usuario_perfil`
--
ALTER TABLE `usuario_perfil`
  ADD CONSTRAINT `fk_perfil_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
