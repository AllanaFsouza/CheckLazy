<?php
session_start();
header("Content-Type: application/json");

require_once 'conexao.php';

/* UTF-8 correto */
$conn->set_charset("utf8mb4");

/* Verifica login */
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["success" => false, "error" => "Usuário não logado"]);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

/* Recebe JSON */
$data = json_decode(file_get_contents("php://input"), true);

$titulo     = trim($data["nome"] ?? "");
$descricao  = trim($data["descricao"] ?? "");
$status_nome = trim($data["status"] ?? "");

/* Validação básica */
if ($titulo === "" || $status_nome === "") {
    echo json_encode(["success" => false, "error" => "Dados incompletos"]);
    exit;
}

/* ================= NORMALIZA STATUS ================= */
$mapStatus = [
    "A Fazer"        => "A Fazer",
    "Em Andamento"   => "Em Andamento",
    "Em Revisão"     => "Em Revisão",
    "Concluído"      => "Concluída",
    "Concluida"      => "Concluída"
];

if (!isset($mapStatus[$status_nome])) {
    echo json_encode(["success" => false, "error" => "Status inválido: " . $status_nome]);
    exit;
}

$status_nome = $mapStatus[$status_nome];

/* ================= BUSCAR ID DO STATUS ================= */
$stmtStatus = $conn->prepare("SELECT id FROM status_kanban WHERE nome_status = ?");
$stmtStatus->bind_param("s", $status_nome);
$stmtStatus->execute();
$result = $stmtStatus->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "error" => "Status não encontrado no banco"]);
    exit;
}

$status_id = $result->fetch_assoc()["id"];

/* ================= INSERIR NO KANBAN ================= */
$stmt = $conn->prepare("
    INSERT INTO kanban (usuario_id, status_id, titulo, descricao)
    VALUES (?, ?, ?, ?)
");

$stmt->bind_param("iiss", $usuario_id, $status_id, $titulo, $descricao);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "id" => $stmt->insert_id
    ]);
} else {
    echo json_encode([
        "success" => false,
        "error" => $stmt->error
    ]);
}

/* Fecha conexões */
$stmt->close();
$stmtStatus->close();
$conn->close();
?>
