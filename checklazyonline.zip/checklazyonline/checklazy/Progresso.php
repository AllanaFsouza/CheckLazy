<?php
session_start();
require_once "conexao.php";

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

// Buscar nome e nível no banco
$sql = "SELECT nome, nivel FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();

$nome_usuario = $usuario['nome'];
$nivel_usuario = $usuario['nivel'];
$inicial = strtoupper(substr($nome_usuario, 0, 1));
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Progresso - CheckLazy</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
:root {
    --roxo: #6C63FF;
    --cinza: #f6f6fb;
    --texto: #333;
    --branco: #fff;
    --borda: #e5e5e5;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Lexend', sans-serif;
}

body {
    background: var(--cinza);
    color: var(--texto);
}

.app {
    display: flex;
    min-height: 100vh;
}

/* ===== SIDEBAR ===== */
.sidebar {
    width: 260px;
    background: #f3f3f3;
    padding: 28px 18px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.logo {
    display: flex;
    align-items: center;
    gap: 14px;
    margin-bottom: 35px;
}

.logo h2 {
    font-size: 22px;
    font-weight: 700;
}

.menu {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.menu a {
    padding: 12px 14px;
    border-radius: 12px;
    text-decoration: none;
    color: var(--texto);
    transition: 0.25s ease;
}

.menu a:hover {
    background: #e9e9e9;
}

.menu a.active {
    background: linear-gradient(135deg, #6C63FF, #8e7fff);
    color: white;
}

/* ===== HEADER ===== */
.header {
    position: fixed;
    top: 0;
    left: 260px;
    right: 0;
    background: var(--branco);
    padding: 25px 30px;
    border-bottom: 1px solid var(--borda);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header h1 {
    font-size: 26px;
}

.mode {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    border: 1px solid #ddd;
    background: white;
    cursor: pointer;
}

/* ===== CONTENT ===== */
.content {
    padding: 100px 40px 40px 0px;
}




.main-layout {
    display: flex;
    gap: 60px; /* aumenta só a distância ENTRE colunas */
    align-items: flex-start;
}


.stats-column {
    width: 220px; /* menor largura */
    display: flex;
    flex-direction: column;
    gap: 20px;
}


.stat-card {
    background: var(--branco);
    border-radius: 20px;
    padding: 25px;
    text-align: center;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}

.stat-number {
    font-size: 36px;
    font-weight: 700;
    margin-top: 10px;
}

.right-section {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 30px;
}

.progress-section {
    background: linear-gradient(135deg, var(--roxo), #8e7fff);
    color: white;
    border-radius: 20px;
    padding: 30px;
}

.progress-percent {
    font-size: 42px;
    font-weight: 700;
    margin-bottom: 20px;
}

.progress-bar {
    height: 12px;
    background: rgba(255,255,255,0.2);
    border-radius: 6px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: white;
    width: 0;
    transition: width 1s ease;
}

.chart-section {
    background: var(--branco);
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}

/* ===== DARK MODE ===== */
body.dark {
    --cinza: #0f1220;
    --branco: #171a2b;
    --texto: #ffffff;
    --borda: #2a2e4a;
}

body.dark .sidebar {
    background: var(--branco);
}

body.dark .header {
    background: var(--branco);
}

body.dark .stat-card,
body.dark .chart-section {
    background: #1d2038;
}

body.dark .mode {
    background: #1d2038;
    color: white;
    border-color: #333;
}

.stats-column {
    flex: 0 0 220px; /* largura fixa menor */
}

.right-section {
    flex: 1; /* ocupa TODO o resto do espaço */
}

.stat-card {
    padding: 20px;
}

.chart-section {
    padding: 40px;
}

.stats-column {
    margin-top: 90px; /* aumenta aqui se quiser mais abaixo */
} 


.stats-column {
    margin-top: 40px;
}

.right-section {
    margin-top: 10px;
}

.stats-column {
    flex: 0 0 200px; /* deixa a coluna esquerda menor */
}

.right-section {
    flex: 1;
    min-width: 800px; /* força largura maior */
}

#tasksChart {
    max-width: 400px;
    max-height: 300px;
    margin: 0 auto; /* centraliza */
}
/* BLOCO USUÁRIO + BOTÃO SAIR */
.user {
    display:flex;
    flex-direction:column;
    gap:10px;
    border-top:1px solid #eee;
    padding-top:15px;
}
.user-info {
    display:flex;
    align-items:center;
    gap:10px;
}
.avatar {
    width:40px; height:40px; border-radius:50%;
    background: linear-gradient(135deg, #6C63FF, #8e7fff);
    color:white; display:flex; justify-content:center; align-items:center;
    font-weight:700; font-size:16px;
}
.logout-btn {
    width:100%; padding:12px 16px; border:none; border-radius:12px;
    background:#ddd; color:#333; font-weight:600; cursor:pointer;
    transition:0.25s ease;
}
.logout-btn:hover { background: linear-gradient(135deg, #6C63FF, #8e7fff); color:white; }
.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 25px 30px;
    background: var(--branco);
    border-bottom: 1px solid var(--borda);
}

.header-title {
    display: flex;
    flex-direction: column; /* Faz o <p> ficar abaixo do <h1> */
}

.logo {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 35px;
}

.logo-mascot {
    width: 42px;
    height: 42px;
    object-fit: contain;
    animation: float-preguica 3s ease-in-out infinite;
}

@keyframes float-preguica {
    0% { transform: translateY(0); }
    50% { transform: translateY(-6px); }
    100% { transform: translateY(0); }
}
/* ===== MODAL LOGOUT ===== */

.modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.45);
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

.logout-box {
    background: var(--branco);
    color: var(--texto);
    padding: 30px;
    border-radius: 20px;
    text-align: center;
    max-width: 320px;
    width: 80%;
    box-shadow: 0 10px 30px rgba(0,0,0,0.25);
}

.logout-actions {
    margin-top: 20px;
    display: flex;
    justify-content: center;
    gap: 10px;
}

.btn-cancel {
    padding: 10px 16px;
    border-radius: 10px;
    border: none;
    background: #ddd;
    cursor: pointer;
}

.btn-confirm {
    padding: 10px 16px;
    border-radius: 10px;
    border: none;
    background: #6C63FF;
    color: white;
    cursor: pointer;
}
/* ============================= */
/* 📱 RESPONSIVIDADE */
/* ============================= */

/* Botão menu (desktop escondido) */
.menu-toggle{
    display: none;
    width: 42px;
    height: 42px;
    border-radius: 50%;
    border: 1px solid #ddd;
    background: #fff;
    cursor: pointer;
}

/* Overlay escuro */
.sidebar-overlay{
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.45);
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.3s ease;
    z-index: 998;
}

.sidebar-overlay.active{
    opacity: 1;
    visibility: visible;
}

/* Camadas */
.sidebar{
    z-index: 999;
}

.header{
    z-index: 997;
}

/* ============================= */
/* 📱 MOBILE */
/* ============================= */

@media (max-width: 992px){

    /* Sidebar vira drawer */
    .sidebar{
        position: fixed;
        top: 0;
        left: -100%;
        width: 80%;
        max-width: 280px;
        height: 100vh;
        transition: left 0.3s ease;
        box-shadow: 0 0 30px rgba(0,0,0,0.25);
    }

    .sidebar.active{
        left: 0;
    }

    /* Mostrar botão menu */
    .menu-toggle{
        display: block;
    }

    /* Header ocupa largura total */
    .header{
        left: 0;
    }

    /* Layout principal em coluna */
    .main-layout{
        flex-direction: column;
        gap: 30px;
    }

    /* Cards estatísticas lado a lado */
    .stats-column{
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        gap: 10px;
        width: 100%;
        margin-top: 0;
    }

    .stat-card{
        flex: 1;
        min-width: 0;
    }

    /* Seção direita ocupa tudo */
    .right-section{
        min-width: 100%;
    }

    /* Ajuste gráfico */
    #tasksChart{
        max-width: 100%;
        max-height: 250px;
    }

    /* Ajuste padding conteúdo */
    .content{
        padding: 100px 20px 40px 20px;
    }
}
.stat-card {
    background: var(--branco);
    border-radius: 20px;
    padding: 18px 10px;
    display: flex;
    flex-direction: column;
    justify-content: center; /* centraliza vertical */
    align-items: center;     /* centraliza horizontal */
    text-align: center;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}
.stat-card h3 {
    margin: 0;
    font-size: 20px;
    font-weight: 500;
}
.stat-number {
    font-size: 35px;
    font-weight: 700;
    margin-top: 6px;
}

</style>
</head>

<body>
<div class="sidebar-overlay"></div>

<div class="app">

<aside class="sidebar">
    <div>
       <div class="logo">
    <img src="LogoCheckLazy.png" alt="Mascote CheckLazy" class="logo-mascot">
    <h2>CheckLazy</h2>
</div>


        <nav class="menu">
       <a href="Tela_inicial.php">📊 Dashboard</a>
<a href="Tarefas.php">📋 Tarefas</a>
<a href="Kanban.php">🗂 Kanban</a>
<a href="Calendario.php">📅 Calendário</a>
<a href="Progresso.php" class="active">📈 Progresso</a>
<a href="Configuracoes.php">⚙️ Configurações</a>
<a href="kanbanonline.php" >🌎 Kanban Online</a>

        </nav>
    </div>
     <!-- BLOCO DO USUÁRIO + BOTÃO SAIR -->
    <div class="user">
        <div class="user-info">
            <div class="avatar"><?php echo $inicial; ?></div>
            <div>
                <strong><?php echo htmlspecialchars($nome_usuario); ?></strong><br>
                <small>Nível <?php echo htmlspecialchars($nivel_usuario); ?></small>
            </div>
        </div>
        <button class="logout-btn">⎋ Sair</button>
    </div>
</aside>
<header class="header">
    <div class="header-title">
        <h1>Progresso</h1>
        <p>Acompanhe seu desempenho!</p>
    </div>
    <div style="display:flex; gap:10px;">
    <button class="mode">🌙</button>
    <button class="menu-toggle">☰</button>
</div>

</header>

<main class="content">

<div class="main-layout">
<div class="stats-column">
    <div class="stat-card">
        <h3>Total</h3>
        <div class="stat-number" id="totalTasks">
            <?php
            $sql_total = "SELECT COUNT(*) AS total FROM tarefas WHERE usuario_id = ?";
            $stmt_total = $conn->prepare($sql_total);
            $stmt_total->bind_param("i", $usuario_id);
            $stmt_total->execute();
            $result_total = $stmt_total->get_result();
            $total = $result_total->fetch_assoc()['total'];
            echo $total;
            ?>
        </div>
    </div>

    <div class="stat-card">
        <h3>Ativas</h3>
        <div class="stat-number" id="activeTasks">
            <?php
            $sql_ativas = "SELECT COUNT(*) AS ativas FROM tarefas WHERE usuario_id = ? AND concluida = 0";
            $stmt_ativas = $conn->prepare($sql_ativas);
            $stmt_ativas->bind_param("i", $usuario_id);
            $stmt_ativas->execute();
            $result_ativas = $stmt_ativas->get_result();
            $ativas = $result_ativas->fetch_assoc()['ativas'];
            echo $ativas;
            ?>
        </div>
    </div>

    <div class="stat-card">
        <h3>Concluídas</h3>
        <div class="stat-number" id="completedTasks">
            <?php
            $sql_concluidas = "SELECT COUNT(*) AS concluidas FROM tarefas WHERE usuario_id = ? AND concluida = 1";
            $stmt_concluidas = $conn->prepare($sql_concluidas);
            $stmt_concluidas->bind_param("i", $usuario_id);
            $stmt_concluidas->execute();
            $result_concluidas = $stmt_concluidas->get_result();
            $concluidas = $result_concluidas->fetch_assoc()['concluidas'];
            echo $concluidas;
            ?>
        </div>
    </div>
</div>

<div class="right-section">
    <div class="progress-section">
        <h2>Progresso Geral</h2>
        <div class="progress-percent" id="progressPercent">
            <?php
            $percent = $total > 0 ? round(($concluidas / $total) * 100) : 0;
            echo $percent . '%';
            ?>
        </div>
        <div class="progress-bar">
            <div class="progress-fill" id="progressFill" style="width: <?php echo $percent; ?>%;"></div>
        </div>
    </div>


        <div class="chart-section">
            <h2>Distribuição das Tarefas</h2>
            <canvas id="tasksChart"></canvas>
        </div>
    </div>

</div>
<!-- MODAL DE CONFIRMAÇÃO DE LOGOUT -->
<div id="logout-modal" class="modal">
    <div class="logout-box">
        <h3>Deseja realmente sair?</h3>
        <p>Você será desconectado do CheckLazy 🐌</p>

        <div class="logout-actions">
            <button id="cancel-logout" class="btn-cancel">Cancelar</button>
            <button id="confirm-logout" class="btn-confirm">Sair</button>
        </div>
    </div>
</div>


</main>
</div>

<script>


function updateChart(active, completed) {
    const ctx = document.getElementById('tasksChart').getContext('2d');

    if (chart) {
        chart.data.datasets[0].data = [active, completed];
        chart.update();
        return;
    }

    chart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Ativas', 'Concluídas'],
            datasets: [{
                data: [active, completed],
                backgroundColor: ['#3B82F6', '#10B981'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { position: 'bottom' } },
            cutout: '70%'
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    loadTasks();
    updateStats();
});

/* DARK MODE */
const modeBtn = document.querySelector('.mode');
const body = document.body;

if (localStorage.getItem('theme') === 'dark') {
    body.classList.add('dark');
    modeBtn.textContent = '☀️';
}

modeBtn.addEventListener('click', () => {
    body.classList.toggle('dark');

    if (body.classList.contains('dark')) {
        localStorage.setItem('theme', 'dark');
        modeBtn.textContent = '☀️';
    } else {
        localStorage.setItem('theme', 'light');
        modeBtn.textContent = '🌙';
    }
});
/* LOGOUT */
const logoutBtn = document.querySelector('.logout-btn');
const logoutModal = document.getElementById('logout-modal');
const cancelLogout = document.getElementById('cancel-logout');
const confirmLogout = document.getElementById('confirm-logout');

// Abrir modal ao clicar em "Sair"
logoutBtn.addEventListener('click', () => {
    logoutModal.style.display = 'flex';
});

// Cancelar logout
cancelLogout.addEventListener('click', () => {
    logoutModal.style.display = 'none';
});

// Confirmar logout
confirmLogout.addEventListener('click', () => {
    window.location.href = 'logout.php'; // aqui você faz a saída real
});

// Fechar clicando fora do modal
logoutModal.addEventListener('click', (e) => {
    if (e.target === logoutModal) {
        logoutModal.style.display = 'none';
    }
});

</script>
<script>
const active = <?php echo $ativas; ?>;
const completed = <?php echo $concluidas; ?>;

const ctx = document.getElementById('tasksChart').getContext('2d');

new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: ['Ativas', 'Concluídas'],
        datasets: [{
            data: [active, completed],
            backgroundColor: ['#3B82F6', '#10B981'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' } },
        cutout: '70%'
    }
});
</script>
<script>
const active = <?php echo $ativas; ?>;
const completed = <?php echo $concluidas; ?>;

const ctx = document.getElementById('tasksChart').getContext('2d');

new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: ['Ativas', 'Concluídas'],
        datasets: [{
            data: [active, completed],
            backgroundColor: ['#3B82F6', '#10B981'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' } },
        cutout: '70%'
    }
});
/* ============================= */
/* ☰ TOGGLE SIDEBAR */
/* ============================= */

const toggleBtn = document.querySelector(".menu-toggle");
const sidebar = document.querySelector(".sidebar");
const overlay = document.querySelector(".sidebar-overlay");

if(toggleBtn){
    toggleBtn.addEventListener("click", () => {
        sidebar.classList.toggle("active");
        overlay.classList.toggle("active");
    });
}

if(overlay){
    overlay.addEventListener("click", () => {
        sidebar.classList.remove("active");
        overlay.classList.remove("active");
    });
}

</script>
<script>
document.addEventListener("DOMContentLoaded", function(){

    const toggleBtn = document.querySelector(".menu-toggle");
    const sidebar = document.querySelector(".sidebar");
    const overlay = document.querySelector(".sidebar-overlay");

    if(toggleBtn){
        toggleBtn.addEventListener("click", function(){
            sidebar.classList.toggle("active");
            overlay.classList.toggle("active");
        });
    }

    if(overlay){
        overlay.addEventListener("click", function(){
            sidebar.classList.remove("active");
            overlay.classList.remove("active");
        });
    }

});
</script>

<script src="transition.js"></script>
</body>



</body>
</html>