<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["status" => "erro", "mensagem" => "Usuário não autenticado"]);
    exit;
}

require_once 'conexao.php';

$usuario_id = $_SESSION['usuario_id'];

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['tasks'])) {
    echo json_encode(["status" => "erro", "mensagem" => "Dados inválidos"]);
    exit;
}

$tasks = $data['tasks'];

/* Limpa tarefas antigas */
$conn->query("DELETE FROM tarefas WHERE usuario_id = $usuario_id");

/* Insere novamente */
$stmt = $conn->prepare("INSERT INTO tarefas (usuario_id, nome, prioridade, concluida) VALUES (?, ?, ?, ?)");

foreach ($tasks as $task) {
    $nome = $task['name'];
    $prioridade = $task['priority'];
    $done = $task['done'] ? 1 : 0;

    $stmt->bind_param("issi", $usuario_id, $nome, $prioridade, $done);
    $stmt->execute();
}

echo json_encode(["status" => "sucesso"]);
