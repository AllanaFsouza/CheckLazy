<?php
$host = "127.0.0.1";     // ou localhost
$user = "root";         // padrão XAMPP
$password = "";         // normalmente vazio no XAMPP
$database = "checklazy";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>
