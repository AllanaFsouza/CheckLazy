<?php
session_start();
require_once "conexao.php";

header("Content-Type: application/json");

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode([]);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

$stmt = $conn->prepare("
    SELECT data, tipo, lembrete 
    FROM calendario 
    WHERE usuario_id = ?
");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();

$result = $stmt->get_result();

$eventos = [];

while ($row = $result->fetch_assoc()) {
    $eventos[] = [
        "data" => $row["data"],
        "tipo" => $row["tipo"],
        "lembrete" => $row["lembrete"]
    ];
}

echo json_encode($eventos);
?>
