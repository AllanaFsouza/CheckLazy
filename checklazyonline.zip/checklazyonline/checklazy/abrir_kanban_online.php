<?php
session_start();
require_once "conexao.php";

header("Content-Type: application/json");

if (!isset($_SESSION["kanban_online_id"])) {
    echo json_encode(["success" => false, "error" => "Não logado no Kanban Online"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$titulo = trim($data["titulo"] ?? "");
$descricao = trim($data["descricao"] ?? "");
$status = $data["status"] ?? "";

if (!$titulo || !$status) {
    echo json_encode(["success" => false, "error" => "Dados inválidos"]);
    exit;
}

$kanban_id = $_SESSION["kanban_online_id"];

/* Converte texto → id do status */
$status_id = 1;

if ($status === "doing") $status_id = 2;
if ($status === "review") $status_id = 3;
if ($status === "done") $status_id = 4;

$stmt = $conn->prepare("
    INSERT INTO kanban_online_tarefas 
    (kanban_online_id, titulo, descricao, status_id)
    VALUES (?, ?, ?, ?)
");

$stmt->bind_param("issi", $kanban_id, $titulo, $descricao, $status_id);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode([
        "success" => false,
        "error" => $conn->error
    ]);
}
